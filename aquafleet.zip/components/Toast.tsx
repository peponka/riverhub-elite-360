import React, { createContext, useContext, useState, useCallback } from 'react';

type ToastType = 'success' | 'error' | 'info' | 'warning';

interface Toast {
  id: number;
  message: string;
  type: ToastType;
}

interface ToastContextType {
  showToast: (message: string, type?: ToastType) => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
};

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const showToast = useCallback((message: string, type: ToastType = 'info') => {
    const id = Date.now();
    setToasts((prev) => [...prev, { id, message, type }]);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3000);
  }, []);

  const removeToast = (id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="fixed bottom-4 right-4 z-[9999] flex flex-col gap-2 pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto min-w-[300px] max-w-md p-4 rounded-lg shadow-2xl border flex items-center gap-3 transform transition-all duration-300 animate-fade-in-up
              ${toast.type === 'success' ? 'bg-white dark:bg-surface-dark border-emerald-500 text-slate-800 dark:text-white' : ''}
              ${toast.type === 'error' ? 'bg-white dark:bg-surface-dark border-red-500 text-slate-800 dark:text-white' : ''}
              ${toast.type === 'info' ? 'bg-white dark:bg-surface-dark border-primary text-slate-800 dark:text-white' : ''}
              ${toast.type === 'warning' ? 'bg-white dark:bg-surface-dark border-orange-500 text-slate-800 dark:text-white' : ''}
            `}
          >
            <div className={`p-1 rounded-full text-white
              ${toast.type === 'success' ? 'bg-emerald-500' : ''}
              ${toast.type === 'error' ? 'bg-red-500' : ''}
              ${toast.type === 'info' ? 'bg-primary' : ''}
              ${toast.type === 'warning' ? 'bg-orange-500' : ''}
            `}>
              <span className="material-symbols-outlined text-[18px] block">
                {toast.type === 'success' ? 'check' : toast.type === 'error' ? 'error' : toast.type === 'warning' ? 'warning' : 'info'}
              </span>
            </div>
            <p className="text-sm font-medium flex-1">{toast.message}</p>
            <button onClick={() => removeToast(toast.id)} className="text-slate-400 hover:text-slate-600 dark:hover:text-white">
              <span className="material-symbols-outlined text-[18px]">close</span>
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
};