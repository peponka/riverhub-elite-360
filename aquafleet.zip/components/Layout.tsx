import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';

interface LayoutProps {
  children: React.ReactNode;
  onLogout: () => void;
}

// --- Mock Data for Global Search ---
const GLOBAL_INDEX = [
  { id: 'v1', type: 'vessel', title: 'Remolcador Titan III', subtitle: 'Operativo • Km 1240', url: '/fleet' },
  { id: 'v2', type: 'vessel', title: 'Barcaza B-102', subtitle: 'Cargada • Soja', url: '/fleet' },
  { id: 'c1', type: 'crew', title: 'Cap. Roberto Gómez', subtitle: 'Titan III • Activo', url: '/crew' },
  { id: 'c2', type: 'crew', title: 'Jefe Máq. Fernández', subtitle: 'Franco', url: '/crew' },
  { id: 't1', type: 'trip', title: 'Viaje VJ-2024-081', subtitle: 'Asunción -> Rosario', url: '/trips' },
  { id: 'r1', type: 'report', title: 'Reporte de Combustible', subtitle: 'Octubre 2023', url: '/reports' },
  { id: 'd1', type: 'doc', title: 'Manifiesto #8829', subtitle: 'Titan III • Soja', url: '/documents' },
];

// --- Mock Data for Notifications ---
const NOTIFICATIONS = [
  { id: 1, title: 'Alerta de Motor', desc: 'Temp. alta en Titan III (Estribor)', time: 'Hace 5 min', type: 'critical' },
  { id: 2, title: 'Tormenta Severa', desc: 'Aviso meteorológico zona Pilar.', time: 'Hace 30 min', type: 'warning' },
  { id: 3, title: 'Arribo a Puerto', desc: 'Convoy Alpha llegó a Villeta.', time: 'Hace 2 horas', type: 'info' },
  { id: 4, title: 'Documento Vencido', desc: 'Póliza de seguro Barcaza T-55.', time: 'Ayer', type: 'warning' },
];

const NavItem = ({ to, icon, label, active, onClick, badge }: { to: string; icon: string; label: string; active: boolean; onClick?: () => void; badge?: string }) => (
  <Link
    to={to}
    onClick={onClick}
    className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors group relative ${
      active
        ? 'bg-primary/10 text-primary border-l-4 border-primary'
        : 'text-[#637588] dark:text-[#9db2b9] hover:bg-[#e0e0e0] dark:hover:bg-[#192327] hover:text-[#111618] dark:hover:text-white border-l-4 border-transparent'
    }`}
  >
    <span className={`material-symbols-outlined text-[22px] ${active ? 'filled' : ''}`}>{icon}</span>
    <p className="text-sm font-medium">{label}</p>
    {badge && (
      <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] font-bold px-1.5 py-0.5 rounded bg-red-500 text-white">
        {badge}
      </span>
    )}
  </Link>
);

export const Layout: React.FC<LayoutProps> = ({ children, onLogout }) => {
  const { t } = useLanguage(); 
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true); 

  const location = useLocation();
  const navigate = useNavigate();
  const p = location.pathname;
  
  const searchRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchFocused(false);
      }
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setIsNotifOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setIsProfileOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);
  const closeSidebar = () => setIsSidebarOpen(false);

  const filteredResults = searchQuery 
    ? GLOBAL_INDEX.filter(item => item.title.toLowerCase().includes(searchQuery.toLowerCase()) || item.subtitle.toLowerCase().includes(searchQuery.toLowerCase()))
    : [];

  const handleSearchResultClick = (url: string) => {
      navigate(url);
      setSearchQuery('');
      setIsSearchFocused(false);
  };

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background-light dark:bg-background-dark text-slate-900 dark:text-white">
      
      {/* Mobile Backdrop */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-30 md:hidden"
          onClick={closeSidebar}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed md:static inset-y-0 left-0 z-40 w-64 flex flex-col border-r border-[#e0e0e0] dark:border-border-dark bg-white dark:bg-surface-darker shrink-0 transition-transform duration-300 ease-out shadow-2xl md:shadow-none
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        <div className="flex flex-col h-full overflow-y-auto custom-scrollbar">
          <div className="p-4 flex flex-col gap-6">
            {/* Branding */}
            <div className="flex items-center justify-between px-2 mt-2">
              <div className="flex items-center gap-3">
                <div className="bg-primary/20 flex items-center justify-center rounded-lg size-10 text-primary">
                  <span className="material-symbols-outlined text-2xl">anchor</span>
                </div>
                <div className="flex flex-col">
                  <h1 className="text-slate-900 dark:text-white text-lg font-bold leading-none tracking-tight">RiverHub</h1>
                  <p className="text-slate-500 dark:text-[#9db2b9] text-xs font-medium mt-1">Elite 360</p>
                </div>
              </div>
              <button 
                onClick={closeSidebar}
                className="md:hidden p-1 text-slate-400 hover:text-primary transition-colors"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            {/* Navigation */}
            <nav className="flex flex-col gap-1">
              
              <NavItem onClick={closeSidebar} to="/dashboard" icon="dashboard" label={t('nav.dashboard')} active={p === '/dashboard'} />
              <NavItem onClick={closeSidebar} to="/map" icon="map" label={t('nav.map')} active={p === '/map'} />

              {/* Commercial */}
              <div className="my-2 px-3">
                  <p className="text-[10px] font-bold text-slate-400 dark:text-slate-600 uppercase tracking-widest">{t('nav.commercial')}</p>
              </div>
              <NavItem onClick={closeSidebar} to="/quote-ia" icon="smart_toy" label={t('nav.quote')} active={p === '/quote-ia'} />
              <NavItem onClick={closeSidebar} to="/documents" icon="description" label={t('nav.docs')} active={p === '/documents'} />
              
              {/* Operations */}
              <div className="my-2 px-3">
                  <p className="text-[10px] font-bold text-slate-400 dark:text-slate-600 uppercase tracking-widest">{t('nav.ops')}</p>
              </div>
              <NavItem onClick={closeSidebar} to="/fleet" icon="directions_boat" label={t('nav.fleet')} active={p.startsWith('/fleet')} />
              <NavItem onClick={closeSidebar} to="/communications" icon="podcasts" label={t('nav.comms')} active={p === '/communications'} badge="VHF" />
              <NavItem onClick={closeSidebar} to="/crew" icon="groups" label={t('nav.crew')} active={p.startsWith('/crew')} />
              <NavItem onClick={closeSidebar} to="/inventory" icon="inventory_2" label={t('nav.inventory')} active={p === '/inventory'} />
              <NavItem onClick={closeSidebar} to="/fuel" icon="local_gas_station" label={t('nav.fuel')} active={p.startsWith('/fuel')} />
              <NavItem onClick={closeSidebar} to="/maintenance" icon="build" label={t('nav.maintenance')} active={p.startsWith('/maintenance')} />
              <NavItem onClick={closeSidebar} to="/trips" icon="route" label={t('nav.trips')} active={p.startsWith('/trips')} />
              
              {/* Environment */}
              <div className="my-2 px-3">
                  <p className="text-[10px] font-bold text-slate-400 dark:text-slate-600 uppercase tracking-widest">{t('nav.env')}</p>
              </div>
              <NavItem onClick={closeSidebar} to="/weather" icon="water_drop" label={t('nav.weather')} active={p === '/weather'} />
              <NavItem onClick={closeSidebar} to="/incidents" icon="emergency_home" label={t('nav.incidents')} active={p.startsWith('/incidents')} />

              {/* Integrations */}
              <NavItem onClick={closeSidebar} to="/integrations" icon="hub" label={t('nav.integrations')} active={p === '/integrations'} />

              {/* Reports */}
              <NavItem onClick={closeSidebar} to="/reports" icon="analytics" label="Reportes" active={p === '/reports'} />

            </nav>
          </div>

          {/* Bottom Actions */}
          <div className="mt-auto border-t border-[#e0e0e0] dark:border-border-dark p-4 flex flex-col gap-1 bg-slate-50 dark:bg-surface-darker/50">
            
            {/* User Profile Card */}
            <div className="flex items-center gap-3 px-3 py-2 mb-2 bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl shadow-sm">
                <div className="size-10 rounded-full bg-cover bg-center shrink-0" style={{ backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuCNwgFHJoYptmcRwaXtmAb_7-PBlFZWVuNRjuVLm7YrocUBJmoXaR0Ignk-j3R32osPKa3KJb5n2xc-0jyyD__WReaPTuVDL1ae_3qgfZn5Q9CF8EhDJXm-7rHk0xilgjHxiVerVzi403GGhMk7ucKHGlMQApWjQdxjerq4EZ9ndOYMR0fPw1jBhdkmI_gcDU6MYVmy8JynuyHW4eV8YobFxGTq0o2guRm8_3dsKdVTeYLPlBD2fQYHFwqSX-89s8XJdDvuOfw8gAtr")' }}></div>
                <div className="min-w-0">
                    <p className="text-sm font-bold text-slate-900 dark:text-white truncate">Carlos Martínez</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 uppercase font-bold tracking-wider">Admin Principal</p>
                </div>
            </div>

            <NavItem onClick={closeSidebar} to="/settings" icon="settings" label={t('nav.settings')} active={p === '/settings'} />
            
            <button
              onClick={onLogout}
              className="flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-slate-500 dark:text-[#9db2b9] hover:bg-red-50 dark:hover:bg-red-900/10 hover:text-red-500 transition-colors group"
            >
              <span className="material-symbols-outlined group-hover:text-red-500">logout</span>
              <p className="text-sm font-medium">{t('nav.logout')}</p>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full min-w-0 overflow-hidden relative">
        {/* Header */}
        <header className="h-16 border-b border-[#e0e0e0] dark:border-border-dark bg-white/80 dark:bg-surface-darker/80 backdrop-blur-md px-6 flex items-center justify-between shrink-0 z-20">
          <div className="flex items-center gap-4 md:hidden">
            <button 
              onClick={toggleSidebar}
              className="p-1 -ml-2 text-slate-500 dark:text-white hover:bg-slate-100 dark:hover:bg-surface-dark rounded-lg transition-colors"
            >
              <span className="material-symbols-outlined">menu</span>
            </button>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">RiverHub</h2>
          </div>

          {/* Global Search */}
          <div className="hidden md:block flex-1 max-w-xl relative" ref={searchRef}>
            <div className="relative w-full group">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <span className={`material-symbols-outlined transition-colors text-[20px] ${isSearchFocused ? 'text-primary' : 'text-slate-400'}`}>search</span>
              </div>
              <input
                className="block w-full rounded-lg border-none bg-slate-100 dark:bg-surface-dark py-2 pl-10 pr-3 text-sm text-slate-900 dark:text-white placeholder-slate-500 focus:ring-2 focus:ring-primary transition-all"
                placeholder={t('search.placeholder')}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
              />
              {/* Shortcut Hint */}
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <span className="text-xs text-slate-400 border border-slate-300 dark:border-slate-600 rounded px-1.5 py-0.5">⌘ K</span>
              </div>
            </div>

            {/* Search Dropdown Results */}
            {isSearchFocused && searchQuery && (
                <div className="absolute top-full mt-2 left-0 w-full bg-white dark:bg-surface-dark rounded-xl shadow-2xl border border-slate-200 dark:border-border-dark overflow-hidden animate-fade-in-up z-50">
                    {filteredResults.length > 0 ? (
                        <div className="py-2">
                            <p className="px-4 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Resultados</p>
                            {filteredResults.map((item) => (
                                <button 
                                    key={item.id}
                                    onClick={() => handleSearchResultClick(item.url)}
                                    className="w-full text-left px-4 py-3 hover:bg-slate-50 dark:hover:bg-surface-darker flex items-center gap-3 transition-colors group"
                                >
                                    <div className={`size-8 rounded-lg flex items-center justify-center text-white
                                        ${item.type === 'vessel' ? 'bg-blue-500' : ''}
                                        ${item.type === 'crew' ? 'bg-emerald-500' : ''}
                                        ${item.type === 'trip' ? 'bg-purple-500' : ''}
                                        ${item.type === 'report' ? 'bg-slate-500' : ''}
                                        ${item.type === 'doc' ? 'bg-orange-500' : ''}
                                    `}>
                                        <span className="material-symbols-outlined text-[18px]">
                                            {item.type === 'vessel' ? 'directions_boat' : item.type === 'crew' ? 'person' : item.type === 'trip' ? 'route' : item.type === 'doc' ? 'description' : 'analytics'}
                                        </span>
                                    </div>
                                    <div>
                                        <p className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-primary">{item.title}</p>
                                        <p className="text-xs text-slate-500">{item.subtitle}</p>
                                    </div>
                                    <span className="material-symbols-outlined ml-auto text-slate-400 text-[16px] group-hover:text-primary">arrow_forward</span>
                                </button>
                            ))}
                        </div>
                    ) : (
                        <div className="p-6 text-center text-slate-500">
                            <span className="material-symbols-outlined text-3xl mb-2 opacity-50">manage_search</span>
                            <p className="text-sm">No se encontraron resultados para "{searchQuery}"</p>
                        </div>
                    )}
                </div>
            )}
          </div>

          <div className="flex items-center gap-4">
            
            {/* System Status Indicator */}
            <div className="hidden lg:flex items-center px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full" title="Estado del Sistema">
                <div className="size-2 rounded-full bg-emerald-500 animate-pulse mr-2"></div>
                <span className="text-xs font-bold text-emerald-500">{t('status.operational')}</span>
            </div>
            
            <div className="h-8 w-px bg-[#e0e0e0] dark:bg-border-dark mx-1 hidden md:block"></div>
            
            {/* Notification Center */}
            <div className="relative" ref={notifRef}>
                <button 
                    onClick={() => setIsNotifOpen(!isNotifOpen)}
                    className={`relative p-2 rounded-lg transition-colors ${isNotifOpen ? 'bg-primary/10 text-primary' : 'text-slate-500 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-surface-dark'}`}
                >
                    <span className="material-symbols-outlined">notifications</span>
                    <span className="absolute top-2 right-2 size-2 bg-red-500 rounded-full ring-2 ring-white dark:ring-surface-darker animate-pulse"></span>
                </button>

                {isNotifOpen && (
                    <div className="absolute top-full right-0 mt-2 w-80 bg-white dark:bg-surface-dark rounded-xl shadow-2xl border border-slate-200 dark:border-border-dark overflow-hidden z-50 animate-fade-in-up">
                        <div className="px-4 py-3 border-b border-slate-200 dark:border-border-dark flex justify-between items-center bg-slate-50 dark:bg-surface-darker">
                            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Notificaciones</h3>
                            <button className="text-xs text-primary hover:underline">Marcar leídas</button>
                        </div>
                        <div className="max-h-[300px] overflow-y-auto">
                            {NOTIFICATIONS.map(notif => (
                                <div key={notif.id} className="p-3 border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-surface-darker transition-colors cursor-pointer flex gap-3">
                                    <div className={`mt-1 size-2 rounded-full shrink-0 ${notif.type === 'critical' ? 'bg-red-500' : notif.type === 'warning' ? 'bg-orange-500' : 'bg-blue-500'}`}></div>
                                    <div>
                                        <p className="text-sm font-bold text-slate-800 dark:text-slate-200">{notif.title}</p>
                                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{notif.desc}</p>
                                        <p className="text-[10px] text-slate-400 mt-1">{notif.time}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div className="p-2 text-center border-t border-slate-200 dark:border-border-dark bg-slate-50 dark:bg-surface-darker">
                            <Link to="/incidents" onClick={() => setIsNotifOpen(false)} className="text-xs font-bold text-primary hover:underline block py-1">Ver Centro de Incidentes</Link>
                        </div>
                    </div>
                )}
            </div>

            {/* Profile Menu (Header - Simplified for Mobile/Desktop Sync) */}
            <div className="relative" ref={profileRef}>
                <div 
                  onClick={() => setIsProfileOpen(!isProfileOpen)}
                  className="flex items-center gap-3 cursor-pointer p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-surface-dark transition-colors group select-none"
                >
                  <div className="text-right hidden md:block">
                    <p className="text-sm font-medium text-slate-900 dark:text-white group-hover:text-primary transition-colors">Cuenta</p>
                  </div>
                  <div
                    className="size-9 rounded-full bg-cover bg-center ring-2 ring-white dark:ring-border-dark shadow-sm group-hover:ring-primary transition-all"
                    style={{ backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuCNwgFHJoYptmcRwaXtmAb_7-PBlFZWVuNRjuVLm7YrocUBJmoXaR0Ignk-j3R32osPKa3KJb5n2xc-0jyyD__WReaPTuVDL1ae_3qgfZn5Q9CF8EhDJXm-7rHk0xilgjHxiVerVzi403GGhMk7ucKHGlMQApWjQdxjerq4EZ9ndOYMR0fPw1jBhdkmI_gcDU6MYVmy8JynuyHW4eV8YobFxGTq0o2guRm8_3dsKdVTeYLPlBD2fQYHFwqSX-89s8XJdDvuOfw8gAtr")' }}
                  ></div>
                  <span className="material-symbols-outlined text-slate-400 text-[20px] group-hover:text-primary transition-colors">expand_more</span>
                </div>

                {/* Profile Dropdown */}
                {isProfileOpen && (
                    <div className="absolute top-full right-0 mt-2 w-56 bg-white dark:bg-surface-dark rounded-xl shadow-2xl border border-slate-200 dark:border-border-dark overflow-hidden z-50 animate-fade-in-up">
                        <div className="p-4 border-b border-slate-200 dark:border-border-dark flex items-center gap-3 md:hidden">
                             <div className="size-10 rounded-full bg-cover bg-center" style={{ backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuCNwgFHJoYptmcRwaXtmAb_7-PBlFZWVuNRjuVLm7YrocUBJmoXaR0Ignk-j3R32osPKa3KJb5n2xc-0jyyD__WReaPTuVDL1ae_3qgfZn5Q9CF8EhDJXm-7rHk0xilgjHxiVerVzi403GGhMk7ucKHGlMQApWjQdxjerq4EZ9ndOYMR0fPw1jBhdkmI_gcDU6MYVmy8JynuyHW4eV8YobFxGTq0o2guRm8_3dsKdVTeYLPlBD2fQYHFwqSX-89s8XJdDvuOfw8gAtr")' }}></div>
                             <div>
                                 <p className="text-sm font-bold text-slate-900 dark:text-white">Carlos Martínez</p>
                                 <p className="text-xs text-slate-500 uppercase">Admin Principal</p>
                             </div>
                        </div>
                        <div className="p-2 space-y-1">
                            <button onClick={() => { navigate('/settings'); setIsProfileOpen(false); }} className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-surface-darker flex items-center gap-3 text-sm text-slate-700 dark:text-slate-200 transition-colors">
                                <span className="material-symbols-outlined text-[18px]">person</span> Mi Perfil
                            </button>
                            <button onClick={() => { navigate('/settings'); setIsProfileOpen(false); }} className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-surface-darker flex items-center gap-3 text-sm text-slate-700 dark:text-slate-200 transition-colors">
                                <span className="material-symbols-outlined text-[18px]">settings</span> Configuración
                            </button>
                            <button onClick={() => setIsDarkMode(!isDarkMode)} className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-surface-darker flex items-center justify-between text-sm text-slate-700 dark:text-slate-200 transition-colors">
                                <div className="flex items-center gap-3">
                                    <span className="material-symbols-outlined text-[18px]">{isDarkMode ? 'dark_mode' : 'light_mode'}</span>
                                    {isDarkMode ? 'Modo Oscuro' : 'Modo Claro'}
                                </div>
                                <div className={`w-8 h-4 rounded-full relative transition-colors ${isDarkMode ? 'bg-primary' : 'bg-slate-300'}`}>
                                    <div className={`absolute top-0.5 size-3 rounded-full bg-white transition-all ${isDarkMode ? 'left-4.5' : 'left-0.5'}`}></div>
                                </div>
                            </button>
                        </div>
                        <div className="p-2 border-t border-slate-200 dark:border-border-dark">
                            <button onClick={onLogout} className="w-full text-left px-3 py-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/10 text-red-500 flex items-center gap-3 text-sm font-medium transition-colors">
                                <span className="material-symbols-outlined text-[18px]">logout</span> {t('nav.logout')}
                            </button>
                        </div>
                    </div>
                )}
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto bg-slate-50 dark:bg-background-dark p-4 md:p-8 scroll-smooth">
          <div className="max-w-[1600px] mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};