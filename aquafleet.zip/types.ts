
export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl: string;
}

export interface Vessel {
  id: string;
  name: string;
  type: string;
  status: 'Operativo' | 'Mantenimiento' | 'Inactivo' | 'En Ruta';
  capacity: string;
  lastUpdate: string;
}

export interface MaintenanceOrder {
  id: string;
  vessel: string;
  type: 'Preventivo' | 'Correctivo';
  description: string;
  status: 'Pendiente' | 'En Progreso' | 'Vencido' | 'Completado';
  dueDate: string;
  technician: string;
}

export interface Incident {
  id: string;
  type: string;
  vessel: string;
  date: string;
  status: 'Abierto' | 'En Investigación' | 'Cerrado';
  severity: 'Baja' | 'Media' | 'Alta';
}
