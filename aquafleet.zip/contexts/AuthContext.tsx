
import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ error: string | null }>;
  register: (email: string, password: string, fullName: string) => Promise<{ error: string | null }>;
  logout: () => Promise<void>;
  isDemoMode: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};

const DEFAULT_USER: User = {
  id: 'user-admin-01',
  name: 'Carlos Martínez',
  email: 'admin@aquafleet.com',
  avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=2070&auto=format&fit=crop'
};

// Llave única y permanente
const SESSION_KEY = 'aquafleet_session_v7_final'; 

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  
  // 1. INICIALIZACIÓN: Leemos directamente del disco duro al iniciar.
  const [user, setUser] = useState<User | null>(() => {
    // Intentamos leer siempre, independiente del modo
    try {
      const stored = localStorage.getItem(SESSION_KEY);
      if (stored) {
        const parsedUser = JSON.parse(stored);
        if (parsedUser && parsedUser.id) {
            return parsedUser;
        }
      }
    } catch (e) {
      console.error("Error recuperando sesión:", e);
    }
    return null;
  });

  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulamos un check muy rápido para liberar la UI
    // En modo Supabase esto tardaría más, en modo Demo es instantáneo
    if (isSupabaseConfigured && supabase) {
        const initSupabaseAuth = async () => {
            const { data: { session } } = await supabase.auth.getSession();
            if (session?.user) {
                // Mapear usuario de supabase
                setUser({
                    id: session.user.id,
                    email: session.user.email || '',
                    name: session.user.user_metadata?.full_name || 'Usuario',
                    avatarUrl: session.user.user_metadata?.avatar_url || DEFAULT_USER.avatarUrl
                });
            }
            setIsLoading(false);
            
            supabase.auth.onAuthStateChange((_event, session) => {
                if (session?.user) {
                    setUser({
                        id: session.user.id,
                        email: session.user.email || '',
                        name: session.user.user_metadata?.full_name || 'Usuario',
                        avatarUrl: session.user.user_metadata?.avatar_url || DEFAULT_USER.avatarUrl
                    });
                } else {
                    setUser(null);
                }
                setIsLoading(false);
            });
        };
        initSupabaseAuth();
    } else {
        // MODO DEMO: Ya leímos el localStorage en el useState inicial.
        // Simplemente marcamos que ya no estamos cargando.
        setIsLoading(false);
    }
  }, []);

  // --- ACCIONES MANUALES ---
  // Ya no usamos useEffect([user]) para guardar, porque puede causar borrados accidentales.
  // Ahora guardamos explícitamente en login() y borramos explícitamente en logout().

  const login = async (email: string, password: string) => {
    if (isSupabaseConfigured && supabase) {
      setIsLoading(true);
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      setIsLoading(false);
      return { error: error?.message || null };
    } else {
      // MODO DEMO
      // Pequeña espera para realismo, pero segura
      await new Promise(resolve => setTimeout(resolve, 500));
      
      if (email && password) {
          const newUser = { ...DEFAULT_USER, email };
          
          // GUARDADO EXPLÍCITO Y SEGURO
          localStorage.setItem(SESSION_KEY, JSON.stringify(newUser));
          setUser(newUser);
          
          return { error: null };
      }
      return { error: "Credenciales inválidas" };
    }
  };

  const register = async (email: string, password: string, fullName: string) => {
    if (isSupabaseConfigured && supabase) {
      setIsLoading(true);
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { full_name: fullName } }
      });
      setIsLoading(false);
      return { error: error?.message || null };
    } else {
      await new Promise(resolve => setTimeout(resolve, 500));
      const newUser = { ...DEFAULT_USER, name: fullName, email };
      
      // GUARDADO EXPLÍCITO
      localStorage.setItem(SESSION_KEY, JSON.stringify(newUser));
      setUser(newUser);
      
      return { error: null };
    }
  };

  const logout = async () => {
    if (isSupabaseConfigured && supabase) {
      await supabase.auth.signOut();
    }
    
    // BORRADO EXPLÍCITO
    localStorage.removeItem(SESSION_KEY);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      isAuthenticated: !!user, 
      isLoading, 
      login, 
      register, 
      logout, 
      isDemoMode: !isSupabaseConfigured 
    }}>
      {children}
    </AuthContext.Provider>
  );
};
