import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'es' | 'pt' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  formatCurrency: (amount: number) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// --- DICCIONARIO DE TRADUCCIONES ---
const TRANSLATIONS: Record<Language, Record<string, string>> = {
  es: {
    'nav.dashboard': 'Panel de Control',
    'nav.commercial': 'Comercial',
    'nav.quote': 'Cotizador IA',
    'nav.docs': 'Documentación',
    'nav.ops': 'Operaciones',
    'nav.fleet': 'Gestión de Flota',
    'nav.comms': 'Comunicaciones',
    'nav.crew': 'Tripulación & Safety',
    'nav.map': 'Mapa de Flota',
    'nav.inventory': 'Pañol Digital',
    'nav.fuel': 'Combustible',
    'nav.maintenance': 'Mantenimiento',
    'nav.trips': 'Gestión de Viajes',
    'nav.env': 'Entorno',
    'nav.weather': 'Hidrología & Clima',
    'nav.incidents': 'Centro de Incidentes',
    'nav.integrations': 'Integraciones',
    'nav.settings': 'Configuración',
    'nav.logout': 'Cerrar Sesión',
    'search.placeholder': 'Buscar flota, tripulación, viajes...',
    'status.operational': 'OPERATIVO',
    'status.maintenance': 'MANTENIMIENTO',
    'status.transit': 'EN RUTA',
  },
  pt: {
    'nav.dashboard': 'Painel de Controle',
    'nav.commercial': 'Comercial',
    'nav.quote': 'Cotação IA',
    'nav.docs': 'Documentação',
    'nav.ops': 'Operações',
    'nav.fleet': 'Gestão da Frota',
    'nav.comms': 'Comunicações',
    'nav.crew': 'Tripulação & Safety',
    'nav.map': 'Mapa da Frota',
    'nav.inventory': 'Almoxarifado',
    'nav.fuel': 'Combustível',
    'nav.maintenance': 'Manutenção',
    'nav.trips': 'Gestão de Viagens',
    'nav.env': 'Meio Ambiente',
    'nav.weather': 'Hidrologia & Clima',
    'nav.incidents': 'Centro de Incidentes',
    'nav.integrations': 'Integrações',
    'nav.settings': 'Configurações',
    'nav.logout': 'Sair',
    'search.placeholder': 'Buscar frota, tripulação, viagens...',
    'status.operational': 'OPERACIONAL',
    'status.maintenance': 'MANUTENÇÃO',
    'status.transit': 'EM TRÂNSITO',
  },
  en: {
    'nav.dashboard': 'Dashboard',
    'nav.commercial': 'Commercial',
    'nav.quote': 'AI Quoter',
    'nav.docs': 'Documentation',
    'nav.ops': 'Operations',
    'nav.fleet': 'Fleet Management',
    'nav.comms': 'Communications',
    'nav.crew': 'Crew & Safety',
    'nav.map': 'Fleet Map',
    'nav.inventory': 'Digital Stores',
    'nav.fuel': 'Bunkers',
    'nav.maintenance': 'Maintenance',
    'nav.trips': 'Voyage Management',
    'nav.env': 'Environment',
    'nav.weather': 'Hydrology & Weather',
    'nav.incidents': 'Incident Center',
    'nav.integrations': 'Integrations',
    'nav.settings': 'Settings',
    'nav.logout': 'Sign Out',
    'search.placeholder': 'Search fleet, crew, trips...',
    'status.operational': 'OPERATIONAL',
    'status.maintenance': 'MAINTENANCE',
    'status.transit': 'IN TRANSIT',
  }
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('es');

  // Load saved language preference
  useEffect(() => {
    const saved = localStorage.getItem('aqua_lang') as Language;
    if (saved) setLanguage(saved);
  }, []);

  const changeLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('aqua_lang', lang);
  };

  const t = (key: string): string => {
    return TRANSLATIONS[language][key] || key;
  };

  const formatCurrency = (amount: number) => {
      const locale = language === 'pt' ? 'pt-BR' : language === 'en' ? 'en-US' : 'es-AR';
      const currency = language === 'pt' ? 'BRL' : 'USD'; // Simplified logic: Brazil sees Reais, others see USD
      return new Intl.NumberFormat(locale, { style: 'currency', currency: currency }).format(amount);
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: changeLanguage, t, formatCurrency }}>
      {children}
    </LanguageContext.Provider>
  );
};