
const WebSocket = require('ws');

// ==========================================
// CONFIGURACIÓN DE ACCESO
// ==========================================
// 1. Ve a https://aisstream.io/
// 2. Regístrate y copia tu API Key.
// 3. Pégala abajo entre las comillas.
const API_KEY = "TU_API_KEY_DE_AISSTREAM"; 

const LOCAL_PORT = 8080;

// Zona: Hidrovía Paraguay-Paraná (Aprox)
const BOUNDING_BOXES = [
    [[-20.0, -62.0], [-35.0, -55.0]] 
];

// ==========================================
// SERVIDOR PROXY
// ==========================================
const wss = new WebSocket.Server({ port: LOCAL_PORT });

console.log(`\n==================================================`);
console.log(`🚀 Proxy AIS Local iniciado en ws://localhost:${LOCAL_PORT}`);
console.log(`   Esperando conexión desde AquaFleet...`);
console.log(`==================================================\n`);

wss.on('connection', (clientWs) => {
    console.log("📍 Mapa conectado. Iniciando enlace satelital...");

    if (API_KEY === "TU_API_KEY_DE_AISSTREAM") {
        console.error("❌ ERROR: No has configurado tu API KEY en proxy.js");
        clientWs.send(JSON.stringify({ error: "API_KEY_MISSING" }));
        clientWs.close();
        return;
    }

    const aisSocket = new WebSocket('wss://stream.aisstream.io/v0/stream');

    aisSocket.on('open', () => {
        console.log("mn   🛰️  Conexión establecida con AISStream.io");
        
        const subscriptionMessage = {
            APIKey: API_KEY,
            BoundingBoxes: BOUNDING_BOXES,
            FilterMessageTypes: ["PositionReport"],
            FilterMessageFormat: "PositionReport" 
        };
        
        aisSocket.send(JSON.stringify(subscriptionMessage));
    });

    aisSocket.on('message', (data) => {
        // Reenviar datos crudos al navegador sin procesar para velocidad
        if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(data);
        }
    });

    aisSocket.on('error', (err) => {
        console.error("❌ Error en socket AISStream:", err.message);
        clientWs.close();
    });

    aisSocket.on('close', () => {
        console.log("⚠️  Conexión AISStream cerrada. Cerrando cliente...");
        clientWs.close();
    });

    clientWs.on('close', () => {
        console.log("🔌 Mapa desconectado. Deteniendo flujo de datos.");
        if (aisSocket.readyState === WebSocket.OPEN) {
            aisSocket.close();
        }
    });
});
