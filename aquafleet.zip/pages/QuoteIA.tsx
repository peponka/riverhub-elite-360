import React, { useState, useEffect, useRef } from 'react';

const QuoteIA: React.FC = () => {
  const [mode, setMode] = useState<'ai' | 'manual'>('ai');
  const [isCalculating, setIsCalculating] = useState(false);
  
  // Estado para controlar qué input está activo y mostrando sugerencias
  const [activeField, setActiveField] = useState<string | null>(null);

  // Referencia para detectar clics fuera
  const componentRef = useRef<HTMLDivElement>(null);

  // --- LISTA MAESTRA DE PUERTOS (Sugerencias) ---
  const COMMON_PORTS = [
      "Asunción (PY)", 
      "Rosario (ARG)", 
      "Nueva Palmira (URU)", 
      "Buenos Aires (ARG)",
      "Montevideo (URU)",
      "Villeta (PY)", 
      "Pilar (PY)",
      "San Lorenzo (ARG)", 
      "Campana (ARG)",
      "Corumbá (BRA)", 
      "Puerto Cáceres (BRA)", 
      "Porto Murtinho (BRA)",
      "Vallemí (PY)", 
      "Concepción (PY)", 
      "Santos (BRA)", 
      "Paranaguá (BRA)",
      "Santa Fe (ARG)",
      "Diamante (ARG)",
      "San Nicolás (ARG)", 
      "Zárate (ARG)", 
      "Dock Sud (ARG)"
  ].sort(); 

  // --- AI PARAMETERS ---
  const [aiParams, setAiParams] = useState({
      origin: 'Asunción (PY)',
      destination: 'Rosario (ARG)',
      tonnage: 15000,
      riverLevel: 3.45,
      bunkerPrice: 1.12,
      marketTrend: 'stable'
  });

  // --- MANUAL PARAMETERS ---
  const [manualParams, setManualParams] = useState({
      origin: '', 
      destination: '',
      dailyHire: 2500,
      tripDays: 12,
      fuelConsumption: 40000,
      fuelPrice: 1.12,
      portDues: 15000,
      otherCosts: 2000,
      targetMargin: 20
  });

  const [result, setResult] = useState({
      price: 0,
      ratePerTon: 0,
      days: 0,
      precision: 0,
      marketComparison: 'avg',
      costBreakdown: { fuel: 0, ops: 0, margin: 0, fees: 0 }
  });

  // --- AUTOCOMPLETE LOGIC ---

  // Efecto para cerrar el dropdown si se hace clic fuera
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        // Si el clic no fue dentro del componente o en un input activo, cerramos
        if (componentRef.current && !componentRef.current.contains(event.target as Node)) {
            setActiveField(null);
        } else {
             // Si hicimos clic en algo que NO es un input ni la lista, cerramos también
             const target = event.target as HTMLElement;
             if (target.tagName !== 'INPUT' && !target.closest('ul')) {
                 setActiveField(null);
             }
        }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getFilteredPorts = (query: string) => {
      if (!query) return COMMON_PORTS;
      return COMMON_PORTS.filter(port => 
          port.toLowerCase().includes(query.toLowerCase())
      );
  };

  const handleSelectPort = (port: string, field: 'origin' | 'destination', modeType: 'ai' | 'manual') => {
      if (modeType === 'ai') {
          setAiParams(prev => ({ ...prev, [field]: port }));
      } else {
          setManualParams(prev => ({ ...prev, [field]: port }));
      }
      setActiveField(null); // Cierra el dropdown inmediatamente
  };

  // --- CALCULATION LOGIC ---

  const handleCalculateAI = () => {
      setIsCalculating(true);
      
      setTimeout(() => {
          // Lógica Mock adaptada a entradas libres
          const baseRate = 22; 
          
          let distanceFactor = 1.0;
          const destLower = aiParams.destination.toLowerCase();
          if (destLower.includes('palmira') || destLower.includes('montevideo') || destLower.includes('buenos aires')) distanceFactor = 1.3;
          if (destLower.includes('corumbá') || destLower.includes('cáceres')) distanceFactor = 1.4;

          const riverPenalty = aiParams.riverLevel < 1.5 ? 1.4 : aiParams.riverLevel < 2.5 ? 1.15 : 1.0;
          const bunkerImpact = aiParams.bunkerPrice * 0.8;
          
          const calculatedRate = (baseRate * distanceFactor * riverPenalty) + bunkerImpact;
          const total = Math.floor(calculatedRate * aiParams.tonnage);

          const marketComp = Math.random() > 0.6 ? 'high' : Math.random() > 0.3 ? 'avg' : 'low';

          setResult({
              price: total,
              ratePerTon: parseFloat(calculatedRate.toFixed(2)),
              days: Math.floor(10 * distanceFactor), 
              precision: aiParams.riverLevel > 3 ? 98 : 82,
              marketComparison: marketComp,
              costBreakdown: { fuel: 0, ops: 0, margin: 0, fees: 0 }
          });
          setIsCalculating(false);
      }, 1500);
  };

  const handleCalculateManual = () => {
      setIsCalculating(true);

      setTimeout(() => {
          const operationalCost = manualParams.dailyHire * manualParams.tripDays;
          const fuelCost = manualParams.fuelConsumption * manualParams.fuelPrice;
          const feesCost = manualParams.portDues + manualParams.otherCosts;
          const totalCost = operationalCost + fuelCost + feesCost;
          const marginAmount = totalCost * (manualParams.targetMargin / 100);
          const totalPrice = totalCost + marginAmount;
          
          const estimatedTonnage = aiParams.tonnage || 10000; 

          setResult({
              price: Math.floor(totalPrice),
              ratePerTon: parseFloat((totalPrice / estimatedTonnage).toFixed(2)),
              days: manualParams.tripDays,
              precision: 100,
              marketComparison: 'avg',
              costBreakdown: {
                  fuel: Math.round((fuelCost / totalPrice) * 100),
                  ops: Math.round((operationalCost / totalPrice) * 100),
                  fees: Math.round((feesCost / totalPrice) * 100),
                  margin: Math.round((marginAmount / totalPrice) * 100),
              }
          });
          setIsCalculating(false);
      }, 800);
  };

  return (
    <div className="animate-fade-in space-y-6" ref={componentRef}>
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
                 <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
                    <span className="p-2 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg text-white material-symbols-outlined">
                        {mode === 'ai' ? 'smart_toy' : 'calculate'}
                    </span>
                    Cotizador Inteligente
                 </h1>
                 <p className="text-slate-500 dark:text-[#9db2b9] mt-1 ml-1">
                    {mode === 'ai' ? 'ESTRATEGIA DE MERCADO • MOTOR GEMINI' : 'CÁLCULO DE COSTOS DIRECTOS • MANUAL'}
                 </p>
            </div>
            <div className="flex bg-slate-200 dark:bg-surface-dark p-1 rounded-lg">
                <button 
                    onClick={() => setMode('ai')}
                    className={`px-4 py-2 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${mode === 'ai' ? 'bg-white dark:bg-slate-700 text-primary shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-white'}`}
                >
                    <span className="material-symbols-outlined text-[18px]">auto_awesome</span> IA Automática
                </button>
                <button 
                    onClick={() => setMode('manual')}
                    className={`px-4 py-2 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${mode === 'manual' ? 'bg-white dark:bg-slate-700 text-primary shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-white'}`}
                >
                    <span className="material-symbols-outlined text-[18px]">edit_note</span> Manual
                </button>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* --- INPUT PANEL --- */}
            <div className={`lg:col-span-5 border border-slate-200 dark:border-border-dark rounded-2xl p-6 shadow-xl relative overflow-visible transition-colors duration-500 ${mode === 'ai' ? 'bg-slate-900 dark:bg-surface-dark' : 'bg-white dark:bg-surface-dark'}`}>
                
                {/* Background Decoration */}
                <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none overflow-hidden h-full w-full">
                    <span className={`material-symbols-outlined text-9xl absolute -right-4 -top-4 ${mode === 'ai' ? 'text-white' : 'text-slate-900 dark:text-white'}`}>
                        {mode === 'ai' ? 'psychology' : 'functions'}
                    </span>
                </div>

                <h3 className={`font-bold text-sm uppercase tracking-widest mb-6 ${mode === 'ai' ? 'text-white' : 'text-slate-500 dark:text-slate-400'}`}>
                    {mode === 'ai' ? 'Parámetros de Mercado' : 'Estructura de Costos'}
                </h3>
                
                {/* --- AI FORM --- */}
                {mode === 'ai' && (
                    <div className="space-y-6 relative z-10 animate-fade-in">
                        <div className="grid grid-cols-2 gap-4">
                            {/* AI ORIGIN */}
                            <div className="flex flex-col gap-2 relative">
                                <label className="text-xs font-bold text-slate-400 uppercase">Origen</label>
                                <div className="relative">
                                    <input 
                                        type="text"
                                        placeholder="Escribe o selecciona..."
                                        value={aiParams.origin}
                                        onChange={e => setAiParams({...aiParams, origin: e.target.value})}
                                        onFocus={() => setActiveField('ai-origin')}
                                        className="bg-slate-800 border-slate-700 text-white rounded-lg px-4 py-3 outline-none focus:ring-2 focus:ring-primary font-medium w-full"
                                        autoComplete="off"
                                    />
                                    {activeField === 'ai-origin' && (
                                        <ul className="absolute left-0 top-full mt-1 w-full bg-slate-800 border border-slate-700 rounded-lg shadow-xl max-h-60 overflow-y-auto z-50 animate-fade-in">
                                            {getFilteredPorts(aiParams.origin).map((port, idx) => (
                                                <li 
                                                    key={idx}
                                                    onClick={() => handleSelectPort(port, 'origin', 'ai')}
                                                    className="px-4 py-2 hover:bg-slate-700 text-slate-200 cursor-pointer text-sm border-b border-slate-700/50 last:border-0 transition-colors"
                                                >
                                                    {port}
                                                </li>
                                            ))}
                                            {getFilteredPorts(aiParams.origin).length === 0 && (
                                                <li className="px-4 py-2 text-slate-500 text-xs italic">Presiona Enter para usar personalizado</li>
                                            )}
                                        </ul>
                                    )}
                                </div>
                            </div>

                            {/* AI DESTINATION */}
                            <div className="flex flex-col gap-2 relative">
                                <label className="text-xs font-bold text-slate-400 uppercase">Destino</label>
                                <div className="relative">
                                    <input 
                                        type="text"
                                        placeholder="Escribe o selecciona..."
                                        value={aiParams.destination}
                                        onChange={e => setAiParams({...aiParams, destination: e.target.value})}
                                        onFocus={() => setActiveField('ai-destination')}
                                        className="bg-slate-800 border-slate-700 text-white rounded-lg px-4 py-3 outline-none focus:ring-2 focus:ring-primary font-medium w-full"
                                        autoComplete="off"
                                    />
                                    {activeField === 'ai-destination' && (
                                        <ul className="absolute left-0 top-full mt-1 w-full bg-slate-800 border border-slate-700 rounded-lg shadow-xl max-h-60 overflow-y-auto z-50 animate-fade-in">
                                            {getFilteredPorts(aiParams.destination).map((port, idx) => (
                                                <li 
                                                    key={idx}
                                                    onClick={() => handleSelectPort(port, 'destination', 'ai')}
                                                    className="px-4 py-2 hover:bg-slate-700 text-slate-200 cursor-pointer text-sm border-b border-slate-700/50 last:border-0 transition-colors"
                                                >
                                                    {port}
                                                </li>
                                            ))}
                                            {getFilteredPorts(aiParams.destination).length === 0 && (
                                                <li className="px-4 py-2 text-slate-500 text-xs italic">Presiona Enter para usar personalizado</li>
                                            )}
                                        </ul>
                                    )}
                                </div>
                            </div>
                        </div>

                        <div className="flex flex-col gap-2">
                            <label className="text-xs font-bold text-slate-400 uppercase">Volumen (Toneladas)</label>
                            <input 
                                type="number" 
                                value={aiParams.tonnage}
                                onChange={e => setAiParams({...aiParams, tonnage: Number(e.target.value)})}
                                className="bg-slate-800 border-slate-700 text-white rounded-lg px-4 py-3 outline-none focus:ring-2 focus:ring-primary font-mono text-lg" 
                            />
                        </div>

                        <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
                            <div className="flex justify-between text-xs font-bold text-slate-400 mb-2 uppercase">
                                <span>Nivel de Río (Simulado)</span>
                                <span className="text-primary">{aiParams.riverLevel}m</span>
                            </div>
                            <input 
                                type="range" 
                                min="0.5" max="6.0" step="0.05"
                                value={aiParams.riverLevel}
                                onChange={e => setAiParams({...aiParams, riverLevel: Number(e.target.value)})}
                                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-primary" 
                            />
                            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                                <span>Crítico</span>
                                <span>Óptimo</span>
                            </div>
                        </div>

                        <div className="flex flex-col gap-2">
                            <label className="text-xs font-bold text-slate-400 uppercase">Precio Búnker (USD/L)</label>
                            <input 
                                type="number" step="0.01"
                                value={aiParams.bunkerPrice}
                                onChange={e => setAiParams({...aiParams, bunkerPrice: Number(e.target.value)})}
                                className="bg-slate-800 border-slate-700 text-emerald-400 rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-emerald-500 font-mono" 
                            />
                        </div>

                        <div className="pt-4">
                            <button 
                                onClick={handleCalculateAI}
                                disabled={isCalculating}
                                className="w-full py-4 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl font-bold text-white shadow-lg shadow-primary/20 flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-70 disabled:cursor-wait"
                            >
                                {isCalculating ? (
                                    <>
                                        <span className="size-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                                        ANALIZANDO MERCADO...
                                    </>
                                ) : (
                                    <>
                                        <span className="material-symbols-outlined">auto_awesome</span>
                                        CALCULAR CON IA
                                    </>
                                )}
                            </button>
                        </div>
                    </div>
                )}

                {/* --- MANUAL FORM --- */}
                {mode === 'manual' && (
                    <div className="space-y-5 relative z-10 animate-fade-in">
                        {/* Hybrid Inputs for Manual Mode */}
                         <div className="grid grid-cols-2 gap-4">
                            {/* MANUAL ORIGIN */}
                            <div className="flex flex-col gap-2 relative">
                                <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase">Origen</label>
                                <div className="relative">
                                    <input 
                                        type="text"
                                        placeholder="Ej. Santos"
                                        value={manualParams.origin}
                                        onChange={e => setManualParams({...manualParams, origin: e.target.value})}
                                        onFocus={() => setActiveField('manual-origin')}
                                        className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-primary font-medium w-full"
                                        autoComplete="off"
                                    />
                                    {activeField === 'manual-origin' && (
                                        <ul className="absolute left-0 top-full mt-1 w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xl max-h-60 overflow-y-auto z-50 animate-fade-in">
                                            {getFilteredPorts(manualParams.origin).map((port, idx) => (
                                                <li 
                                                    key={idx}
                                                    onClick={() => handleSelectPort(port, 'origin', 'manual')}
                                                    className="px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 cursor-pointer text-sm border-b border-slate-100 dark:border-slate-700/50 last:border-0 transition-colors"
                                                >
                                                    {port}
                                                </li>
                                            ))}
                                        </ul>
                                    )}
                                </div>
                            </div>

                            {/* MANUAL DESTINATION */}
                            <div className="flex flex-col gap-2 relative">
                                <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase">Destino</label>
                                <div className="relative">
                                    <input 
                                        type="text"
                                        placeholder="Ej. Rotterdam"
                                        value={manualParams.destination}
                                        onChange={e => setManualParams({...manualParams, destination: e.target.value})}
                                        onFocus={() => setActiveField('manual-destination')}
                                        className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-primary font-medium w-full"
                                        autoComplete="off"
                                    />
                                    {activeField === 'manual-destination' && (
                                        <ul className="absolute left-0 top-full mt-1 w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xl max-h-60 overflow-y-auto z-50 animate-fade-in">
                                            {getFilteredPorts(manualParams.destination).map((port, idx) => (
                                                <li 
                                                    key={idx}
                                                    onClick={() => handleSelectPort(port, 'destination', 'manual')}
                                                    className="px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 cursor-pointer text-sm border-b border-slate-100 dark:border-slate-700/50 last:border-0 transition-colors"
                                                >
                                                    {port}
                                                </li>
                                            ))}
                                        </ul>
                                    )}
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="flex flex-col gap-2">
                                <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase">Hire Diario (USD)</label>
                                <input 
                                    type="number"
                                    value={manualParams.dailyHire}
                                    onChange={e => setManualParams({...manualParams, dailyHire: Number(e.target.value)})}
                                    className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-primary font-mono"
                                />
                            </div>
                            <div className="flex flex-col gap-2">
                                <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase">Días Viaje</label>
                                <input 
                                    type="number"
                                    value={manualParams.tripDays}
                                    onChange={e => setManualParams({...manualParams, tripDays: Number(e.target.value)})}
                                    className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-primary font-mono"
                                />
                            </div>
                        </div>

                        <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
                            <h4 className="text-xs font-bold text-primary mb-3 uppercase flex items-center gap-1">
                                <span className="material-symbols-outlined text-sm">local_gas_station</span> Combustible
                            </h4>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-[10px] text-slate-500 uppercase block mb-1">Consumo Total (L)</label>
                                    <input 
                                        type="number"
                                        value={manualParams.fuelConsumption}
                                        onChange={e => setManualParams({...manualParams, fuelConsumption: Number(e.target.value)})}
                                        className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded px-2 py-1.5 text-sm dark:text-white"
                                    />
                                </div>
                                <div>
                                    <label className="text-[10px] text-slate-500 uppercase block mb-1">Precio (USD/L)</label>
                                    <input 
                                        type="number" step="0.01"
                                        value={manualParams.fuelPrice}
                                        onChange={e => setManualParams({...manualParams, fuelPrice: Number(e.target.value)})}
                                        className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded px-2 py-1.5 text-sm dark:text-white"
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="flex flex-col gap-2">
                                <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase">Gastos Puerto</label>
                                <input 
                                    type="number"
                                    value={manualParams.portDues}
                                    onChange={e => setManualParams({...manualParams, portDues: Number(e.target.value)})}
                                    className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-primary font-mono"
                                />
                            </div>
                            <div className="flex flex-col gap-2">
                                <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase">Margen (%)</label>
                                <input 
                                    type="number"
                                    value={manualParams.targetMargin}
                                    onChange={e => setManualParams({...manualParams, targetMargin: Number(e.target.value)})}
                                    className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-primary font-mono text-emerald-600 font-bold"
                                />
                            </div>
                        </div>

                        <div className="pt-4">
                            <button 
                                onClick={handleCalculateManual}
                                disabled={isCalculating}
                                className="w-full py-4 bg-slate-800 hover:bg-slate-700 dark:bg-white dark:hover:bg-slate-200 dark:text-slate-900 text-white rounded-xl font-bold shadow-lg flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-70 disabled:cursor-wait"
                            >
                                {isCalculating ? (
                                    <>
                                        <span className="size-5 border-2 border-slate-500 border-t-slate-900 rounded-full animate-spin"></span>
                                        CALCULANDO...
                                    </>
                                ) : (
                                    <>
                                        <span className="material-symbols-outlined">calculate</span>
                                        CALCULAR TARIFA
                                    </>
                                )}
                            </button>
                        </div>
                    </div>
                )}
            </div>

            {/* --- OUTPUT PANEL --- */}
            <div className="lg:col-span-7 flex flex-col gap-6">
                
                {/* Price Display */}
                <div className="bg-slate-900 dark:bg-surface-dark border border-slate-800 dark:border-border-dark rounded-2xl p-8 relative overflow-hidden shadow-2xl flex flex-col justify-center min-h-[300px]">
                    <h3 className="text-xs font-bold text-white uppercase tracking-widest mb-2 flex items-center gap-2">
                        <span className="material-symbols-outlined text-sm">payments</span> Precio Final de Empresa
                    </h3>
                    
                    <div className="flex items-baseline gap-2 relative z-10">
                        <span className="text-4xl text-slate-500 font-bold">USD</span>
                        <span className={`text-7xl md:text-8xl font-black text-white tracking-tighter tabular-nums ${isCalculating ? 'animate-pulse opacity-50' : ''}`}>
                            {result.price > 0 ? result.price.toLocaleString('es-PY') : '---'}
                        </span>
                    </div>

                    <div className="absolute top-8 right-8 text-right">
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-wide">Tarifa x Tonelada</p>
                        <div className="text-2xl font-bold text-white border border-white/20 px-3 py-1 rounded-lg mt-1 inline-block bg-white/5 backdrop-blur tabular-nums">
                            $ {result.ratePerTon > 0 ? result.ratePerTon.toFixed(2) : '--.--'}
                        </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mt-12">
                         {mode === 'ai' ? (
                            <>
                                <div className="bg-slate-800/50 p-4 rounded-xl flex items-center gap-3">
                                    <div className="bg-blue-500/20 p-2 rounded-full text-blue-400"><span className="material-symbols-outlined">schedule</span></div>
                                    <div>
                                        <p className="text-[10px] text-slate-400 uppercase font-bold">Tránsito Est.</p>
                                        <p className="text-xl font-bold text-white">{result.days} Días</p>
                                    </div>
                                </div>
                                <div className="bg-slate-800/50 p-4 rounded-xl flex items-center gap-3">
                                    <div className="bg-emerald-500/20 p-2 rounded-full text-emerald-400"><span className="material-symbols-outlined">verified</span></div>
                                    <div>
                                        <p className="text-[10px] text-slate-400 uppercase font-bold">Confianza IA</p>
                                        <p className="text-xl font-bold text-white">{result.precision}%</p>
                                    </div>
                                </div>
                                <div className="bg-slate-800/50 p-4 rounded-xl flex items-center gap-3">
                                    <div className={`p-2 rounded-full ${result.marketComparison === 'low' ? 'bg-emerald-500/20 text-emerald-400' : result.marketComparison === 'high' ? 'bg-red-500/20 text-red-400' : 'bg-blue-500/20 text-blue-400'}`}>
                                        <span className="material-symbols-outlined">query_stats</span>
                                    </div>
                                    <div>
                                        <p className="text-[10px] text-slate-400 uppercase font-bold">Vs. Mercado</p>
                                        <p className="text-sm font-bold text-white uppercase">
                                            {result.marketComparison === 'low' ? 'Muy Competitivo' : result.marketComparison === 'high' ? 'Por Encima' : 'Promedio'}
                                        </p>
                                    </div>
                                </div>
                            </>
                         ) : (
                             // Manual Mode Stats (Simple Breakdown)
                             <div className="col-span-3 bg-slate-800/50 p-4 rounded-xl">
                                 <p className="text-[10px] text-slate-400 uppercase font-bold mb-2">Composición del Costo</p>
                                 <div className="flex h-4 w-full rounded-full overflow-hidden mb-2">
                                     <div style={{width: `${result.costBreakdown.fuel}%`}} className="bg-orange-500" title="Combustible"></div>
                                     <div style={{width: `${result.costBreakdown.ops}%`}} className="bg-blue-500" title="Operativo"></div>
                                     <div style={{width: `${result.costBreakdown.fees}%`}} className="bg-slate-500" title="Puerto"></div>
                                     <div style={{width: `${result.costBreakdown.margin}%`}} className="bg-emerald-500" title="Margen"></div>
                                 </div>
                                 <div className="flex justify-between text-xs text-slate-300">
                                     <span className="flex items-center gap-1"><div className="size-2 rounded-full bg-orange-500"></div> Combustible ({result.costBreakdown.fuel}%)</span>
                                     <span className="flex items-center gap-1"><div className="size-2 rounded-full bg-blue-500"></div> Operativo ({result.costBreakdown.ops}%)</span>
                                     <span className="flex items-center gap-1"><div className="size-2 rounded-full bg-emerald-500"></div> Margen ({result.costBreakdown.margin}%)</span>
                                 </div>
                             </div>
                         )}
                    </div>
                </div>

                {/* Argumentation / Actions */}
                <div className="bg-slate-800/50 dark:bg-surface-darker/50 border border-slate-700/50 dark:border-border-dark rounded-2xl p-6 flex-1 flex flex-col">
                    <div className="flex justify-between items-center mb-4">
                         <h3 className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-2">
                            <span className="material-symbols-outlined text-sm">description</span> 
                            {mode === 'ai' ? 'Argumentación Comercial' : 'Detalle Técnico'}
                         </h3>
                         <button className="text-xs font-bold text-slate-400 hover:text-white flex items-center gap-1">
                             <span className="material-symbols-outlined text-sm">lock</span> BLOQUEAR PRECIO
                         </button>
                    </div>
                    
                    <div className="relative pl-8 italic text-slate-400 text-lg leading-relaxed flex-1">
                        <span className="absolute left-0 top-0 text-6xl text-slate-600 font-serif opacity-30">“</span>
                        {result.price === 0 ? 'Esperando cálculo...' : 
                         mode === 'ai' 
                         ? `Cotización optimizada para la ruta ${aiParams.origin} - ${aiParams.destination}, considerando el nivel actual del río (${aiParams.riverLevel}m). Incluye recargo por búnker ajustado. El precio sugerido es ${result.marketComparison === 'low' ? 'altamente competitivo' : 'estándar'} para cerrar el contrato esta semana.`
                         : `Cálculo de costos para tramo ${manualParams.origin} a ${manualParams.destination} basado en ${manualParams.tripDays} días de viaje y consumo estimado de ${manualParams.fuelConsumption.toLocaleString()} litros. El margen del ${manualParams.targetMargin}% está asegurado.`
                        }
                    </div>

                    <div className="flex gap-4 mt-6 pt-6 border-t border-slate-700/50">
                        <button className="flex-1 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-lg font-bold flex items-center justify-center gap-2 transition-colors">
                            <span className="material-symbols-outlined">picture_as_pdf</span> PDF FORMAL
                        </button>
                        <button className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold flex items-center justify-center gap-2 transition-colors shadow-lg shadow-emerald-500/20">
                            <span className="material-symbols-outlined">send</span> ENVIAR PRECIO EMPRESA
                        </button>
                    </div>
                </div>

            </div>
        </div>
    </div>
  );
};

export default QuoteIA;