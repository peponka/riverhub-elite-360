import React from 'react';

const Incidents: React.FC = () => {
    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex justify-between items-end">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Incidentes y Seguridad</h1>
                    <p className="text-slate-500 dark:text-[#9db2b9] mt-1">Sistema de Gestión de Seguridad (SMS) y reporte de novedades.</p>
                </div>
                <button className="bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-lg font-bold shadow-lg shadow-red-500/20 flex items-center gap-2">
                    <span className="material-symbols-outlined">warning</span> Reportar Incidente
                </button>
            </div>

            {/* Alert Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                 <div className="bg-red-50 dark:bg-red-900/10 border border-red-200 dark:border-red-800 p-4 rounded-xl flex items-start gap-4">
                    <div className="bg-red-500 text-white p-2 rounded-lg"><span className="material-symbols-outlined">priority_high</span></div>
                    <div>
                        <h3 className="font-bold text-red-700 dark:text-red-400">1 Incidente Abierto</h3>
                        <p className="text-xs text-red-600/80 dark:text-red-300">Requiere investigación inmediata.</p>
                    </div>
                 </div>
                 <div className="bg-orange-50 dark:bg-orange-900/10 border border-orange-200 dark:border-orange-800 p-4 rounded-xl flex items-start gap-4">
                    <div className="bg-orange-500 text-white p-2 rounded-lg"><span className="material-symbols-outlined">rule</span></div>
                    <div>
                        <h3 className="font-bold text-orange-700 dark:text-orange-400">2 No Conformidades</h3>
                        <p className="text-xs text-orange-600/80 dark:text-orange-300">Auditoría interna Octubre.</p>
                    </div>
                 </div>
                 <div className="bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-200 dark:border-emerald-800 p-4 rounded-xl flex items-start gap-4">
                    <div className="bg-emerald-500 text-white p-2 rounded-lg"><span className="material-symbols-outlined">safety_check</span></div>
                    <div>
                        <h3 className="font-bold text-emerald-700 dark:text-emerald-400">350 Días Sin Accidentes</h3>
                        <p className="text-xs text-emerald-600/80 dark:text-emerald-300">Récord de flota actual.</p>
                    </div>
                 </div>
            </div>

            {/* Incident Log */}
            <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl overflow-hidden shadow-sm">
                 <div className="px-6 py-4 border-b border-slate-200 dark:border-border-dark bg-slate-50 dark:bg-surface-darker flex justify-between items-center">
                    <h3 className="font-bold text-slate-900 dark:text-white">Registro de Eventos</h3>
                    <div className="flex gap-2">
                        <select className="bg-white dark:bg-surface-dark border border-slate-300 dark:border-border-dark rounded-lg text-xs px-2 py-1 outline-none">
                            <option>Todos los Estados</option>
                            <option>Abierto</option>
                            <option>Cerrado</option>
                        </select>
                    </div>
                </div>
                <table className="w-full text-left text-sm">
                    <thead className="bg-slate-50 dark:bg-surface-darker text-slate-500 border-b border-slate-200 dark:border-border-dark">
                        <tr>
                            <th className="px-6 py-3">ID</th>
                            <th className="px-6 py-3">Título</th>
                            <th className="px-6 py-3">Embarcación</th>
                            <th className="px-6 py-3">Severidad</th>
                            <th className="px-6 py-3">Fecha</th>
                            <th className="px-6 py-3">Estado</th>
                            <th className="px-6 py-3">Acciones</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-border-dark">
                         <tr className="hover:bg-slate-50 dark:hover:bg-surface-darker/50">
                            <td className="px-6 py-4 font-mono text-xs text-slate-500">INC-2023-04</td>
                            <td className="px-6 py-4 font-bold text-slate-900 dark:text-white">Falla en sistema de gobierno</td>
                            <td className="px-6 py-4 text-slate-600 dark:text-slate-300">Remolcador Titan III</td>
                            <td className="px-6 py-4"><span className="bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400 px-2 py-0.5 rounded text-xs font-bold uppercase">Alta</span></td>
                            <td className="px-6 py-4 text-slate-600 dark:text-slate-300">2023-10-22</td>
                            <td className="px-6 py-4"><span className="flex items-center gap-1 text-orange-500 font-bold text-xs uppercase"><span className="size-2 bg-orange-500 rounded-full animate-pulse"></span> En Investigación</span></td>
                            <td className="px-6 py-4"><button className="text-primary hover:underline font-bold text-xs">Ver Informe</button></td>
                        </tr>
                        <tr className="hover:bg-slate-50 dark:hover:bg-surface-darker/50 opacity-75">
                            <td className="px-6 py-4 font-mono text-xs text-slate-500">INC-2023-03</td>
                            <td className="px-6 py-4 font-bold text-slate-900 dark:text-white">Derrame menor en cubierta</td>
                            <td className="px-6 py-4 text-slate-600 dark:text-slate-300">Barcaza T-55</td>
                            <td className="px-6 py-4"><span className="bg-yellow-100 text-yellow-600 dark:bg-yellow-900/30 dark:text-yellow-400 px-2 py-0.5 rounded text-xs font-bold uppercase">Media</span></td>
                            <td className="px-6 py-4 text-slate-600 dark:text-slate-300">2023-09-15</td>
                            <td className="px-6 py-4"><span className="text-emerald-500 font-bold text-xs uppercase">Cerrado</span></td>
                            <td className="px-6 py-4"><button className="text-slate-400 hover:text-primary font-bold text-xs">Archivado</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default Incidents;