
import React, { useState, useEffect } from 'react';

type Category = 'All' | 'Government' | 'Data' | 'Enterprise';

interface IntegrationItem {
    id: string;
    name: string;
    description: string;
    category: Category;
    icon: string;
    iconType: 'symbol' | 'text' | 'image';
    color: string;
    status: 'connected' | 'disconnected' | 'pending' | 'error';
    meta?: string;
}

const INTEGRATION_LIST: IntegrationItem[] = [
    // --- AUTORIDADES (Government) ---
    {
        id: 'pna',
        name: 'Prefectura Naval Argentina',
        description: 'Sincronización de Niveles de Río (Limnímetros) y Avisos.',
        category: 'Government',
        icon: 'security',
        iconType: 'symbol',
        color: 'bg-[#1e40af]', // Azul Prefectura
        status: 'connected',
        meta: 'Auto'
    },
    {
        id: 'pgn',
        name: 'Prefectura Gral. Naval (PY)',
        description: 'Conexión con VUE para despacho de buques.',
        category: 'Government',
        icon: 'anchor',
        iconType: 'symbol',
        color: 'bg-[#dc2626]', // Rojo
        status: 'pending',
        meta: 'Token Pendiente'
    },
    {
        id: 'ais',
        name: 'MarineTraffic / Spire',
        description: 'Telemetría satelital AIS de largo alcance.',
        category: 'Data',
        icon: 'satellite_alt',
        iconType: 'symbol',
        color: 'bg-slate-700',
        status: 'connected',
        meta: 'Ping: 2 min'
    },
    {
        id: 'sap',
        name: 'SAP ERP',
        description: 'Sincronización de facturación y stock.',
        category: 'Enterprise',
        icon: 'S',
        iconType: 'text',
        color: 'bg-[#0070ad]',
        status: 'connected',
        meta: 'ERP Corp.'
    },
];

const Integrations: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'providers' | 'clients'>('providers');
    
    // AISStream Key State
    const [aisKey, setAisKey] = useState('');
    const [keySaved, setKeySaved] = useState(false);

    useEffect(() => {
        const savedKey = localStorage.getItem('ais_key');
        if (savedKey) setAisKey(savedKey);
    }, []);

    const handleSaveAisKey = () => {
        if (aisKey.trim()) {
            localStorage.setItem('ais_key', aisKey.trim());
            setKeySaved(true);
            setTimeout(() => setKeySaved(false), 3000);
        }
    };

    return (
        <div className="animate-fade-in space-y-8">
            {/* Header Area */}
            <div className="flex flex-col gap-6">
                <h1 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">Centro de Conectividad API</h1>
                
                {/* Custom Tab Navigation matching screenshot */}
                <div className="flex flex-col md:flex-row md:items-center gap-4 border-b border-slate-200 dark:border-slate-800">
                    <div className="flex gap-6">
                        <button 
                            onClick={() => setActiveTab('providers')}
                            className={`pb-3 text-sm font-bold tracking-wide transition-all border-b-2 flex items-center gap-2 ${
                                activeTab === 'providers' 
                                ? 'text-primary border-primary' 
                                : 'text-slate-500 border-transparent hover:text-slate-300'
                            }`}
                        >
                            <span className="material-symbols-outlined text-[20px]">hub</span> 
                            CONECTAR PROVEEDORES
                        </button>
                        <button 
                            onClick={() => setActiveTab('clients')}
                            className={`pb-3 text-sm font-bold tracking-wide transition-all border-b-2 flex items-center gap-2 ${
                                activeTab === 'clients' 
                                ? 'text-primary border-primary' 
                                : 'text-slate-500 border-transparent hover:text-slate-300'
                            }`}
                        >
                            <span className="material-symbols-outlined text-[20px]">code</span>
                            MI API PARA CLIENTES
                        </button>
                    </div>
                    
                    <div className="ml-auto pb-2 hidden md:block">
                        <button className="bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold px-3 py-1.5 rounded flex items-center gap-2 transition-colors border border-slate-700 shadow-sm">
                            <span className="material-symbols-outlined text-[16px]">help</span> ¿CÓMO CONSIGO MIS LLAVES?
                        </button>
                    </div>
                </div>
            </div>

            {/* --- TAB: PROVEEDORES (Inputs) --- */}
            {activeTab === 'providers' && (
                <div className="space-y-8">
                    {/* Core Engines Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        
                        {/* AISStream Card (NEW) */}
                        <div className="bg-[#1e293b] dark:bg-[#0f1519] rounded-2xl border border-slate-800 shadow-xl flex flex-col group hover:border-slate-700 transition-colors relative overflow-hidden">
                            {/* Glow Effect */}
                            <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>
                            
                            <div className="p-6 flex-1">
                                <div className="size-12 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                                    <span className="material-symbols-outlined text-3xl">satellite_alt</span>
                                </div>
                                <h3 className="text-xl font-bold text-white mb-2">AIS Satelital (En Vivo)</h3>
                                <p className="text-slate-400 text-xs leading-relaxed font-medium mb-4">
                                    Conecta el mapa de la flota a la red satelital de AISStream.io para ver tráfico real.
                                </p>
                                
                                {/* Input Area */}
                                <div className="space-y-2 mt-auto">
                                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">TU API KEY</label>
                                    <div className="flex gap-2">
                                        <input 
                                            type="password" 
                                            value={aisKey}
                                            onChange={(e) => setAisKey(e.target.value)}
                                            placeholder="Pegar clave..."
                                            className="flex-1 bg-slate-900 border border-slate-700 text-white text-xs rounded-lg px-3 py-2 outline-none focus:border-purple-500 transition-colors placeholder-slate-600"
                                        />
                                        <button 
                                            onClick={handleSaveAisKey}
                                            className="bg-purple-600 hover:bg-purple-500 text-white px-3 py-2 rounded-lg text-xs font-bold transition-colors shadow-lg shadow-purple-500/20"
                                        >
                                            {keySaved ? <span className="material-symbols-outlined text-[16px]">check</span> : 'OK'}
                                        </button>
                                    </div>
                                    {keySaved && <p className="text-[10px] text-emerald-400 flex items-center gap-1 animate-fade-in"><span className="material-symbols-outlined text-[12px]">verified</span> Guardado localmente</p>}
                                </div>
                            </div>
                            <div className="bg-black/20 p-4 rounded-b-2xl flex justify-between items-center border-t border-slate-800/50">
                                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">GRATIS EN:</span>
                                <a href="https://aisstream.io/" target="_blank" rel="noreferrer" className="text-xs font-bold text-white flex items-center gap-1 hover:text-purple-400 transition-colors">
                                    AISStream.io <span className="material-symbols-outlined text-[14px]">open_in_new</span>
                                </a>
                            </div>
                        </div>

                        {/* Gemini Card */}
                        <div className="bg-[#1e293b] dark:bg-[#0f1519] rounded-2xl border border-slate-800 shadow-xl flex flex-col group hover:border-slate-700 transition-colors">
                            <div className="p-6 flex-1">
                                <div className="size-12 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                                    <span className="material-symbols-outlined text-3xl">psychology</span>
                                </div>
                                <h3 className="text-xl font-bold text-white mb-3">Motor de IA (Gemini)</h3>
                                <p className="text-slate-400 text-sm leading-relaxed font-medium">
                                    Esta llave es la más importante: hace que el "Capitán IA" piense y analice tus datos.
                                </p>
                            </div>
                            <div className="bg-black/20 p-4 rounded-b-2xl flex justify-between items-center border-t border-slate-800/50">
                                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">DÓNDE CONSEGUIRLA:</span>
                                <a href="https://aistudio.google.com/" target="_blank" rel="noreferrer" className="text-xs font-bold text-white flex items-center gap-1 hover:text-primary transition-colors">
                                    Google AI Studio <span className="material-symbols-outlined text-[14px]">open_in_new</span>
                                </a>
                            </div>
                        </div>

                        {/* OpenWeather Card */}
                        <div className="bg-[#1e293b] dark:bg-[#0f1519] rounded-2xl border border-slate-800 shadow-xl flex flex-col group hover:border-slate-700 transition-colors">
                            <div className="p-6 flex-1">
                                <div className="size-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                                    <span className="material-symbols-outlined text-3xl">cloud</span>
                                </div>
                                <h3 className="text-xl font-bold text-white mb-3">Clima y Satélites</h3>
                                <p className="text-slate-400 text-sm leading-relaxed font-medium">
                                    Necesaria para recibir alertas de tormentas reales y velocidad de viento en vivo sobre el río.
                                </p>
                            </div>
                            <div className="bg-black/20 p-4 rounded-b-2xl flex justify-between items-center border-t border-slate-800/50">
                                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">DÓNDE CONSEGUIRLA:</span>
                                <a href="#" className="text-xs font-bold text-white flex items-center gap-1 hover:text-primary transition-colors">
                                    OpenWeather Portal <span className="material-symbols-outlined text-[14px]">open_in_new</span>
                                </a>
                            </div>
                        </div>

                        {/* Hydro Card */}
                        <div className="bg-[#1e293b] dark:bg-[#0f1519] rounded-2xl border border-slate-800 shadow-xl flex flex-col group hover:border-slate-700 transition-colors">
                            <div className="p-6 flex-1">
                                <div className="size-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                                    <span className="material-symbols-outlined text-3xl">account_balance</span>
                                </div>
                                <h3 className="text-xl font-bold text-white mb-3">Hidrología y Puertos</h3>
                                <p className="text-slate-400 text-sm leading-relaxed font-medium">
                                    Para obtener el nivel del río real. Estos datos suelen ser públicos pero requieren una clave oficial.
                                </p>
                            </div>
                            <div className="bg-black/20 p-4 rounded-b-2xl flex justify-between items-center border-t border-slate-800/50">
                                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">ENLACE OFICIAL:</span>
                                <a href="#" className="text-xs font-bold text-white flex items-center gap-1 hover:text-primary transition-colors">
                                    Portal Hidrovía <span className="material-symbols-outlined text-[14px]">open_in_new</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    {/* Secondary Integrations List */}
                    <div>
                        <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                             <span className="material-symbols-outlined text-slate-400">extension</span>
                             Otras Integraciones Conectadas
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                             {INTEGRATION_LIST.map((item) => (
                                <div key={item.id} className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark p-4 rounded-xl flex items-center gap-3 shadow-sm">
                                    <div className={`size-10 rounded-lg flex items-center justify-center text-white font-bold ${item.color}`}>
                                        {item.iconType === 'text' ? item.icon : <span className="material-symbols-outlined text-lg">{item.icon}</span>}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="flex justify-between items-center mb-0.5">
                                            <h4 className="font-bold text-sm text-slate-900 dark:text-white truncate pr-2">{item.name}</h4>
                                            {item.status === 'connected' && <div className="size-2 rounded-full bg-emerald-500"></div>}
                                            {item.status === 'pending' && <div className="size-2 rounded-full bg-amber-500 animate-pulse"></div>}
                                        </div>
                                        <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{item.description}</p>
                                    </div>
                                </div>
                             ))}
                             <button className="border-2 border-dashed border-slate-300 dark:border-border-dark p-4 rounded-xl flex items-center justify-center gap-2 text-slate-500 hover:text-primary hover:border-primary hover:bg-slate-50 dark:hover:bg-surface-darker transition-all">
                                 <span className="material-symbols-outlined">add</span>
                                 <span className="text-sm font-bold">Agregar Nueva</span>
                             </button>
                        </div>
                    </div>
                </div>
            )}

            {/* --- TAB: CLIENTES (Outputs) --- */}
            {activeTab === 'clients' && (
                <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 min-h-[500px]">
                    {/* Left: Credentials (Screenshot 2 Match) */}
                    <div className="lg:col-span-3 bg-[#0f1519] rounded-2xl p-8 border border-slate-800 shadow-2xl flex flex-col justify-center relative overflow-hidden">
                        {/* Background Deco */}
                        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>

                        <h2 className="text-2xl font-bold text-white mb-4 relative z-10">Tus Credenciales RiverHub</h2>
                        <p className="text-slate-400 text-sm mb-8 leading-relaxed max-w-lg relative z-10">
                            Estas llaves son las que <strong className="text-slate-200">tú generas</strong> para que tus clientes (como cargadores o puertos) puedan ver tus barcos en sus propios sistemas.
                        </p>
                        
                        <div className="space-y-6 relative z-10">
                            <div>
                                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 block">PUNTO DE ENLACE (ENDPOINT)</label>
                                <div className="bg-black/30 border border-slate-800 rounded-lg p-4 font-mono text-sm text-slate-300 select-all hover:border-slate-600 transition-colors flex items-center gap-3">
                                    <span className="material-symbols-outlined text-slate-600">link</span>
                                    https://api.riverhub.com/v2/fleet
                                </div>
                            </div>
                            <div>
                                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 block">ID DE CLIENTE OPERATIVO</label>
                                <div className="bg-black/30 border border-slate-800 rounded-lg p-4 font-mono text-sm text-white select-all flex justify-between items-center group hover:border-slate-600 transition-colors">
                                    <span className="font-bold tracking-wide">RH-CLIENT-882910</span>
                                    <button className="text-slate-500 hover:text-white transition-colors" title="Copiar">
                                        <span className="material-symbols-outlined text-[20px]">content_copy</span>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div className="mt-8 pt-6 border-t border-slate-800/50 flex gap-4">
                            <button className="bg-primary hover:bg-primary-dark text-white px-4 py-2 rounded-lg text-sm font-bold transition-colors shadow-lg shadow-primary/10">
                                Regenerar Credenciales
                            </button>
                            <button className="text-slate-400 hover:text-white px-4 py-2 rounded-lg text-sm font-bold transition-colors">
                                Ver Documentación
                            </button>
                        </div>
                    </div>

                    {/* Right: Info/QR (Screenshot 2 Match) */}
                    <div className="lg:col-span-2 bg-[#0f1519] rounded-2xl p-8 border border-slate-800 shadow-2xl flex flex-col items-center justify-center text-center relative overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                        
                        <div className="relative z-10 bg-white p-4 rounded-xl shadow-lg mb-8 rotate-3 hover:rotate-0 transition-transform duration-500">
                             <span className="material-symbols-outlined text-8xl text-slate-900">qr_code_2</span>
                        </div>
                        
                        <h3 className="text-xl font-bold text-white mb-3 relative z-10">¿Quién usa estas llaves?</h3>
                        <p className="text-slate-400 text-sm max-w-xs relative z-10 leading-relaxed">
                            Si tienes un cliente que quiere saber dónde está su carga en tiempo real, tú le das este <strong className="text-white">ID de Cliente</strong> para que su sistema se conecte automáticamente.
                        </p>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Integrations;
