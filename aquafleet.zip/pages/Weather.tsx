import React from 'react';

const LOCATIONS = [
    { name: "Asunción", temp: 32, cond: "Soleado", wind: "NE 15km/h", river: 1.24, trend: "down" },
    { name: "Villeta", temp: 33, cond: "Parcial", wind: "N 10km/h", river: 1.45, trend: "down" },
    { name: "Pilar", temp: 30, cond: "Tormenta", wind: "S 45km/h", river: 2.80, trend: "up" },
    { name: "Corumbá", temp: 35, cond: "Soleado", wind: "NW 5km/h", river: 3.40, trend: "stable" },
];

const Weather: React.FC = () => {
  return (
    <div className="animate-fade-in space-y-6">
        <div className="flex justify-between items-end">
            <div>
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Hidrología y Clima</h1>
                <p className="text-slate-500 dark:text-[#9db2b9] mt-1">Pronóstico meteorológico y niveles de río en tiempo real.</p>
            </div>
            <button className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark text-slate-700 dark:text-white px-4 py-2 rounded-lg text-sm font-bold shadow-sm hover:bg-slate-50 dark:hover:bg-surface-darker transition-colors flex items-center gap-2">
                <span className="material-symbols-outlined text-primary">download</span> Descargar Boletín
            </button>
        </div>

        {/* Forecast Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {LOCATIONS.map((loc, i) => (
                <div key={i} className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-5 shadow-sm relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                        <span className="material-symbols-outlined text-6xl">
                            {loc.cond === 'Soleado' ? 'sunny' : loc.cond === 'Tormenta' ? 'thunderstorm' : 'partly_cloudy_day'}
                        </span>
                    </div>
                    
                    <h3 className="font-bold text-lg text-slate-900 dark:text-white mb-4">{loc.name}</h3>
                    
                    <div className="flex items-center gap-3 mb-4">
                        <span className="text-4xl font-light text-slate-900 dark:text-white">{loc.temp}°</span>
                        <div className="text-xs text-slate-500 dark:text-slate-400">
                            <p>{loc.cond}</p>
                            <p>Viento: {loc.wind}</p>
                        </div>
                    </div>

                    <div className="pt-4 border-t border-slate-100 dark:border-border-dark flex justify-between items-end">
                        <div>
                            <p className="text-xs font-bold text-slate-400 uppercase">Nivel Río</p>
                            <p className="text-xl font-bold text-primary">{loc.river}m</p>
                        </div>
                        <span className={`flex items-center text-xs font-bold px-2 py-1 rounded ${
                            loc.trend === 'up' ? 'text-emerald-500 bg-emerald-500/10' : 
                            loc.trend === 'down' ? 'text-red-500 bg-red-500/10' : 
                            'text-slate-500 bg-slate-500/10'
                        }`}>
                            <span className="material-symbols-outlined text-sm mr-1">
                                {loc.trend === 'up' ? 'trending_up' : loc.trend === 'down' ? 'trending_down' : 'trending_flat'}
                            </span>
                            {loc.trend === 'up' ? 'Subiendo' : loc.trend === 'down' ? 'Bajando' : 'Estable'}
                        </span>
                    </div>
                </div>
            ))}
        </div>

        {/* Detailed Chart Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-6 shadow-sm">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="font-bold text-slate-900 dark:text-white">Tendencia Histórica (Asunción)</h3>
                    <div className="flex gap-2">
                        <button className="px-3 py-1 text-xs font-bold rounded bg-slate-100 dark:bg-surface-darker text-slate-600 dark:text-slate-300">7D</button>
                        <button className="px-3 py-1 text-xs font-bold rounded bg-primary text-white">30D</button>
                        <button className="px-3 py-1 text-xs font-bold rounded bg-slate-100 dark:bg-surface-darker text-slate-600 dark:text-slate-300">1A</button>
                    </div>
                </div>
                {/* CSS Chart Simulation */}
                <div className="h-64 flex items-end gap-2 px-2">
                    {Array.from({length: 30}).map((_, i) => {
                        const height = 30 + Math.random() * 50;
                        return (
                            <div key={i} className="flex-1 bg-blue-500/20 hover:bg-blue-500/50 rounded-t transition-colors relative group" style={{ height: `${height}%` }}>
                                <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-xs px-2 py-1 rounded">
                                    {(height / 20).toFixed(2)}m
                                </div>
                            </div>
                        )
                    })}
                </div>
                <div className="flex justify-between mt-2 text-xs text-slate-400">
                    <span>1 Oct</span>
                    <span>15 Oct</span>
                    <span>30 Oct</span>
                </div>
            </div>

            <div className="bg-slate-900 text-white rounded-xl p-6 shadow-lg relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-900 to-slate-900"></div>
                <div className="relative z-10">
                    <h3 className="font-bold mb-4 flex items-center gap-2">
                        <span className="material-symbols-outlined text-yellow-400">warning</span> Alertas Vigentes
                    </h3>
                    <div className="space-y-4">
                        <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                            <p className="text-xs font-bold text-red-400 uppercase mb-1">Tormenta Severa</p>
                            <p className="text-sm font-medium">Zona Pilar - Humaitá</p>
                            <p className="text-xs text-slate-400 mt-2">Vientos > 60km/h. Se recomienda suspender navegación nocturna.</p>
                        </div>
                        <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                            <p className="text-xs font-bold text-orange-400 uppercase mb-1">Bajante Crítica</p>
                            <p className="text-sm font-medium">Paso Bermejo</p>
                            <p className="text-xs text-slate-400 mt-2">Calado máximo recomendado: 8 pies.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default Weather;