import React, { useState } from 'react';

// --- Interfaces ---
interface StockItem {
    vessel: string;
    levelPercent: number;
    capacity: number; // Litros totales
    current: number;  // Litros actuales
    avgDailyConsumption: number; // Litros por día estimados
}

interface Transaction {
    id: string;
    date: string;
    vessel: string;
    type: 'Carga' | 'Consumo';
    amount: number;
    location: string;
    responsible: string;
    cost?: number; // Para cargas
}

// --- Mock Initial Data ---
const INITIAL_STOCK: StockItem[] = [
    { vessel: "Titan III", levelPercent: 75, capacity: 40000, current: 30000, avgDailyConsumption: 1200 },
    { vessel: "Alpha Uno", levelPercent: 25, capacity: 35000, current: 8750, avgDailyConsumption: 950 },
    { vessel: "Delta", levelPercent: 90, capacity: 50000, current: 45000, avgDailyConsumption: 1500 },
    { vessel: "Barcaza G-200", levelPercent: 10, capacity: 5000, current: 500, avgDailyConsumption: 100 }, // Generador
];

const INITIAL_TRANSACTIONS: Transaction[] = [
    { id: "TX-991", date: "Hoy, 09:30", vessel: "Titan III", type: "Carga", amount: 5000, location: "Puerto Villeta", responsible: "Cap. Gómez", cost: 5600 },
    { id: "TX-990", date: "Ayer, 18:00", vessel: "Titan III", type: "Consumo", amount: 1200, location: "En Navegación", responsible: "Sistema Auto" },
    { id: "TX-989", date: "20 Oct, 10:15", vessel: "Alpha Uno", type: "Carga", amount: 10000, location: "Terminal Fénix", responsible: "Jefe Máq. Pérez", cost: 11200 },
];

const Fuel: React.FC = () => {
    // --- State ---
    const [stockList, setStockList] = useState<StockItem[]>(INITIAL_STOCK);
    const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
    const [isModalOpen, setIsModalOpen] = useState(false);
    
    // Dynamic chart data state
    const [dailyConsumption, setDailyConsumption] = useState([
        { day: 'Lun', val: 1200 }, 
        { day: 'Mar', val: 1500 }, 
        { day: 'Mie', val: 1100 },
        { day: 'Jue', val: 1800 }, 
        { day: 'Vie', val: 2000 }, 
        { day: 'Sab', val: 900 }, 
        { day: 'Dom (Hoy)', val: 800 }
    ]);
    const maxVal = 3000;

    // --- Actions ---
    const handleRegisterTransaction = (e: React.FormEvent) => {
        e.preventDefault();
        const form = e.target as HTMLFormElement;
        const formData = new FormData(form);

        const vesselName = formData.get('vessel') as string;
        const type = formData.get('type') as 'Carga' | 'Consumo';
        const amount = Number(formData.get('amount'));
        const pricePerLiter = Number(formData.get('price'));

        // 1. Create Transaction
        const newTx: Transaction = {
            id: `TX-${Math.floor(Math.random() * 10000)}`,
            date: "Ahora",
            vessel: vesselName,
            type: type,
            amount: amount,
            location: formData.get('location') as string,
            responsible: formData.get('responsible') as string,
            cost: type === 'Carga' ? amount * pricePerLiter : undefined
        };

        setTransactions([newTx, ...transactions]);

        // 2. Update Stock
        setStockList(prevStock => prevStock.map(item => {
            if (item.vessel === vesselName) {
                let newCurrent = item.current;
                if (type === 'Carga') {
                    newCurrent = Math.min(item.current + amount, item.capacity);
                } else {
                    newCurrent = Math.max(item.current - amount, 0);
                }
                const newPercent = (newCurrent / item.capacity) * 100;
                return { ...item, current: newCurrent, levelPercent: newPercent };
            }
            return item;
        }));

        // 3. Update Chart if it's a Consumption
        if (type === 'Consumo') {
            setDailyConsumption(prev => {
                const newData = [...prev];
                const todayIndex = 6; // Updating 'Dom (Hoy)'
                newData[todayIndex] = { 
                    ...newData[todayIndex], 
                    val: newData[todayIndex].val + amount 
                };
                return newData;
            });
        }

        setIsModalOpen(false);
    };

    // Calculate Financial KPIs
    const totalSpentMonth = transactions
        .filter(t => t.type === 'Carga')
        .reduce((acc, curr) => acc + (curr.cost || 0), 0);
    
    const totalStockLiters = stockList.reduce((acc, curr) => acc + curr.current, 0);

    return (
        <div className="space-y-6 animate-fade-in relative">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Combustible</h1>
                    <p className="text-slate-500 dark:text-[#9db2b9] mt-1">Control de consumo, stock y operaciones de búnker.</p>
                </div>
                <button 
                    onClick={() => setIsModalOpen(true)}
                    className="bg-primary hover:bg-primary-dark text-white px-5 py-2.5 rounded-lg font-bold shadow-lg shadow-primary/20 flex items-center gap-2 transition-colors"
                >
                    <span className="material-symbols-outlined">local_gas_station</span> Registrar Carga / Consumo
                </button>
            </div>

            {/* Financial KPIs */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white dark:bg-surface-dark p-4 rounded-xl border border-slate-200 dark:border-border-dark flex items-center gap-4 shadow-sm">
                    <div className="size-12 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center"><span className="material-symbols-outlined text-2xl">payments</span></div>
                    <div>
                        <p className="text-xs text-slate-500 uppercase font-bold">Gasto Mes Actual</p>
                        <h3 className="text-2xl font-bold text-slate-900 dark:text-white">$ {totalSpentMonth.toLocaleString()}</h3>
                    </div>
                </div>
                <div className="bg-white dark:bg-surface-dark p-4 rounded-xl border border-slate-200 dark:border-border-dark flex items-center gap-4 shadow-sm">
                    <div className="size-12 rounded-full bg-blue-500/10 text-blue-500 flex items-center justify-center"><span className="material-symbols-outlined text-2xl">water_drop</span></div>
                    <div>
                        <p className="text-xs text-slate-500 uppercase font-bold">Stock en Flota</p>
                        <h3 className="text-2xl font-bold text-slate-900 dark:text-white">{totalStockLiters.toLocaleString()} L</h3>
                    </div>
                </div>
                 <div className="bg-white dark:bg-surface-dark p-4 rounded-xl border border-slate-200 dark:border-border-dark flex items-center gap-4 shadow-sm">
                    <div className="size-12 rounded-full bg-orange-500/10 text-orange-500 flex items-center justify-center"><span className="material-symbols-outlined text-2xl">trending_up</span></div>
                    <div>
                        <p className="text-xs text-slate-500 uppercase font-bold">Precio Promedio</p>
                        <h3 className="text-2xl font-bold text-slate-900 dark:text-white">$ 1.12 / L</h3>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Main Consumption Chart - CORREGIDO */}
                <div className="lg:col-span-2 bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-6 shadow-sm flex flex-col">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="font-bold text-slate-900 dark:text-white">Consumo Semanal (Litros)</h3>
                        <div className="flex gap-2">
                            <span className="flex items-center gap-1 text-xs text-slate-500"><div className="size-2 rounded-full bg-primary"></div> Real</span>
                            <span className="flex items-center gap-1 text-xs text-slate-500"><div className="size-2 rounded-full bg-slate-300"></div> Est.</span>
                        </div>
                    </div>
                    {/* Contenedor del gráfico con altura definida y alineación inferior */}
                    <div className="flex-1 flex items-end justify-between gap-4 min-h-[250px] pb-2">
                        {dailyConsumption.map((d, i) => (
                            <div key={i} className="flex flex-col items-center gap-2 w-full h-full justify-end group cursor-pointer">
                                {/* Track de la barra (flex-1 para ocupar espacio vertical disponible) */}
                                <div className="relative w-full bg-slate-100 dark:bg-surface-darker rounded-t-lg flex-1 overflow-hidden flex items-end">
                                    <div 
                                        className="w-full bg-primary opacity-80 group-hover:opacity-100 transition-all duration-700 ease-out rounded-t-lg relative"
                                        style={{ height: `${Math.min((d.val / maxVal) * 100, 100)}%` }}
                                    >
                                        <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity z-10 whitespace-nowrap font-bold">
                                            {d.val.toLocaleString()} L
                                        </div>
                                    </div>
                                </div>
                                <span className="text-xs font-bold text-slate-500 truncate max-w-[40px] text-center">{d.day.substring(0, 3)}</span>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Stock Levels & Alerts */}
                <div className="flex flex-col gap-6">
                    {/* Stock Widget */}
                    <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-6 shadow-sm flex flex-col gap-5">
                        <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                            <span className="material-symbols-outlined text-slate-400">propane_tank</span> Niveles de Tanque
                        </h3>
                        {stockList.map((s, i) => {
                             let color = 'bg-emerald-500';
                             if (s.levelPercent < 40) color = 'bg-amber-500';
                             if (s.levelPercent < 20) color = 'bg-red-500';
                             
                             // Cálculo de autonomía aproximada
                             const daysLeft = s.avgDailyConsumption > 0 ? Math.floor(s.current / s.avgDailyConsumption) : 0;

                             return (
                                <div key={i}>
                                    <div className="flex justify-between items-end text-sm mb-1">
                                        <div>
                                            <span className="font-bold text-slate-700 dark:text-white block">{s.vessel}</span>
                                            {/* Nuevo indicador de autonomía */}
                                            <span className="text-[10px] text-slate-400 font-medium flex items-center gap-1">
                                                <span className="material-symbols-outlined text-[12px]">timelapse</span>
                                                ~{daysLeft} días de autonomía
                                            </span>
                                        </div>
                                        <span className={`text-xs font-mono ${s.levelPercent < 20 ? "text-red-500 font-bold" : "text-slate-500"}`}>
                                            {s.current.toLocaleString()} / {s.capacity.toLocaleString()} L
                                        </span>
                                    </div>
                                    <div className="w-full bg-slate-100 dark:bg-surface-darker h-3 rounded-full overflow-hidden mt-1">
                                        <div 
                                            className={`h-full rounded-full transition-all duration-1000 ${color}`} 
                                            style={{ width: `${s.levelPercent}%` }}
                                        ></div>
                                    </div>
                                </div>
                             )
                        })}
                    </div>

                    {/* Anomalies Widget */}
                    <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-6 shadow-sm flex-1">
                        <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-4">
                            <span className="material-symbols-outlined text-orange-500">warning</span> Alertas de Consumo
                        </h3>
                        <div className="space-y-3">
                            <div className="bg-orange-50 dark:bg-orange-900/10 border border-orange-100 dark:border-orange-900/30 p-3 rounded-lg flex gap-3">
                                <span className="material-symbols-outlined text-orange-500">trending_up</span>
                                <div>
                                    <p className="text-xs font-bold text-slate-900 dark:text-white">Titan III: Motor Estribor</p>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">Consumo +15% sobre promedio histórico.</p>
                                </div>
                            </div>
                            <div className="bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-900/30 p-3 rounded-lg flex gap-3">
                                <span className="material-symbols-outlined text-red-500">local_gas_station</span>
                                <div>
                                    <p className="text-xs font-bold text-slate-900 dark:text-white">Barcaza G-200</p>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">Nivel crítico (10%). Requiere recarga.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Transaction Log */}
            <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl overflow-hidden shadow-sm">
                <div className="px-6 py-4 border-b border-slate-200 dark:border-border-dark bg-slate-50 dark:bg-surface-darker flex justify-between items-center">
                    <h3 className="font-bold text-slate-900 dark:text-white">Historial de Operaciones</h3>
                    <button className="text-xs font-bold text-primary hover:underline">Exportar Excel</button>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-slate-50 dark:bg-surface-darker text-slate-500 border-b border-slate-200 dark:border-border-dark">
                            <tr>
                                <th className="px-6 py-3">Fecha</th>
                                <th className="px-6 py-3">Embarcación</th>
                                <th className="px-6 py-3">Tipo</th>
                                <th className="px-6 py-3">Cantidad</th>
                                <th className="px-6 py-3">Ubicación</th>
                                <th className="px-6 py-3">Responsable</th>
                                <th className="px-6 py-3 text-right">Costo Est.</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-border-dark">
                            {transactions.map((tx) => (
                                <tr key={tx.id} className="hover:bg-slate-50 dark:hover:bg-surface-darker/50 transition-colors animate-fade-in">
                                    <td className="px-6 py-3 text-slate-500">{tx.date}</td>
                                    <td className="px-6 py-3 font-bold text-slate-900 dark:text-white">{tx.vessel}</td>
                                    <td className="px-6 py-3">
                                        <span className={`px-2 py-0.5 rounded text-xs font-bold uppercase ${
                                            tx.type === 'Carga' 
                                            ? 'text-emerald-500 bg-emerald-100 dark:bg-emerald-900/20' 
                                            : 'text-blue-500 bg-blue-100 dark:bg-blue-900/20'
                                        }`}>
                                            {tx.type}
                                        </span>
                                    </td>
                                    <td className={`px-6 py-3 font-mono font-bold ${tx.type === 'Consumo' ? 'text-slate-500' : 'text-emerald-600 dark:text-emerald-400'}`}>
                                        {tx.type === 'Consumo' ? '-' : '+'}{tx.amount.toLocaleString()} L
                                    </td>
                                    <td className="px-6 py-3 text-slate-500">{tx.location}</td>
                                    <td className="px-6 py-3 text-slate-500">{tx.responsible}</td>
                                    <td className="px-6 py-3 text-right font-mono text-slate-600 dark:text-slate-400">
                                        {tx.cost ? `$ ${tx.cost.toLocaleString()}` : '-'}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* --- MODAL REGISTRAR CARGA/CONSUMO --- */}
            {isModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <div 
                        className="absolute inset-0 bg-slate-900/70 backdrop-blur-sm transition-opacity" 
                        onClick={() => setIsModalOpen(false)}
                    ></div>

                    <div className="relative w-full max-w-lg bg-white dark:bg-surface-dark rounded-xl shadow-2xl border border-slate-200 dark:border-border-dark flex flex-col max-h-[90vh] overflow-hidden animate-fade-in-up">
                        <div className="px-6 py-4 border-b border-slate-200 dark:border-border-dark flex justify-between items-center bg-slate-50 dark:bg-surface-darker">
                            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                <span className="material-symbols-outlined text-primary">local_gas_station</span>
                                Registrar Operación
                            </h3>
                            <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-red-500 transition-colors">
                                <span className="material-symbols-outlined">close</span>
                            </button>
                        </div>

                        <form onSubmit={handleRegisterTransaction} className="p-6 space-y-4 overflow-y-auto">
                            
                            <div className="grid grid-cols-2 gap-4">
                                <div className="col-span-2">
                                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1.5">Embarcación</label>
                                    <select name="vessel" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50">
                                        {stockList.map(s => <option key={s.vessel} value={s.vessel}>{s.vessel}</option>)}
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1.5">Tipo Operación</label>
                                    <select name="type" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50">
                                        <option value="Carga">Carga (Entrada)</option>
                                        <option value="Consumo">Consumo (Salida)</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1.5">Cantidad (Litros)</label>
                                    <input name="amount" type="number" required min="1" placeholder="0" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50 font-mono" />
                                </div>
                            </div>

                            <div className="p-4 bg-slate-50 dark:bg-surface-darker rounded-lg border border-slate-200 dark:border-border-dark">
                                <h4 className="text-xs font-bold text-slate-500 uppercase mb-3">Detalles Financieros (Opcional para Consumo)</h4>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Precio Unitario ($/L)</label>
                                        <input name="price" type="number" step="0.01" defaultValue="1.12" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-white dark:bg-surface-dark px-3 py-2 text-sm text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Proveedor / Orden</label>
                                        <input name="provider" type="text" placeholder="Ej. Petropar #992" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-white dark:bg-surface-dark px-3 py-2 text-sm text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                                    </div>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1.5">Ubicación</label>
                                    <input name="location" type="text" required placeholder="Ej. Puerto Villeta" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1.5">Responsable</label>
                                    <input name="responsible" type="text" required placeholder="Ej. Cap. Martínez" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                                </div>
                            </div>

                            <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200 dark:border-border-dark mt-4">
                                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-slate-600 dark:text-slate-300 font-medium hover:bg-slate-100 dark:hover:bg-surface-darker rounded-lg transition-colors">Cancelar</button>
                                <button type="submit" className="px-6 py-2 bg-primary hover:bg-primary-dark text-white font-bold rounded-lg shadow-lg shadow-primary/20 transition-all">Confirmar Operación</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Fuel;