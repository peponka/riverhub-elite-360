
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/Toast';

const Login: React.FC = () => {
  const { login } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();
  
  // Default values kept for demo convenience, clear them to force manual entry if preferred
  const [email, setEmail] = useState('admin@aquafleet.com');
  const [password, setPassword] = useState('password');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const { error } = await login(email, password);
      if (error) {
        showToast(error, 'error');
      } else {
        showToast('Bienvenido de nuevo', 'success');
        navigate('/dashboard');
      }
    } catch (err) {
      showToast('Error al iniciar sesión', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-screen w-full bg-background-light dark:bg-background-dark text-slate-900 dark:text-white font-display">
      {/* Left Side: Form */}
      <div className="w-full lg:w-1/2 flex flex-col justify-center items-center px-6 py-12 lg:px-20 xl:px-32 relative z-10 bg-white dark:bg-[#0f1519]">
        <div className="w-full max-w-[420px] flex flex-col gap-8 animate-fade-in-up">
          
          {/* Logo */}
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-3 text-primary">
              <div className="size-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <span className="material-symbols-outlined text-[32px]">anchor</span>
              </div>
              <div>
                <span className="text-2xl font-black tracking-tighter text-slate-900 dark:text-white block leading-none">AquaFleet</span>
                <span className="text-xs font-bold text-slate-400 tracking-widest uppercase">Logística Fluvial</span>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col gap-2">
            <h1 className="text-4xl font-black tracking-tight text-slate-900 dark:text-white">Bienvenido</h1>
            <p className="text-slate-500 dark:text-[#9db2b9]">
                Plataforma de gestión inteligente para la Hidrovía.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            <label className="flex flex-col w-full gap-2">
              <span className="text-sm font-bold text-slate-700 dark:text-slate-300">Correo electrónico</span>
              <div className="relative group">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-primary transition-colors material-symbols-outlined text-[20px]">mail</span>
                <input 
                  className="w-full rounded-xl border border-slate-200 dark:border-border-dark bg-slate-50 dark:bg-surface-darker focus:border-primary focus:ring-4 focus:ring-primary/10 h-12 pl-12 pr-4 outline-none transition-all placeholder:text-slate-400 dark:placeholder:text-[#5f747d] text-sm font-medium" 
                  placeholder="usuario@empresa.com" 
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </label>
            
            <label className="flex flex-col w-full gap-2">
              <div className="flex justify-between items-center">
                <span className="text-sm font-bold text-slate-700 dark:text-slate-300">Contraseña</span>
                <a href="#" className="text-xs text-primary hover:underline font-bold">¿Olvidaste tu contraseña?</a>
              </div>
              <div className="relative group">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-primary transition-colors material-symbols-outlined text-[20px]">lock</span>
                <input 
                  className="w-full rounded-xl border border-slate-200 dark:border-border-dark bg-slate-50 dark:bg-surface-darker focus:border-primary focus:ring-4 focus:ring-primary/10 h-12 pl-12 pr-12 outline-none transition-all text-sm font-medium" 
                  placeholder="••••••••" 
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <button type="button" className="absolute right-0 top-0 h-full px-4 text-slate-400 hover:text-primary transition-colors">
                  <span className="material-symbols-outlined text-[20px]">visibility</span>
                </button>
              </div>
            </label>

            <button 
                type="submit" 
                disabled={isSubmitting}
                className={`w-full h-12 rounded-xl bg-primary hover:bg-primary-dark text-white font-bold transition-all shadow-xl shadow-primary/20 flex items-center justify-center gap-2 mt-4 hover:scale-[1.02] active:scale-95 ${isSubmitting ? 'opacity-70 cursor-wait' : ''}`}
            >
              {isSubmitting ? (
                  <span className="size-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
              ) : (
                  <>
                    <span>Iniciar Sesión</span>
                    <span className="material-symbols-outlined text-[20px]">login</span>
                  </>
              )}
            </button>
          </form>

          <div className="text-center pt-2">
            <p className="text-slate-500 dark:text-[#9db2b9] text-sm">
              ¿No tienes una cuenta? 
              <Link to="/register" className="font-bold text-primary hover:underline ml-1">Solicitar Acceso</Link>
            </p>
          </div>
        </div>
        
        <div className="absolute bottom-6 text-[10px] text-slate-400 font-medium">
            © 2024 AquaFleet Systems. Todos los derechos reservados.
        </div>
      </div>

      {/* Right Side: Image */}
      <div className="hidden lg:flex lg:w-1/2 relative bg-surface-dark overflow-hidden">
        <div 
          className="absolute inset-0 w-full h-full bg-cover bg-center transition-transform duration-[20s] hover:scale-105" 
          style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1559251606-c623743a6d76?q=80&w=2670&auto=format&fit=crop")' }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-[#0f1519] via-[#0f1519]/40 to-transparent mix-blend-multiply opacity-80"></div>
          <div className="absolute inset-0 bg-blue-900/20 mix-blend-overlay"></div>
        </div>
        
        <div className="absolute bottom-0 left-0 w-full p-20 z-10">
            <div className="mb-6">
                <span className="px-3 py-1 bg-white/10 backdrop-blur-md border border-white/20 rounded-full text-xs font-bold text-white uppercase tracking-wider">
                    Versión 2.5 Live
                </span>
            </div>
            <h2 className="text-5xl font-black text-white leading-tight mb-6 tracking-tight">
                Control total de tu flota,<br/>en tiempo real.
            </h2>
            <div className="flex gap-12 border-t border-white/10 pt-8">
                <div>
                    <p className="text-3xl font-bold text-white">98%</p>
                    <p className="text-xs text-slate-300 font-medium uppercase tracking-wider mt-1">Uptime Garantizado</p>
                </div>
                <div>
                    <p className="text-3xl font-bold text-white">24/7</p>
                    <p className="text-xs text-slate-300 font-medium uppercase tracking-wider mt-1">Monitoreo Satelital</p>
                </div>
                <div>
                    <p className="text-3xl font-bold text-white">+500</p>
                    <p className="text-xs text-slate-300 font-medium uppercase tracking-wider mt-1">Buques Conectados</p>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
