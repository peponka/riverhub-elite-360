
import React, { useState, useEffect } from 'react';

interface VesselData {
  id: string;
  name: string;
  mat: string;
  type: string;
  status: string;
  color: string;
  // Extended details
  capacity: string;
  currentCargo: string; // New field
  lastUpdate: string;
  crew: number;
  engineHours: number;
  location: string;
  year: string;
}

const Fleet: React.FC = () => {
  // Mock Data as Initial State with extended details
  const [vessels, setVessels] = useState<VesselData[]>([
    { 
      name: "Remolcador Titan III", id: "REM-042", mat: "PY-2938-AR", type: "Remolcador", status: "Operativo", color: "green",
      capacity: "N/A", currentCargo: "Convoy (12 Barcazas)", lastUpdate: "Hace 10 min", crew: 8, engineHours: 12450, location: "Km 1240 - Asunción", year: "2015"
    },
    { 
      name: "Barcaza B-102", id: "BAR-102", mat: "PY-8821-BG", type: "Barcaza", status: "Operativo", color: "green",
      capacity: "2,500 Ton", currentCargo: "Soja (2,400 Ton)", lastUpdate: "Hace 2 horas", crew: 0, engineHours: 0, location: "Km 980 - Pilar", year: "2010"
    },
    { 
      name: "Barcaza T-55", id: "BAR-055", mat: "PY-1102-BT", type: "Tanque", status: "Mantenimiento", color: "amber",
      capacity: "3,000 m3", currentCargo: "Vacío (Desgasificado)", lastUpdate: "Hace 1 día", crew: 0, engineHours: 0, location: "Astillero Chaco", year: "2012"
    },
    { 
      name: "Remolcador Alpha Uno", id: "REM-001", mat: "PY-1001-AR", type: "Remolcador", status: "Inactivo", color: "red",
      capacity: "N/A", currentCargo: "Sin Asignación", lastUpdate: "Hace 5 días", crew: 2, engineHours: 45200, location: "Puerto Villeta", year: "2005"
    },
    { 
      name: "Buque Motor Delta", id: "BM-009", mat: "PY-4402-BM", type: "Buque Motor", status: "En Ruta", color: "blue",
      capacity: "140 TEUs", currentCargo: "Contenedores (85 TEUs)", lastUpdate: "En vivo", crew: 12, engineHours: 8500, location: "Km 450 - Corumbá", year: "2019"
    },
    { 
      name: "Barcaza G-200", id: "BAR-200", mat: "PY-3321-BG", type: "Barcaza", status: "Operativo", color: "green",
      capacity: "2,500 Ton", currentCargo: "Mineral de Hierro", lastUpdate: "Hace 30 min", crew: 0, engineHours: 0, location: "Km 1240 - Asunción", year: "2011"
    },
    { 
      name: "Remolcador Horizonte", id: "REM-088", mat: "PY-5511-AR", type: "Remolcador", status: "En Ruta", color: "blue",
      capacity: "N/A", currentCargo: "Convoy (16 Barcazas)", lastUpdate: "Hace 45 min", crew: 6, engineHours: 9800, location: "Km 1100 - Concepción", year: "2018"
    },
    { 
      name: "Barcaza C-404", id: "BAR-404", mat: "PY-9922-BG", type: "Barcaza", status: "Inactivo", color: "red",
      capacity: "2,500 Ton", currentCargo: "Vacío", lastUpdate: "Hace 1 semana", crew: 0, engineHours: 0, location: "Puerto Fénix", year: "2008"
    },
    { 
      name: "Barcaza L-99", id: "BAR-099", mat: "PY-1234-BG", type: "Barcaza", status: "Operativo", color: "green",
      capacity: "2,800 Ton", currentCargo: "Fertilizantes", lastUpdate: "Hace 2 horas", crew: 0, engineHours: 0, location: "Km 1000", year: "2015"
    },
    { 
      name: "Remolcador Taurus", id: "REM-112", mat: "PY-5678-AR", type: "Remolcador", status: "En Ruta", color: "blue",
      capacity: "N/A", currentCargo: "Convoy Mixto", lastUpdate: "En vivo", crew: 7, engineHours: 11000, location: "Km 800", year: "2016"
    }
  ]);

  // Filter State
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(5);

  // Modals State
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isCargoModalOpen, setIsCargoModalOpen] = useState(false); 
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false); // New Modal for Delete
  
  const [editingVessel, setEditingVessel] = useState<VesselData | null>(null);
  const [viewingVessel, setViewingVessel] = useState<VesselData | null>(null);
  const [vesselToDelete, setVesselToDelete] = useState<VesselData | null>(null); // To confirm deletion

  // Dynamic Page Size
  useEffect(() => {
    const calculatePageSize = () => {
      const availableHeight = window.innerHeight - 450; 
      const calculatedItems = Math.max(5, Math.floor(availableHeight / 73));
      setItemsPerPage(calculatedItems);
    };

    calculatePageSize();
    window.addEventListener('resize', calculatePageSize);
    return () => window.removeEventListener('resize', calculatePageSize);
  }, []);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, filterType, filterStatus, itemsPerPage]);

  const filteredVessels = vessels.filter(vessel => {
    const searchLower = searchTerm.toLowerCase();
    const matchesSearch = 
      vessel.name.toLowerCase().includes(searchLower) || 
      vessel.mat.toLowerCase().includes(searchLower) || 
      vessel.id.toLowerCase().includes(searchLower);
    
    const matchesType = filterType ? vessel.type === filterType : true;
    const matchesStatus = filterStatus ? vessel.status === filterStatus : true;

    return matchesSearch && matchesType && matchesStatus;
  });

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredVessels.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(filteredVessels.length / itemsPerPage);

  const uniqueTypes = Array.from(new Set(vessels.map(v => v.type)));
  const uniqueStatuses = Array.from(new Set(vessels.map(v => v.status)));

  // Handlers
  const handleRowClick = (vessel: VesselData) => {
    setViewingVessel(vessel);
  };

  const handleEditClick = (e: React.MouseEvent, vessel: VesselData) => {
    e.stopPropagation(); 
    setEditingVessel({ ...vessel });
    setIsEditModalOpen(true);
  };

  const handleDeleteClick = (e: React.MouseEvent, vessel: VesselData) => {
    e.stopPropagation();
    setVesselToDelete(vessel);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = () => {
      if (vesselToDelete) {
          setVessels(prev => prev.filter(v => v.id !== vesselToDelete.id));
          setIsDeleteModalOpen(false);
          setVesselToDelete(null);
          // If viewing details of deleted item, close modal
          if (viewingVessel?.id === vesselToDelete.id) {
              setViewingVessel(null);
          }
      }
  };

  const handleCloseEditModal = () => {
    setIsEditModalOpen(false);
    setEditingVessel(null);
  };
  
  const handleAddVessel = (e: React.FormEvent) => {
      e.preventDefault();
      const form = e.target as HTMLFormElement;
      const formData = new FormData(form);
      
      const status = formData.get('status') as string;
      let color = 'green';
      if (status === 'Mantenimiento') color = 'amber';
      if (status === 'Inactivo') color = 'red';
      if (status === 'En Ruta') color = 'blue';

      const newVessel: VesselData = {
          id: `ID-${Math.floor(Math.random()*1000)}`,
          name: formData.get('name') as string,
          mat: formData.get('mat') as string,
          type: formData.get('type') as string,
          status: status,
          color: color,
          capacity: formData.get('capacity') as string,
          currentCargo: formData.get('currentCargo') as string || 'Vacío',
          lastUpdate: 'Ahora',
          crew: 0,
          engineHours: 0,
          location: 'Puerto Central',
          year: formData.get('year') as string
      };
      
      setVessels([...vessels, newVessel]);
      setIsAddModalOpen(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    if (!editingVessel) return;
    const { name, value } = e.target;
    setEditingVessel({ ...editingVessel, [name]: value } as any);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingVessel) return;

    let newColor = 'green';
    if (editingVessel.status === 'Mantenimiento') newColor = 'amber';
    if (editingVessel.status === 'Inactivo') newColor = 'red';
    if (editingVessel.status === 'En Ruta') newColor = 'blue';

    const updatedVessel = { ...editingVessel, color: newColor };

    setVessels(prev => prev.map(v => v.id === updatedVessel.id ? updatedVessel : v));
    handleCloseEditModal();
  };

  const handleCargoUpdate = (e: React.FormEvent) => {
      e.preventDefault();
      const form = e.target as HTMLFormElement;
      const formData = new FormData(form);
      
      if (!viewingVessel) return;

      const newCargo = formData.get('cargoDescription') as string;
      const newStatus = formData.get('operationStatus') as string;
      
      let newColor = 'green';
      if (newStatus === 'Mantenimiento') newColor = 'amber';
      if (newStatus === 'Inactivo') newColor = 'red';
      if (newStatus === 'En Ruta') newColor = 'blue';

      const updatedVessel = {
          ...viewingVessel,
          currentCargo: newCargo,
          status: newStatus,
          color: newColor,
          lastUpdate: 'Hace un momento'
      };

      setVessels(prev => prev.map(v => v.id === viewingVessel.id ? updatedVessel : v));
      setViewingVessel(updatedVessel); 
      setIsCargoModalOpen(false);
  };

  const clearFilters = () => {
    setSearchTerm('');
    setFilterType('');
    setFilterStatus('');
  };

  return (
    <div className="space-y-6 relative h-[calc(100vh-140px)] flex flex-col">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 mb-2 shrink-0">
            <div>
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Flota</h1>
                <p className="text-slate-500 dark:text-[#9db2b9] mt-1">Gestión integral de barcazas y remolcadores.</p>
            </div>
            <button 
                onClick={() => setIsAddModalOpen(true)}
                className="bg-primary hover:bg-primary-dark text-white px-5 py-2.5 rounded-lg font-bold shadow-lg shadow-primary/20 flex items-center gap-2 transition-colors"
            >
                <span className="material-symbols-outlined">add</span> Nueva Embarcación
            </button>
        </div>

        {/* Filters Toolbar */}
        <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-4 shadow-sm flex flex-col md:flex-row gap-4 items-center shrink-0">
          <div className="relative w-full md:flex-1">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 material-symbols-outlined text-[20px]">search</span>
            <input 
              type="text" 
              placeholder="Buscar por nombre, matrícula o ID..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker text-slate-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all"
            />
          </div>
          
          <div className="flex w-full md:w-auto gap-4">
            <div className="relative w-full md:w-48">
              <select 
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="w-full pl-4 pr-10 py-2 rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker text-slate-700 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none appearance-none transition-all cursor-pointer"
              >
                <option value="">Todos los Tipos</option>
                {uniqueTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none material-symbols-outlined text-[20px]">filter_list</span>
            </div>

            <div className="relative w-full md:w-48">
              <select 
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="w-full pl-4 pr-10 py-2 rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker text-slate-700 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none appearance-none transition-all cursor-pointer"
              >
                <option value="">Todos los Estados</option>
                {uniqueStatuses.map(status => (
                  <option key={status} value={status}>{status}</option>
                ))}
              </select>
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none material-symbols-outlined text-[20px]">expand_more</span>
            </div>

            {(searchTerm || filterType || filterStatus) && (
              <button 
                onClick={clearFilters}
                className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 rounded-lg transition-colors"
                title="Limpiar filtros"
              >
                <span className="material-symbols-outlined text-[20px]">filter_alt_off</span>
              </button>
            )}
          </div>
        </div>

        <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl overflow-hidden shadow-sm flex flex-col flex-1 min-h-0">
            <div className="overflow-auto flex-1">
                <table className="w-full text-left text-sm">
                    <thead className="bg-slate-50 dark:bg-surface-darker text-slate-500 dark:text-[#9db2b9] border-b border-slate-200 dark:border-border-dark sticky top-0 z-10">
                        <tr>
                            <th className="px-6 py-4 font-semibold">Embarcación</th>
                            <th className="px-6 py-4 font-semibold">Matrícula</th>
                            <th className="px-6 py-4 font-semibold">Tipo</th>
                            <th className="px-6 py-4 font-semibold">Estado</th>
                            <th className="px-6 py-4 font-semibold text-right">Acciones</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 dark:divide-border-dark">
                        {currentItems.length > 0 ? (
                          currentItems.map((v) => (
                              <tr 
                                key={v.id} 
                                onClick={() => handleRowClick(v)}
                                className="hover:bg-slate-50 dark:hover:bg-surface-darker/50 transition-colors group cursor-pointer"
                              >
                                  <td className="px-6 py-4">
                                      <div className="flex items-center gap-3">
                                          <div className="size-10 rounded-lg bg-slate-200 dark:bg-surface-darker flex items-center justify-center text-slate-500 dark:text-white">
                                              <span className="material-symbols-outlined">directions_boat</span>
                                          </div>
                                          <div>
                                              <p className="font-bold text-slate-900 dark:text-white group-hover:text-primary transition-colors">{v.name}</p>
                                              <p className="text-xs text-slate-500 dark:text-[#9db2b9]">{v.id}</p>
                                          </div>
                                      </div>
                                  </td>
                                  <td className="px-6 py-4 text-slate-600 dark:text-[#9db2b9] font-mono">{v.mat}</td>
                                  <td className="px-6 py-4 text-slate-900 dark:text-white">{v.type}</td>
                                  <td className="px-6 py-4">
                                      {v.status === 'En Ruta' ? (
                                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-500/20 shadow-sm group-hover:bg-blue-100 dark:group-hover:bg-blue-500/20 transition-colors">
                                            <span className="material-symbols-outlined text-[18px] animate-pulse">sailing</span>
                                            <span>En Ruta</span>
                                            <span className="relative flex size-2 ml-1">
                                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                                                <span className="relative inline-flex rounded-full size-2 bg-blue-500"></span>
                                            </span>
                                        </span>
                                      ) : (
                                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-${v.color}-100 dark:bg-${v.color}-500/10 text-${v.color}-700 dark:text-${v.color}-500 border border-${v.color}-200 dark:border-${v.color}-500/20`}>
                                            {v.status}
                                        </span>
                                      )}
                                  </td>
                                  <td className="px-6 py-4 text-right">
                                      <div className="flex justify-end gap-1">
                                        <button 
                                            onClick={(e) => handleEditClick(e, v)}
                                            className="text-slate-400 hover:text-primary p-2 transition-colors rounded-full hover:bg-slate-100 dark:hover:bg-surface-darker z-10 relative"
                                            title="Editar detalles"
                                        >
                                            <span className="material-symbols-outlined text-[20px]">edit</span>
                                        </button>
                                        <button 
                                            onClick={(e) => handleDeleteClick(e, v)}
                                            className="text-slate-400 hover:text-red-500 p-2 transition-colors rounded-full hover:bg-red-50 dark:hover:bg-red-900/10 z-10 relative"
                                            title="Eliminar embarcación"
                                        >
                                            <span className="material-symbols-outlined text-[20px]">delete</span>
                                        </button>
                                      </div>
                                  </td>
                              </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={5} className="px-6 py-8 text-center text-slate-500 dark:text-[#9db2b9]">
                              <div className="flex flex-col items-center gap-2">
                                <span className="material-symbols-outlined text-4xl opacity-50">search_off</span>
                                <p>No se encontraron embarcaciones con los filtros actuales.</p>
                                <button onClick={clearFilters} className="text-primary hover:underline text-sm font-medium">Limpiar filtros</button>
                              </div>
                            </td>
                          </tr>
                        )}
                    </tbody>
                </table>
            </div>

            {/* Pagination Controls */}
            {filteredVessels.length > 0 && (
                <div className="px-6 py-4 border-t border-slate-200 dark:border-border-dark flex items-center justify-between bg-slate-50 dark:bg-surface-darker shrink-0">
                    <p className="text-sm text-slate-500 dark:text-[#9db2b9]">
                        Mostrando <span className="font-bold text-slate-900 dark:text-white">{indexOfFirstItem + 1}</span> a <span className="font-bold text-slate-900 dark:text-white">{Math.min(indexOfLastItem, filteredVessels.length)}</span> de <span className="font-bold text-slate-900 dark:text-white">{filteredVessels.length}</span> embarcaciones
                    </p>
                    <div className="flex items-center gap-2">
                        <button 
                            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                            disabled={currentPage === 1}
                            className="p-2 rounded-lg border border-slate-200 dark:border-border-dark hover:bg-white dark:hover:bg-surface-dark text-slate-600 dark:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                        >
                            <span className="material-symbols-outlined text-[20px]">chevron_left</span>
                        </button>
                        <span className="text-sm font-medium text-slate-600 dark:text-white px-2">
                            Página {currentPage} de {totalPages}
                        </span>
                        <button 
                            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                            disabled={currentPage === totalPages}
                            className="p-2 rounded-lg border border-slate-200 dark:border-border-dark hover:bg-white dark:hover:bg-surface-dark text-slate-600 dark:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                        >
                            <span className="material-symbols-outlined text-[20px]">chevron_right</span>
                        </button>
                    </div>
                </div>
            )}
        </div>

        {/* --- DETAILS MODAL --- */}
        {viewingVessel && (
             <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                <div 
                    className="absolute inset-0 bg-slate-900/70 backdrop-blur-sm transition-opacity" 
                    onClick={() => setViewingVessel(null)}
                ></div>

                <div className="relative w-full max-w-2xl bg-white dark:bg-surface-dark rounded-2xl shadow-2xl border border-slate-200 dark:border-border-dark overflow-hidden animate-fade-in-up">
                    {/* Header Image/Banner */}
                    <div className="h-32 bg-slate-800 relative overflow-hidden">
                        <div className="absolute inset-0 bg-[url('https://lh3.googleusercontent.com/aida-public/AB6AXuDgdm1br09l4HMWYtNme7-id8ufkJ1lGWlGDU932SJY4447rvTEez-WjX1jD6eMFH3pYy8avEy4LVKXAqc2GYWpUJjAGm1k9PcB90a6ZJ9zTkzhxiC_bR6lU6Tb9z0On2lpwJl_jqLtx6taYFc2yOMijiVZxqzYcrJdjerffabPSfz_OBnDreMS3aQsRsm6f2aWb-5BUpi_DROd0dp2Ga0GShset5XP5DBjt2EIDsDf_EnmjuSbPaYY0_9O0-iBKonWgKNKSXGIqBSN')] bg-cover bg-center opacity-40"></div>
                        <div className="absolute inset-0 bg-gradient-to-t from-surface-dark to-transparent"></div>
                        <button 
                            onClick={() => setViewingVessel(null)}
                            className="absolute top-4 right-4 bg-black/30 hover:bg-black/50 text-white rounded-full p-1.5 transition-colors backdrop-blur-md"
                        >
                            <span className="material-symbols-outlined">close</span>
                        </button>
                    </div>

                    <div className="px-8 pb-8 relative">
                        {/* Icon Overlay */}
                        <div className="size-20 bg-white dark:bg-surface-darker rounded-2xl border-4 border-white dark:border-surface-dark shadow-xl -mt-10 flex items-center justify-center text-primary relative z-10">
                             <span className="material-symbols-outlined text-4xl">directions_boat</span>
                        </div>

                        <div className="mt-4 flex flex-col md:flex-row justify-between items-start gap-4">
                            <div>
                                <h2 className="text-2xl font-bold text-slate-900 dark:text-white">{viewingVessel.name}</h2>
                                <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-[#9db2b9] mt-1">
                                    <span className="font-mono bg-slate-100 dark:bg-surface-darker px-2 py-0.5 rounded">{viewingVessel.mat}</span>
                                    <span>•</span>
                                    <span>{viewingVessel.type}</span>
                                    <span>•</span>
                                    <span>Año {viewingVessel.year}</span>
                                </div>
                            </div>
                            <div className={`px-3 py-1 rounded-full text-sm font-bold border flex items-center gap-2 bg-${viewingVessel.color}-100 dark:bg-${viewingVessel.color}-500/10 text-${viewingVessel.color}-700 dark:text-${viewingVessel.color}-500 border-${viewingVessel.color}-200 dark:border-${viewingVessel.color}-500/20`}>
                                <span className={`size-2 rounded-full bg-${viewingVessel.color}-500`}></span>
                                {viewingVessel.status}
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
                            {/* Card 1: Technical Specs */}
                            <div className="bg-slate-50 dark:bg-surface-darker/50 rounded-xl p-5 border border-slate-100 dark:border-border-dark">
                                <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4 flex items-center gap-2">
                                    <span className="material-symbols-outlined text-slate-400">tune</span> Especificaciones
                                </h3>
                                <div className="space-y-3">
                                    <div className="flex justify-between border-b border-slate-200 dark:border-border-dark/50 pb-2">
                                        <span className="text-sm text-slate-500">Capacidad Carga</span>
                                        <span className="text-sm font-medium text-slate-900 dark:text-white">{viewingVessel.capacity}</span>
                                    </div>
                                    <div className="flex justify-between border-b border-slate-200 dark:border-border-dark/50 pb-2">
                                        <span className="text-sm text-slate-500">Tripulación Asignada</span>
                                        <span className="text-sm font-medium text-slate-900 dark:text-white">{viewingVessel.crew} personas</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-sm text-slate-500">Horas de Motor</span>
                                        <span className="text-sm font-medium text-slate-900 dark:text-white">{viewingVessel.engineHours.toLocaleString()} hrs</span>
                                    </div>
                                </div>
                            </div>

                            {/* Card 2: Operational Info */}
                            <div className="bg-slate-50 dark:bg-surface-darker/50 rounded-xl p-5 border border-slate-100 dark:border-border-dark">
                                <div className="flex justify-between items-center mb-4">
                                    <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                                        <span className="material-symbols-outlined text-slate-400">radar</span> Estado Actual
                                    </h3>
                                    <button 
                                        onClick={() => setIsCargoModalOpen(true)}
                                        className="text-[10px] font-bold bg-primary text-white px-2 py-1 rounded hover:bg-primary-dark transition-colors flex items-center gap-1"
                                    >
                                        <span className="material-symbols-outlined text-[14px]">inventory_2</span> GESTIONAR
                                    </button>
                                </div>
                                <div className="space-y-3">
                                    <div className="flex justify-between border-b border-slate-200 dark:border-border-dark/50 pb-2">
                                        <span className="text-sm text-slate-500">Ubicación</span>
                                        <span className="text-sm font-medium text-primary flex items-center gap-1">
                                            <span className="material-symbols-outlined text-[16px]">location_on</span>
                                            {viewingVessel.location}
                                        </span>
                                    </div>
                                    <div className="flex justify-between border-b border-slate-200 dark:border-border-dark/50 pb-2">
                                        <span className="text-sm text-slate-500">Carga Actual</span>
                                        <span className="text-sm font-medium text-slate-900 dark:text-white flex items-center gap-1 truncate max-w-[150px]" title={viewingVessel.currentCargo}>
                                            <span className="material-symbols-outlined text-[16px] text-slate-400">inventory_2</span>
                                            {viewingVessel.currentCargo}
                                        </span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-sm text-slate-500">Última Actualización</span>
                                        <span className="text-sm font-medium text-slate-900 dark:text-white">{viewingVessel.lastUpdate}</span>
                                    </div>
                                </div>
                                <div className="mt-4 pt-3 border-t border-slate-200 dark:border-border-dark/50 flex gap-2">
                                    <button onClick={() => alert("Mostrando historial operativo...")} className="flex-1 bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-lg py-2 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-border-dark transition-colors">
                                        Historial
                                    </button>
                                    <button onClick={() => alert("Mostrando documentos de la nave...")} className="flex-1 bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-lg py-2 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-border-dark transition-colors">
                                        Documentación
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div className="mt-8 flex justify-end">
                             <button 
                                onClick={(e) => {
                                    setViewingVessel(null);
                                    handleEditClick(e as any, viewingVessel);
                                }}
                                className="text-primary hover:underline text-sm font-medium flex items-center gap-1"
                             >
                                <span className="material-symbols-outlined text-[18px]">edit</span>
                                Editar información completa
                             </button>
                        </div>
                    </div>
                </div>
             </div>
        )}

        {/* --- CARGO OPERATION MODAL --- */}
        {isCargoModalOpen && viewingVessel && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
                <div 
                    className="absolute inset-0 bg-slate-900/70 backdrop-blur-sm transition-opacity" 
                    onClick={() => setIsCargoModalOpen(false)}
                ></div>

                <div className="relative w-full max-w-md bg-white dark:bg-surface-dark rounded-xl shadow-2xl border border-slate-200 dark:border-border-dark flex flex-col overflow-hidden animate-fade-in-up">
                    <div className="px-6 py-4 border-b border-slate-200 dark:border-border-dark flex justify-between items-center bg-slate-50 dark:bg-surface-darker">
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                            <span className="material-symbols-outlined text-primary">inventory_2</span>
                            Operación de Carga
                        </h3>
                        <button onClick={() => setIsCargoModalOpen(false)} className="text-slate-400 hover:text-red-500 transition-colors">
                            <span className="material-symbols-outlined">close</span>
                        </button>
                    </div>

                    <form onSubmit={handleCargoUpdate} className="p-6 space-y-5">
                        <div className="p-3 bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30 rounded-lg flex items-center gap-3">
                            <div className="size-10 rounded-full bg-blue-100 dark:bg-blue-800 flex items-center justify-center text-blue-600 dark:text-white font-bold">
                                <span className="material-symbols-outlined">directions_boat</span>
                            </div>
                            <div>
                                <p className="text-xs text-blue-600 dark:text-blue-300 font-bold uppercase">Buque</p>
                                <p className="font-bold text-slate-900 dark:text-white">{viewingVessel.name}</p>
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1.5">Descripción de la Carga</label>
                            <input 
                                name="cargoDescription" 
                                type="text" 
                                defaultValue={viewingVessel.currentCargo}
                                placeholder="Ej. Soja, Vacío..." 
                                className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" 
                            />
                            <p className="text-xs text-slate-500 mt-1">Incluye producto y cantidad estimada.</p>
                        </div>

                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1.5">Estado Operativo</label>
                            <select 
                                name="operationStatus"
                                defaultValue={viewingVessel.status}
                                className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50"
                            >
                                <option value="Operativo">Operativo (Estándar)</option>
                                <option value="En Ruta">En Ruta (Navegando)</option>
                                <option value="Mantenimiento">Mantenimiento</option>
                                <option value="Inactivo">Inactivo / Fondeado</option>
                            </select>
                        </div>

                        <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-200 dark:border-border-dark mt-2">
                            <button type="button" onClick={() => setIsCargoModalOpen(false)} className="px-4 py-2 text-slate-600 dark:text-slate-300 font-medium hover:bg-slate-100 dark:hover:bg-surface-darker rounded-lg transition-colors">Cancelar</button>
                            <button type="submit" className="px-6 py-2 bg-primary hover:bg-primary-dark text-white font-bold rounded-lg shadow-lg shadow-primary/20 transition-all">Actualizar Estado</button>
                        </div>
                    </form>
                </div>
            </div>
        )}

        {/* --- ADD VESSEL MODAL --- */}
        {isAddModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                <div 
                    className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity" 
                    onClick={() => setIsAddModalOpen(false)}
                ></div>

                <div className="relative w-full max-w-lg bg-white dark:bg-surface-dark rounded-xl shadow-2xl border border-slate-200 dark:border-border-dark flex flex-col max-h-[90vh] overflow-hidden animate-fade-in-up">
                    <div className="px-6 py-4 border-b border-slate-200 dark:border-border-dark flex justify-between items-center bg-slate-50 dark:bg-surface-darker">
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                            <span className="material-symbols-outlined text-primary">add_circle</span>
                            Nueva Embarcación
                        </h3>
                        <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-red-500 transition-colors">
                            <span className="material-symbols-outlined">close</span>
                        </button>
                    </div>

                    <form onSubmit={handleAddVessel} className="p-6 overflow-y-auto space-y-5">
                         <div className="grid grid-cols-2 gap-4">
                            <div className="col-span-2">
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Nombre de la Embarcación</label>
                                <input name="name" type="text" required className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Matrícula</label>
                                <input name="mat" type="text" required className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Año Const.</label>
                                <input name="year" type="number" defaultValue="2020" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                            </div>
                         </div>
                         <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Tipo</label>
                                <select name="type" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50">
                                    <option value="Remolcador">Remolcador</option>
                                    <option value="Barcaza">Barcaza</option>
                                    <option value="Tanque">Tanque</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Capacidad</label>
                                <input name="capacity" type="text" placeholder="Ej. 2000 Ton" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                            </div>
                         </div>
                         <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Carga Actual (Opcional)</label>
                            <input name="currentCargo" type="text" placeholder="Ej. Soja, Vacío..." className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                         </div>
                         <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Estado Inicial</label>
                            <select name="status" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50">
                                <option value="Operativo">Operativo</option>
                                <option value="Inactivo">Inactivo</option>
                                <option value="Mantenimiento">Mantenimiento</option>
                            </select>
                         </div>

                        <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200 dark:border-border-dark mt-6">
                            <button type="button" onClick={() => setIsAddModalOpen(false)} className="px-4 py-2 text-slate-600 dark:text-slate-300 font-medium hover:bg-slate-100 dark:hover:bg-surface-darker rounded-lg transition-colors">Cancelar</button>
                            <button type="submit" className="px-6 py-2 bg-primary hover:bg-primary-dark text-white font-bold rounded-lg shadow-lg shadow-primary/20 transition-all">Guardar</button>
                        </div>
                    </form>
                </div>
            </div>
        )}

        {/* --- EDIT MODAL (Existing) --- */}
        {isEditModalOpen && editingVessel && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div 
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity" 
              onClick={handleCloseEditModal}
            ></div>

            <div className="relative w-full max-w-lg bg-white dark:bg-surface-dark rounded-xl shadow-2xl border border-slate-200 dark:border-border-dark flex flex-col max-h-[90vh] overflow-hidden animate-fade-in-up">
              
              <div className="px-6 py-4 border-b border-slate-200 dark:border-border-dark flex justify-between items-center bg-slate-50 dark:bg-surface-darker">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary">edit_square</span>
                  Editar Embarcación
                </h3>
                <button onClick={handleCloseEditModal} className="text-slate-400 hover:text-red-500 transition-colors">
                  <span className="material-symbols-outlined">close</span>
                </button>
              </div>

              <form onSubmit={handleSave} className="p-6 overflow-y-auto space-y-5">
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Nombre de la Embarcación</label>
                    <input 
                      type="text" 
                      name="name"
                      value={editingVessel.name}
                      onChange={handleChange}
                      className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Matrícula</label>
                    <input 
                      type="text" 
                      name="mat"
                      value={editingVessel.mat}
                      onChange={handleChange}
                      className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all font-mono"
                      required
                    />
                  </div>

                   <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">ID Interno</label>
                    <input 
                      type="text" 
                      name="id"
                      value={editingVessel.id}
                      onChange={handleChange}
                      readOnly
                      className="w-full rounded-lg border border-slate-200 dark:border-border-dark bg-slate-100 dark:bg-surface-darker px-4 py-2.5 text-slate-500 dark:text-slate-400 outline-none cursor-not-allowed"
                    />
                  </div>
                </div>

                <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Carga Actual</label>
                    <input 
                      type="text" 
                      name="currentCargo"
                      value={editingVessel.currentCargo}
                      onChange={handleChange}
                      placeholder="Ej. Soja, Vacío..."
                      className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all"
                    />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Tipo</label>
                    <select 
                      name="type"
                      value={editingVessel.type}
                      onChange={handleChange}
                      className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all appearance-none"
                    >
                      <option value="Remolcador">Remolcador</option>
                      <option value="Barcaza">Barcaza</option>
                      <option value="Tanque">Tanque</option>
                      <option value="Buque Motor">Buque Motor</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Estado</label>
                    <select 
                      name="status"
                      value={editingVessel.status}
                      onChange={handleChange}
                      className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all appearance-none"
                    >
                      <option value="Operativo">Operativo</option>
                      <option value="Mantenimiento">Mantenimiento</option>
                      <option value="Inactivo">Inactivo</option>
                      <option value="En Ruta">En Ruta</option>
                    </select>
                  </div>
                </div>

                <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200 dark:border-border-dark mt-6">
                  <button 
                    type="button" 
                    onClick={handleCloseEditModal}
                    className="px-4 py-2 text-slate-600 dark:text-slate-300 font-medium hover:bg-slate-100 dark:hover:bg-surface-darker rounded-lg transition-colors"
                  >
                    Cancelar
                  </button>
                  <button 
                    type="submit" 
                    className="px-6 py-2 bg-primary hover:bg-primary-dark text-white font-bold rounded-lg shadow-lg shadow-primary/20 transition-all flex items-center gap-2"
                  >
                    <span className="material-symbols-outlined text-[20px]">save</span>
                    Guardar Cambios
                  </button>
                </div>

              </form>
            </div>
          </div>
        )}

        {/* --- DELETE CONFIRMATION MODAL (NEW) --- */}
        {isDeleteModalOpen && vesselToDelete && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
                <div 
                    className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm transition-opacity" 
                    onClick={() => setIsDeleteModalOpen(false)}
                ></div>
                
                <div className="relative w-full max-w-sm bg-white dark:bg-surface-dark rounded-xl shadow-2xl border border-slate-200 dark:border-border-dark p-6 animate-fade-in-up">
                    <div className="flex flex-col items-center text-center">
                        <div className="size-16 bg-red-100 dark:bg-red-900/20 text-red-500 rounded-full flex items-center justify-center mb-4">
                            <span className="material-symbols-outlined text-4xl">warning</span>
                        </div>
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">¿Eliminar Embarcación?</h3>
                        <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">
                            Estás a punto de eliminar <strong className="text-slate-900 dark:text-white">{vesselToDelete.name}</strong> ({vesselToDelete.id}). Esta acción no se puede deshacer.
                        </p>
                        
                        <div className="flex gap-3 w-full">
                            <button 
                                onClick={() => setIsDeleteModalOpen(false)}
                                className="flex-1 py-2.5 bg-slate-100 dark:bg-surface-darker hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-700 dark:text-white font-bold rounded-lg transition-colors"
                            >
                                Cancelar
                            </button>
                            <button 
                                onClick={confirmDelete}
                                className="flex-1 py-2.5 bg-red-500 hover:bg-red-600 text-white font-bold rounded-lg shadow-lg shadow-red-500/20 transition-colors"
                            >
                                Eliminar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default Fleet;
