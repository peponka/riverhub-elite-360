
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/Toast';

const Register: React.FC = () => {
  const { register } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
      companyName: '',
      fiscalId: '',
      email: '',
      password: '',
      confirmPassword: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
        showToast('Las contraseñas no coinciden', 'error');
        return;
    }

    setIsSubmitting(true);
    
    try {
        const { error } = await register(formData.email, formData.password, formData.companyName);
        if (error) {
            showToast(error, 'error');
        } else {
            showToast('Cuenta creada exitosamente', 'success');
            navigate('/dashboard');
        }
    } catch (err) {
        showToast('Error al registrar usuario', 'error');
    } finally {
        setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background-light dark:bg-background-dark flex flex-col items-center justify-center p-4 font-display">
      <div className="w-full max-w-[600px] bg-white dark:bg-surface-dark rounded-2xl border border-slate-200 dark:border-border-dark p-8 md:p-10 shadow-2xl">
        <div className="flex flex-col items-center mb-8 text-center">
          <div className="size-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-4">
            <span className="material-symbols-outlined text-3xl">anchor</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Registra tu flota en AquaFleet</h1>
          <p className="text-slate-500 dark:text-[#9db2b9]">
              Crea tu cuenta corporativa para comenzar a operar.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-medium text-slate-700 dark:text-slate-200">Nombre de la Empresa</span>
              <input 
                name="companyName"
                value={formData.companyName}
                onChange={handleChange}
                className="form-input rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] text-slate-900 dark:text-white px-4 py-2.5 focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none" 
                type="text" 
                placeholder="Ej. Naviera del Sur" 
                required 
              />
            </label>
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-medium text-slate-700 dark:text-slate-200">ID Fiscal (CUIT/RUC)</span>
              <input 
                name="fiscalId"
                value={formData.fiscalId}
                onChange={handleChange}
                className="form-input rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] text-slate-900 dark:text-white px-4 py-2.5 focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none" 
                type="text" 
                placeholder="30-12345678-9" 
              />
            </label>
          </div>

          <label className="flex flex-col gap-1.5">
            <span className="text-sm font-medium text-slate-700 dark:text-slate-200">Email Corporativo</span>
            <input 
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="form-input rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] text-slate-900 dark:text-white px-4 py-2.5 focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none" 
                type="email" 
                placeholder="admin@empresa.com" 
                required 
            />
          </label>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-medium text-slate-700 dark:text-slate-200">Contraseña</span>
              <input 
                name="password"
                value={formData.password}
                onChange={handleChange}
                className="form-input rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] text-slate-900 dark:text-white px-4 py-2.5 focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none" 
                type="password" 
                placeholder="••••••••" 
                required 
              />
            </label>
            <label className="flex flex-col gap-1.5">
              <span className="text-sm font-medium text-slate-700 dark:text-slate-200">Confirmar Contraseña</span>
              <input 
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                className="form-input rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] text-slate-900 dark:text-white px-4 py-2.5 focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none" 
                type="password" 
                placeholder="••••••••" 
                required 
              />
            </label>
          </div>

          <div className="flex items-start gap-3 mt-2">
            <input type="checkbox" className="mt-1 rounded border-slate-300 dark:border-border-dark text-primary focus:ring-primary bg-slate-50 dark:bg-[#111618]" required />
            <span className="text-sm text-slate-500 dark:text-[#9db2b9]">Acepto los <a href="#" className="text-primary hover:underline">Términos y Condiciones</a> y la <a href="#" className="text-primary hover:underline">Política de Privacidad</a>.</span>
          </div>

          <button 
            type="submit" 
            disabled={isSubmitting}
            className={`w-full bg-primary hover:bg-primary-dark text-white font-bold py-3.5 rounded-lg transition-all shadow-lg shadow-primary/20 mt-2 ${isSubmitting ? 'opacity-70 cursor-wait' : ''}`}
          >
            {isSubmitting ? 'Creando cuenta...' : 'Crear Cuenta Corporativa'}
          </button>
        </form>

        <div className="mt-8 text-center border-t border-slate-200 dark:border-border-dark pt-6">
          <p className="text-sm text-slate-500 dark:text-[#9db2b9]">
            ¿Ya tienes una cuenta? <Link to="/login" className="text-primary font-bold hover:underline ml-1">Iniciar Sesión</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;
