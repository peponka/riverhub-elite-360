import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';

// --- Reusable Components ---
const Toggle = ({ label, description, checked, onChange }: { label: string, description?: string, checked: boolean, onChange: (v: boolean) => void }) => (
  <div className="flex items-center justify-between py-4 border-b border-slate-100 dark:border-border-dark last:border-0">
    <div>
      <p className="text-sm font-medium text-slate-900 dark:text-white">{label}</p>
      {description && <p className="text-xs text-slate-500 dark:text-[#9db2b9] mt-0.5">{description}</p>}
    </div>
    <button 
      onClick={() => onChange(!checked)}
      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-primary/50 ${checked ? 'bg-primary' : 'bg-slate-200 dark:bg-slate-700'}`}
    >
      <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${checked ? 'translate-x-6' : 'translate-x-1'}`} />
    </button>
  </div>
);

const SectionHeader = ({ title, subtitle }: { title: string, subtitle: string }) => (
  <div className="mb-6">
    <h2 className="text-lg font-bold text-slate-900 dark:text-white">{title}</h2>
    <p className="text-sm text-slate-500 dark:text-[#9db2b9]">{subtitle}</p>
  </div>
);

const InputGroup = ({ label, type = "text", defaultValue, disabled = false }: { label: string, type?: string, defaultValue: string, disabled?: boolean }) => (
    <div className="flex flex-col gap-1.5">
        <label className="text-xs font-bold text-slate-500 uppercase tracking-wide">{label}</label>
        <input 
            type={type} 
            defaultValue={defaultValue} 
            disabled={disabled}
            className={`w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2.5 text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all ${disabled ? 'opacity-60 cursor-not-allowed' : ''}`}
        />
    </div>
);

const Settings: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'general' | 'notifications' | 'security' | 'system'>('general');
  const { language, setLanguage } = useLanguage(); // Language Hook

  // --- Mock State for Toggles ---
  const [notifEmail, setNotifEmail] = useState(true);
  const [notifPush, setNotifPush] = useState(true);
  const [alertCritical, setAlertCritical] = useState(true);
  const [alertMaintenance, setAlertMaintenance] = useState(true);
  const [alertWeather, setAlertWeather] = useState(false);
  const [twoFactor, setTwoFactor] = useState(false);

  // --- Render Functions for Tabs ---
  const renderGeneral = () => (
    <div className="animate-fade-in">
        <SectionHeader title="Perfil y Preferencias" subtitle="Administra tu información personal y apariencia de la aplicación." />
        
        {/* Avatar Section */}
        <div className="flex items-center gap-6 mb-8 bg-slate-50 dark:bg-surface-darker p-4 rounded-xl border border-slate-200 dark:border-border-dark">
            <div className="relative">
                <img 
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuCNwgFHJoYptmcRwaXtmAb_7-PBlFZWVuNRjuVLm7YrocUBJmoXaR0Ignk-j3R32osPKa3KJb5n2xc-0jyyD__WReaPTuVDL1ae_3qgfZn5Q9CF8EhDJXm-7rHk0xilgjHxiVerVzi403GGhMk7ucKHGlMQApWjQdxjerq4EZ9ndOYMR0fPw1jBhdkmI_gcDU6MYVmy8JynuyHW4eV8YobFxGTq0o2guRm8_3dsKdVTeYLPlBD2fQYHFwqSX-89s8XJdDvuOfw8gAtr" 
                    alt="Avatar" 
                    className="size-20 rounded-full object-cover ring-4 ring-white dark:ring-surface-dark"
                />
                <button className="absolute bottom-0 right-0 bg-primary text-white p-1.5 rounded-full shadow-lg hover:bg-primary-dark transition-colors">
                    <span className="material-symbols-outlined text-[16px]">photo_camera</span>
                </button>
            </div>
            <div>
                <h3 className="font-bold text-slate-900 dark:text-white">Carlos M.</h3>
                <p className="text-sm text-slate-500 dark:text-[#9db2b9]">Jefe de Flota • Naviera del Sur</p>
                <button className="mt-2 text-xs font-bold text-primary hover:underline">Cambiar foto</button>
            </div>
        </div>

        {/* Forms */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-8">
            <InputGroup label="Nombre Completo" defaultValue="Carlos Martínez" />
            <InputGroup label="Correo Electrónico" defaultValue="carlos.m@aquafleet.com" type="email" />
            <InputGroup label="Cargo / Rol" defaultValue="Jefe de Operaciones Fluviales" />
            <InputGroup label="Teléfono de Contacto" defaultValue="+595 981 123 456" />
        </div>

        <SectionHeader title="Idioma y Región" subtitle="Configuración de localización e interfaz." />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-6">
            <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wide">Idioma / Language</label>
                <select 
                    value={language}
                    onChange={(e) => setLanguage(e.target.value as any)}
                    className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2.5 text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none"
                >
                    <option value="es">Español (Latinoamérica)</option>
                    <option value="pt">Português (Brasil)</option>
                    <option value="en">English (US)</option>
                </select>
                <p className="text-[10px] text-slate-400">Cambia los menús y formatos de moneda (USD/BRL/ARS).</p>
            </div>
            <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wide">Zona Horaria</label>
                <select className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2.5 text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none">
                    <option>(GMT-04:00) Asunción</option>
                    <option>(GMT-03:00) Buenos Aires</option>
                    <option>(GMT-03:00) São Paulo</option>
                    <option>(GMT-04:00) La Paz</option>
                </select>
            </div>
        </div>
    </div>
  );

  const renderNotifications = () => (
    <div className="animate-fade-in">
        <SectionHeader title="Configuración de Alertas" subtitle="Decide qué notificaciones recibir y a través de qué canales." />
        
        <div className="bg-slate-50 dark:bg-surface-darker rounded-xl border border-slate-200 dark:border-border-dark p-5 mb-6">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase mb-4 tracking-wider">Canales</h3>
            <Toggle 
                label="Notificaciones por Correo" 
                description="Recibe resúmenes diarios y alertas críticas en tu email."
                checked={notifEmail} 
                onChange={setNotifEmail} 
            />
            <Toggle 
                label="Notificaciones Push" 
                description="Alertas en tiempo real en tu navegador y dispositivo móvil."
                checked={notifPush} 
                onChange={setNotifPush} 
            />
        </div>

        <div className="bg-slate-50 dark:bg-surface-darker rounded-xl border border-slate-200 dark:border-border-dark p-5">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase mb-4 tracking-wider">Tipos de Evento</h3>
            <Toggle 
                label="Alertas Críticas de Flota" 
                description="Fallas de motor, paradas inesperadas, botón de pánico."
                checked={alertCritical} 
                onChange={setAlertCritical} 
            />
            <Toggle 
                label="Mantenimiento Preventivo" 
                description="Avisos 7 días antes del vencimiento de un servicio."
                checked={alertMaintenance} 
                onChange={setAlertMaintenance} 
            />
             <Toggle 
                label="Alertas Meteorológicas" 
                description="Cambios bruscos en el nivel del río o tormentas."
                checked={alertWeather} 
                onChange={setAlertWeather} 
            />
             <Toggle 
                label="Reportes de Viaje" 
                description="Notificación al arribar o zarpar de puerto."
                checked={true} 
                onChange={() => {}} 
            />
        </div>
    </div>
  );

  const renderSecurity = () => (
    <div className="animate-fade-in">
         <SectionHeader title="Seguridad de la Cuenta" subtitle="Protege tu cuenta y gestiona tus sesiones activas." />

         <div className="bg-slate-50 dark:bg-surface-darker rounded-xl border border-slate-200 dark:border-border-dark p-5 mb-6">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase mb-4 tracking-wider">Contraseña</h3>
            <div className="space-y-4 max-w-md">
                <InputGroup label="Contraseña Actual" type="password" defaultValue="********" />
                <InputGroup label="Nueva Contraseña" type="password" defaultValue="" />
                <InputGroup label="Confirmar Nueva Contraseña" type="password" defaultValue="" />
                <button className="bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-white px-4 py-2 rounded-lg text-sm font-bold transition-colors">
                    Actualizar Contraseña
                </button>
            </div>
         </div>

         <div className="bg-slate-50 dark:bg-surface-darker rounded-xl border border-slate-200 dark:border-border-dark p-5 mb-6">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase mb-4 tracking-wider">Autenticación</h3>
            <Toggle 
                label="Autenticación de Dos Factores (2FA)" 
                description="Añade una capa extra de seguridad usando una app autenticadora."
                checked={twoFactor} 
                onChange={setTwoFactor} 
            />
         </div>

         <div className="border-t border-slate-200 dark:border-border-dark pt-6">
             <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase mb-4 tracking-wider">Sesiones Activas</h3>
             <div className="space-y-3">
                 <div className="flex items-center justify-between p-3 bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-lg">
                    <div className="flex items-center gap-3">
                        <span className="material-symbols-outlined text-primary">laptop_mac</span>
                        <div>
                            <p className="text-sm font-bold text-slate-900 dark:text-white">Windows PC - Chrome</p>
                            <p className="text-xs text-slate-500 dark:text-[#9db2b9]">Asunción, PY • Sesión actual</p>
                        </div>
                    </div>
                    <span className="text-xs font-bold text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded">Activo</span>
                 </div>
                 <div className="flex items-center justify-between p-3 bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-lg opacity-75">
                    <div className="flex items-center gap-3">
                        <span className="material-symbols-outlined text-slate-400">smartphone</span>
                        <div>
                            <p className="text-sm font-bold text-slate-900 dark:text-white">iPhone 13 - App</p>
                            <p className="text-xs text-slate-500 dark:text-[#9db2b9]">Santos, BR • Hace 2 días</p>
                        </div>
                    </div>
                    <button className="text-xs font-bold text-red-500 hover:underline">Cerrar</button>
                 </div>
             </div>
         </div>
    </div>
  );

  const renderSystem = () => (
      <div className="animate-fade-in">
          <SectionHeader title="Configuración del Sistema" subtitle="Parámetros técnicos de la aplicación AquaFleet." />
          
          <div className="bg-slate-50 dark:bg-surface-darker rounded-xl border border-slate-200 dark:border-border-dark p-5 mb-6">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase mb-4 tracking-wider">Parámetros de Flota</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <InputGroup label="Umbral de Combustible Bajo (%)" defaultValue="15" type="number" />
                <InputGroup label="Alerta de Velocidad Máxima (Nudos)" defaultValue="12" type="number" />
                <InputGroup label="Días Aviso Mantenimiento" defaultValue="7" type="number" />
                <InputGroup label="Radio de Geofence Puerto (Metros)" defaultValue="500" type="number" />
            </div>
          </div>

          <div className="bg-slate-50 dark:bg-surface-darker rounded-xl border border-slate-200 dark:border-border-dark p-5">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase mb-4 tracking-wider">Integraciones y API</h3>
             <InputGroup label="Clave API (Solo Lectura)" defaultValue="ak_live_84920384029384..." disabled={true} />
             <p className="text-xs text-slate-500 dark:text-[#9db2b9] mt-2">Usa esta clave para conectar sistemas de terceros (ERP, SAP) con AquaFleet.</p>
             <button className="mt-4 border border-slate-300 dark:border-border-dark hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 px-4 py-2 rounded-lg text-sm font-bold transition-colors flex items-center gap-2">
                 <span className="material-symbols-outlined text-[18px]">refresh</span>
                 Regenerar Clave
             </button>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-200 dark:border-border-dark">
              <h3 className="text-sm font-bold text-red-500 uppercase mb-2 tracking-wider">Zona de Peligro</h3>
              <p className="text-sm text-slate-500 mb-4">Estas acciones son irreversibles.</p>
              <button className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-lg shadow-red-500/20 transition-all">
                  Eliminar Organización
              </button>
          </div>
      </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Configuración</h1>
            <p className="text-slate-500 dark:text-[#9db2b9] mt-1">Administra tu cuenta y las preferencias del sistema.</p>
        </div>
        <button className="bg-primary hover:bg-primary-dark text-white px-6 py-2.5 rounded-lg font-bold shadow-lg shadow-primary/20 flex items-center gap-2 transition-colors">
            <span className="material-symbols-outlined">save</span> Guardar Cambios
        </button>
      </div>

      <div className="flex flex-col lg:flex-row gap-8 mt-6">
        {/* Sidebar Navigation */}
        <aside className="w-full lg:w-64 shrink-0">
            <nav className="flex lg:flex-col gap-2 overflow-x-auto pb-2 lg:pb-0">
                {[
                    { id: 'general', icon: 'person', label: 'General' },
                    { id: 'notifications', icon: 'notifications', label: 'Notificaciones' },
                    { id: 'security', icon: 'lock', label: 'Seguridad' },
                    { id: 'system', icon: 'settings_applications', label: 'Sistema' }
                ].map((item) => (
                    <button
                        key={item.id}
                        onClick={() => setActiveTab(item.id as any)}
                        className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap
                        ${activeTab === item.id 
                            ? 'bg-white dark:bg-surface-dark text-primary shadow-sm border border-slate-200 dark:border-border-dark' 
                            : 'text-slate-500 dark:text-[#9db2b9] hover:bg-slate-100 dark:hover:bg-surface-darker hover:text-slate-900 dark:hover:text-white'
                        }`}
                    >
                        <span className={`material-symbols-outlined ${activeTab === item.id ? 'filled' : ''}`}>{item.icon}</span>
                        {item.label}
                    </button>
                ))}
            </nav>
        </aside>

        {/* Main Content Area */}
        <div className="flex-1 bg-white dark:bg-surface-dark rounded-2xl border border-slate-200 dark:border-border-dark shadow-sm p-6 md:p-8 min-h-[600px]">
            {activeTab === 'general' && renderGeneral()}
            {activeTab === 'notifications' && renderNotifications()}
            {activeTab === 'security' && renderSecurity()}
            {activeTab === 'system' && renderSystem()}
        </div>
      </div>
    </div>
  );
};

export default Settings;