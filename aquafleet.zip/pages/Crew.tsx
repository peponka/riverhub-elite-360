import React, { useState, useMemo } from 'react';

// --- Types & Mock Data ---

interface Certification {
  name: string;
  issueDate: string;
  expiryDate: string;
  status: 'Valid' | 'Expiring' | 'Expired';
  fileUrl?: string;
}

interface ServiceRecord {
  vessel: string;
  role: string;
  startDate: string;
  endDate: string | 'Presente';
}

interface CrewMember {
  id: string;
  name: string;
  role: 'Capitán' | 'Jefe de Máquinas' | 'Timonel' | 'Marinero' | 'Cocinero' | 'Baqueano';
  status: 'Embarcado' | 'Franco' | 'Licencia' | 'Inactivo';
  vesselId?: string; 
  vesselName?: string;
  phone: string;
  email: string;
  avatarUrl: string;
  certifications: Certification[];
  history: ServiceRecord[];
  totalSeaTime: string;
  daysOnBoard: number; // Current rotation days
  rotationLimit: number; // Max days before mandatory leave
}

const MOCK_CREW: CrewMember[] = [
  {
    id: "CREW-001", name: "Roberto Gómez", role: "Capitán", status: "Embarcado",
    vesselName: "Remolcador Titan III", phone: "+595 981 555 001", email: "r.gomez@aquafleet.com",
    avatarUrl: "https://i.pravatar.cc/300?u=CREW-001", totalSeaTime: "15 años",
    daysOnBoard: 25, rotationLimit: 30,
    certifications: [
      { name: "Patrón de Cabotaje", issueDate: "2020-01-10", expiryDate: "2025-01-10", status: "Expiring" },
      { name: "Examen Médico", issueDate: "2023-11-01", expiryDate: "2024-11-01", status: "Valid" },
      { name: "Curso OMI 1.13", issueDate: "2022-05-15", expiryDate: "2027-05-15", status: "Valid" }
    ],
    history: [
        { vessel: "Remolcador Titan III", role: "Capitán", startDate: "2023-01-10", endDate: "Presente" },
        { vessel: "Barcaza T-55", role: "Capitán", startDate: "2020-03-01", endDate: "2022-12-15" },
        { vessel: "Remolcador Alpha", role: "Timonel", startDate: "2015-06-20", endDate: "2020-02-28" }
    ]
  },
  {
    id: "CREW-002", name: "Luis Fernández", role: "Jefe de Máquinas", status: "Franco",
    phone: "+595 982 444 022", email: "l.fernandez@aquafleet.com",
    avatarUrl: "https://i.pravatar.cc/300?u=CREW-002", totalSeaTime: "10 años",
    daysOnBoard: 0, rotationLimit: 30,
    certifications: [
      { name: "Conductor de Máquinas", issueDate: "2019-03-20", expiryDate: "2024-03-20", status: "Expired" }
    ],
    history: [
        { vessel: "Remolcador Alpha", role: "Jefe de Máquinas", startDate: "2021-05-10", endDate: "2024-02-01" }
    ]
  },
  {
    id: "CREW-003", name: "Carlos Villagra", role: "Timonel", status: "Embarcado",
    vesselName: "Remolcador Titan III", phone: "+595 971 333 111", email: "c.villagra@aquafleet.com",
    avatarUrl: "https://i.pravatar.cc/300?u=CREW-003", totalSeaTime: "5 años",
    daysOnBoard: 10, rotationLimit: 30,
    certifications: [
      { name: "Timonel", issueDate: "2021-06-01", expiryDate: "2026-06-01", status: "Valid" }
    ],
    history: []
  },
  {
    id: "CREW-004", name: "Mario Benítez", role: "Marinero", status: "Embarcado",
    vesselName: "Barcaza B-102", phone: "+595 985 222 999", email: "m.benitez@aquafleet.com",
    avatarUrl: "https://i.pravatar.cc/300?u=CREW-004", totalSeaTime: "2 años",
    daysOnBoard: 29, rotationLimit: 30,
    certifications: [
      { name: "Marinero de Cubierta", issueDate: "2022-09-10", expiryDate: "2027-09-10", status: "Valid" }
    ],
    history: []
  },
  {
    id: "CREW-006", name: "Jorge Almirón", role: "Baqueano", status: "Embarcado",
    vesselName: "Remolcador Alpha Uno", phone: "+595 981 111 222", email: "j.almiron@aquafleet.com",
    avatarUrl: "https://i.pravatar.cc/300?u=CREW-006", totalSeaTime: "25 años",
    daysOnBoard: 45, rotationLimit: 40,
    certifications: [
      { name: "Conocimiento de Zona", issueDate: "2018-05-05", expiryDate: "2023-05-05", status: "Expired" }
    ],
    history: []
  }
];

// --- Helper Components ---

const KPICard = ({ label, value, subtext, icon, color }: any) => (
    <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-4 flex items-center gap-4 shadow-sm hover:border-slate-300 transition-colors">
        <div className={`size-12 rounded-full ${color} bg-opacity-10 flex items-center justify-center text-xl`}>
            <span className="material-symbols-outlined">{icon}</span>
        </div>
        <div>
            <p className="text-xs text-slate-500 dark:text-[#9db2b9] font-bold uppercase tracking-wider">{label}</p>
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white">{value}</h3>
            {subtext && <p className="text-xs text-slate-400">{subtext}</p>}
        </div>
    </div>
);

const StatusBadge = ({ status }: { status: CrewMember['status'] }) => {
    let styles = "";
    switch(status) {
        case 'Embarcado': styles = "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"; break;
        case 'Franco': styles = "bg-blue-500/10 text-blue-500 border-blue-500/20"; break;
        case 'Licencia': styles = "bg-amber-500/10 text-amber-500 border-amber-500/20"; break;
        case 'Inactivo': styles = "bg-slate-500/10 text-slate-500 border-slate-500/20"; break;
    }
    return (
        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase border ${styles} shadow-sm`}>
            {status}
        </span>
    );
};

const RoleBadge = ({ role }: { role: string }) => (
    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-surface-darker px-2 py-0.5 rounded border border-slate-200 dark:border-border-dark uppercase tracking-wider">
        {role === 'Capitán' && <span className="material-symbols-outlined text-[12px] text-primary">stars</span>}
        {role === 'Jefe de Máquinas' && <span className="material-symbols-outlined text-[12px] text-orange-500">settings</span>}
        {role}
    </span>
);

const Crew: React.FC = () => {
  const [crewList, setCrewList] = useState<CrewMember[]>(MOCK_CREW);
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("Todos");
  const [statusFilter, setStatusFilter] = useState("Todos");
  const [crewMemberFilter, setCrewMemberFilter] = useState("Todos"); // New Filter
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  
  // Modals
  const [selectedMember, setSelectedMember] = useState<CrewMember | null>(null);
  const [activeTab, setActiveTab] = useState<'general' | 'documents' | 'history'>('general');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false); // To toggle edit mode in detail modal

  // Add/Edit Crew State
  const [formData, setFormData] = useState<Partial<CrewMember>>({
      name: '', role: 'Marinero', status: 'Franco', phone: '', email: ''
  });

  // Derived Data
  const filteredCrew = useMemo(() => {
    return crewList.filter(member => {
        const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesRole = roleFilter === "Todos" || member.role === roleFilter;
        const matchesStatus = statusFilter === "Todos" || member.status === statusFilter;
        const matchesCrewMember = crewMemberFilter === "Todos" || member.name === crewMemberFilter;
        return matchesSearch && matchesRole && matchesStatus && matchesCrewMember;
    });
  }, [searchTerm, roleFilter, statusFilter, crewMemberFilter, crewList]);

  // Generate lists for dropdowns
  const roles = ["Todos", "Capitán", "Jefe de Máquinas", "Timonel", "Marinero", "Cocinero", "Baqueano"];
  const statuses = ["Todos", "Embarcado", "Franco", "Licencia"];
  const crewNames = useMemo(() => ["Todos", ...crewList.map(c => c.name).sort()], [crewList]);

  const stats = {
      total: crewList.length,
      embarked: crewList.filter(m => m.status === 'Embarcado').length,
      leave: crewList.filter(m => m.status === 'Franco').length,
      docsIssue: crewList.filter(m => m.certifications?.some(c => c.status === 'Expired' || c.status === 'Expiring')).length
  };

  // --- Actions ---

  const handleAddCrew = (e: React.FormEvent) => {
      e.preventDefault();
      const newMember: CrewMember = {
          id: `CREW-${Math.floor(Math.random() * 10000)}`,
          name: formData.name || 'Nuevo Tripulante',
          role: formData.role as any,
          status: formData.status as any,
          phone: formData.phone || '-',
          email: formData.email || '-',
          avatarUrl: `https://i.pravatar.cc/300?u=${Math.random()}`,
          certifications: [],
          history: [],
          totalSeaTime: '0 años',
          daysOnBoard: 0,
          rotationLimit: 30
      };
      setCrewList([...crewList, newMember]);
      setIsAddModalOpen(false);
      setFormData({ name: '', role: 'Marinero', status: 'Franco', phone: '', email: '' });
  };

  const handleUpdateCrew = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMember) return;
    
    const updatedList = crewList.map(c => 
        c.id === selectedMember.id ? { ...c, ...formData } as CrewMember : c
    );
    setCrewList(updatedList);
    setSelectedMember({ ...selectedMember, ...formData } as CrewMember);
    setIsEditing(false);
  };

  const handleExportProfile = (member: CrewMember) => {
    const lines = [
        "----------------------------------------",
        "       AQUAFLEET - FICHA DE TRIPULANTE  ",
        "----------------------------------------",
        `ID: ${member.id}`,
        `Nombre: ${member.name}`,
        `Cargo: ${member.role}`,
        `Estado Actual: ${member.status}`,
        `Buque Asignado: ${member.vesselName || "Sin asignar"}`,
        "",
        "--- INFORMACIÓN DE CONTACTO ---",
        `Teléfono: ${member.phone}`,
        `Email: ${member.email}`,
        "",
        "--- ESTADÍSTICAS OPERATIVAS ---",
        `Antigüedad: ${member.totalSeaTime}`,
        `Días en Rotación Actual: ${member.daysOnBoard}`,
        "",
        "--- DOCUMENTACIÓN ---",
        ...member.certifications.map(c => `- ${c.name} (Vence: ${c.expiryDate}) [${c.status}]`),
        "",
        "----------------------------------------",
        `Generado: ${new Date().toLocaleString()}`,
        "----------------------------------------",
    ];

    const blob = new Blob([lines.join("\n")], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Ficha_${member.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const openAddModal = () => {
      setFormData({ name: '', role: 'Marinero', status: 'Franco', phone: '', email: '' });
      setIsAddModalOpen(true);
  };

  const startEditing = (member: CrewMember) => {
      setFormData({
          name: member.name,
          role: member.role,
          status: member.status,
          phone: member.phone,
          email: member.email,
          vesselName: member.vesselName
      });
      setIsEditing(true);
  };

  // --- Render Functions for Modal Tabs ---
  const renderGeneralTab = (member: CrewMember) => {
    if (isEditing) {
        return (
            <form onSubmit={handleUpdateCrew} className="space-y-4 animate-fade-in">
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nombre</label>
                    <input type="text" className="w-full border rounded-lg p-2 dark:bg-surface-darker dark:border-border-dark" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Rol</label>
                        <select className="w-full border rounded-lg p-2 dark:bg-surface-darker dark:border-border-dark" value={formData.role} onChange={e => setFormData({...formData, role: e.target.value as any})}>
                            {roles.slice(1).map(r => <option key={r} value={r}>{r}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Estado</label>
                        <select className="w-full border rounded-lg p-2 dark:bg-surface-darker dark:border-border-dark" value={formData.status} onChange={e => setFormData({...formData, status: e.target.value as any})}>
                            {statuses.slice(1).map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                    </div>
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Teléfono</label>
                        <input type="text" className="w-full border rounded-lg p-2 dark:bg-surface-darker dark:border-border-dark" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Email</label>
                        <input type="text" className="w-full border rounded-lg p-2 dark:bg-surface-darker dark:border-border-dark" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} />
                    </div>
                 </div>
                 <div className="flex justify-end gap-2 pt-4">
                     <button type="button" onClick={() => setIsEditing(false)} className="px-4 py-2 text-slate-500 hover:bg-slate-100 rounded-lg">Cancelar</button>
                     <button type="submit" className="px-4 py-2 bg-primary text-white rounded-lg font-bold">Guardar Cambios</button>
                 </div>
            </form>
        );
    }

    return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-fade-in">
        <div className="bg-slate-50 dark:bg-surface-darker/50 p-4 rounded-xl border border-slate-100 dark:border-border-dark">
            <h3 className="text-xs font-bold text-slate-500 uppercase mb-3">Información de Contacto</h3>
            <div className="space-y-3 text-sm">
                <div className="flex items-center gap-3">
                    <div className="size-8 rounded-lg bg-white dark:bg-surface-dark flex items-center justify-center text-slate-400">
                        <span className="material-symbols-outlined text-[18px]">phone</span>
                    </div>
                    <div>
                        <p className="text-xs text-slate-500">Móvil</p>
                        <p className="text-slate-900 dark:text-white font-medium">{member.phone}</p>
                    </div>
                </div>
                <div className="flex items-center gap-3">
                    <div className="size-8 rounded-lg bg-white dark:bg-surface-dark flex items-center justify-center text-slate-400">
                        <span className="material-symbols-outlined text-[18px]">mail</span>
                    </div>
                    <div>
                         <p className="text-xs text-slate-500">Correo</p>
                         <p className="text-slate-900 dark:text-white font-medium">{member.email}</p>
                    </div>
                </div>
            </div>
        </div>
        <div className="bg-slate-50 dark:bg-surface-darker/50 p-4 rounded-xl border border-slate-100 dark:border-border-dark">
            <h3 className="text-xs font-bold text-slate-500 uppercase mb-3">Situación Actual</h3>
            <div className="space-y-3">
                <div className="flex justify-between items-center border-b border-slate-200 dark:border-border-dark/50 pb-2">
                    <span className="text-sm text-slate-600 dark:text-slate-300">Estado</span>
                    <StatusBadge status={member.status} />
                </div>
                <div className="flex justify-between items-center border-b border-slate-200 dark:border-border-dark/50 pb-2">
                    <span className="text-sm text-slate-600 dark:text-slate-300">Buque</span>
                    <span className="text-sm font-bold text-primary flex items-center gap-1 cursor-pointer hover:underline">
                         <span className="material-symbols-outlined text-[16px]">directions_boat</span>
                         {member.vesselName || "N/A"}
                    </span>
                </div>
                 <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600 dark:text-slate-300">Días Embarcado</span>
                    <span className="font-mono font-bold text-slate-900 dark:text-white">{member.daysOnBoard} días</span>
                </div>
            </div>
            <button className="w-full mt-4 bg-white dark:bg-surface-dark border border-slate-300 dark:border-border-dark text-slate-700 dark:text-white font-bold py-2 rounded-lg text-sm hover:bg-slate-50 dark:hover:bg-border-dark transition-colors flex items-center justify-center gap-2">
                <span className="material-symbols-outlined text-[18px]">swap_horiz</span>
                Transferir de Buque
            </button>
        </div>

        {/* Rotation Summary Widget */}
        <div className="col-span-1 md:col-span-2 bg-slate-50 dark:bg-surface-darker/50 p-4 rounded-xl border border-slate-100 dark:border-border-dark">
            <h3 className="text-xs font-bold text-slate-500 uppercase mb-3">Ciclo de Rotación</h3>
            <div className="flex items-center gap-4">
                 <div className="flex-1">
                     <div className="flex justify-between mb-1">
                         <span className="text-xs font-bold text-slate-700 dark:text-white">Progreso de Marea</span>
                         <span className="text-xs text-slate-500">{member.daysOnBoard} / {member.rotationLimit} días</span>
                     </div>
                     <div className="h-3 w-full bg-slate-200 dark:bg-surface-dark rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-500 rounded-full" style={{width: `${Math.min((member.daysOnBoard/member.rotationLimit)*100, 100)}%`}}></div>
                     </div>
                 </div>
                 <div className="text-center px-4 border-l border-slate-200 dark:border-border-dark">
                     <p className="text-xs text-slate-500">Días Restantes</p>
                     <p className="text-xl font-bold text-slate-900 dark:text-white">{Math.max(0, member.rotationLimit - member.daysOnBoard)}</p>
                 </div>
            </div>
        </div>
    </div>
    );
  };

  const renderDocumentsTab = (member: CrewMember) => (
    <div className="space-y-4 animate-fade-in">
        <div className="border border-dashed border-slate-300 dark:border-border-dark rounded-xl p-6 flex flex-col items-center justify-center text-center bg-slate-50 dark:bg-surface-darker/30 hover:bg-slate-100 dark:hover:bg-surface-darker transition-colors cursor-pointer group">
             <div className="size-12 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                 <span className="material-symbols-outlined">cloud_upload</span>
             </div>
             <p className="mt-2 text-sm font-bold text-slate-900 dark:text-white">Subir nuevo documento</p>
             <p className="text-xs text-slate-500">Arrastra y suelta o haz clic para seleccionar (PDF, JPG)</p>
        </div>

        <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-500 uppercase">Documentos Vigentes</h3>
            {member.certifications.map((cert, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-lg hover:border-primary/50 transition-colors">
                    <div className="flex items-center gap-3">
                         <div className={`size-10 rounded bg-slate-100 dark:bg-surface-darker flex items-center justify-center ${cert.status === 'Expired' ? 'text-red-500' : 'text-slate-500'}`}>
                             <span className="material-symbols-outlined">description</span>
                         </div>
                         <div>
                             <p className="text-sm font-bold text-slate-900 dark:text-white">{cert.name}</p>
                             <div className="flex items-center gap-2 text-xs">
                                 <span className="text-slate-500">Vence: {cert.expiryDate}</span>
                                 {cert.status === 'Expiring' && <span className="text-orange-500 font-bold bg-orange-100 dark:bg-orange-900/20 px-1.5 rounded">Por Vencer</span>}
                                 {cert.status === 'Expired' && <span className="text-red-500 font-bold bg-red-100 dark:bg-red-900/20 px-1.5 rounded">Vencido</span>}
                             </div>
                         </div>
                    </div>
                    <div className="flex gap-1">
                        <button className="p-2 text-slate-400 hover:text-primary rounded-full hover:bg-slate-100 dark:hover:bg-surface-darker">
                            <span className="material-symbols-outlined text-[20px]">visibility</span>
                        </button>
                        <button className="p-2 text-slate-400 hover:text-primary rounded-full hover:bg-slate-100 dark:hover:bg-surface-darker">
                            <span className="material-symbols-outlined text-[20px]">download</span>
                        </button>
                    </div>
                </div>
            ))}
        </div>
    </div>
  );

  const renderHistoryTab = (member: CrewMember) => (
    <div className="animate-fade-in space-y-6">
        {/* Rotation Calendar (New Feature) */}
        <div className="bg-slate-50 dark:bg-surface-darker/50 p-4 rounded-xl border border-slate-100 dark:border-border-dark">
             <h3 className="text-xs font-bold text-slate-500 uppercase mb-3 flex items-center gap-2">
                <span className="material-symbols-outlined text-[16px]">calendar_month</span>
                Calendario de Guardias (Últimos 30 días)
             </h3>
             <div className="flex gap-1">
                {Array.from({length: 30}).map((_, i) => {
                    // Mock logic for days active
                    const isActive = member.status === 'Embarcado' && i > 5;
                    return (
                        <div 
                            key={i} 
                            className={`flex-1 h-8 rounded-sm ${isActive ? 'bg-emerald-500' : 'bg-slate-200 dark:bg-slate-700'}`}
                            title={isActive ? 'Embarcado' : 'Franco'}
                        ></div>
                    )
                })}
             </div>
             <div className="flex justify-between mt-2 text-xs text-slate-400">
                <span>Hace 30 días</span>
                <span>Hoy</span>
             </div>
        </div>

        {/* List */}
        <div className="relative pl-4 border-l-2 border-slate-200 dark:border-border-dark space-y-6 ml-2">
            {member.history && member.history.length > 0 ? (
                member.history.map((record, i) => (
                    <div key={i} className="relative">
                        <div className="absolute -left-[25px] top-1 size-4 rounded-full border-2 border-white dark:border-surface-dark bg-primary"></div>
                        <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-4 shadow-sm">
                            <div className="flex justify-between items-start">
                                <div>
                                    <h4 className="font-bold text-slate-900 dark:text-white">{record.vessel}</h4>
                                    <p className="text-sm text-primary">{record.role}</p>
                                </div>
                                <span className="text-xs font-mono bg-slate-100 dark:bg-surface-darker px-2 py-1 rounded text-slate-600 dark:text-slate-300">
                                    {record.startDate} - {record.endDate}
                                </span>
                            </div>
                        </div>
                    </div>
                ))
            ) : (
                <div className="text-center py-4 text-slate-500 dark:text-[#9db2b9]">
                    <p>No hay historial registrado en el sistema.</p>
                </div>
            )}
        </div>
    </div>
  );

  return (
    <div className="space-y-6 animate-fade-in relative">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
            <div>
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Tripulación</h1>
                <p className="text-slate-500 dark:text-[#9db2b9] mt-1">Gestión de personal embarcado, rotaciones y documentación.</p>
            </div>
            <div className="flex gap-2">
                <div className="bg-white dark:bg-surface-dark p-1 rounded-lg border border-slate-200 dark:border-border-dark flex">
                    <button 
                        onClick={() => setViewMode('grid')}
                        className={`p-2 rounded transition-colors ${viewMode === 'grid' ? 'bg-slate-100 dark:bg-surface-darker text-primary' : 'text-slate-400 hover:text-slate-600'}`}
                    >
                        <span className="material-symbols-outlined text-[20px]">grid_view</span>
                    </button>
                    <button 
                        onClick={() => setViewMode('list')}
                        className={`p-2 rounded transition-colors ${viewMode === 'list' ? 'bg-slate-100 dark:bg-surface-darker text-primary' : 'text-slate-400 hover:text-slate-600'}`}
                    >
                        <span className="material-symbols-outlined text-[20px]">view_list</span>
                    </button>
                </div>
                <button 
                    onClick={openAddModal}
                    className="bg-primary hover:bg-primary-dark text-white px-5 py-2.5 rounded-lg font-bold shadow-lg shadow-primary/20 flex items-center gap-2 transition-colors"
                >
                    <span className="material-symbols-outlined">person_add</span> Alta Tripulante
                </button>
            </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <KPICard label="Total Personal" value={stats.total} icon="groups" color="text-slate-500 bg-slate-500" />
            <KPICard label="Embarcados" value={stats.embarked} icon="directions_boat" color="text-emerald-500 bg-emerald-500" />
            <KPICard label="De Franco" value={stats.leave} icon="home" color="text-blue-500 bg-blue-500" />
            <KPICard 
                label="Alertas Documentación" 
                value={stats.docsIssue} 
                subtext="Vencidos o por vencer" 
                icon="folder_off" 
                color={stats.docsIssue > 0 ? "text-red-500 bg-red-500" : "text-emerald-500 bg-emerald-500"} 
            />
        </div>

        {/* Filters */}
        <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-4 flex flex-col lg:flex-row gap-4">
             <div className="relative flex-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 material-symbols-outlined text-[20px]">search</span>
                <input 
                  type="text" 
                  placeholder="Buscar por nombre..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker text-slate-900 dark:text-white focus:ring-2 focus:ring-primary/50 outline-none"
                />
             </div>
             <div className="flex gap-4 overflow-x-auto pb-2 lg:pb-0">
                 {/* New Crew Member Dropdown */}
                 <select 
                    value={crewMemberFilter}
                    onChange={(e) => setCrewMemberFilter(e.target.value)}
                    className="px-4 py-2 rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker text-slate-700 dark:text-white outline-none cursor-pointer"
                 >
                     <option value="Todos">Todos los Tripulantes</option>
                     {crewNames.filter(n => n !== "Todos").map(name => <option key={name} value={name}>{name}</option>)}
                 </select>

                 <select 
                    value={roleFilter}
                    onChange={(e) => setRoleFilter(e.target.value)}
                    className="px-4 py-2 rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker text-slate-700 dark:text-white outline-none cursor-pointer"
                 >
                     {roles.map(r => <option key={r} value={r}>{r}</option>)}
                 </select>
                 <select 
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="px-4 py-2 rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker text-slate-700 dark:text-white outline-none cursor-pointer"
                 >
                     {statuses.map(s => <option key={s} value={s}>{s}</option>)}
                 </select>
             </div>
        </div>

        {/* --- GRID VIEW (ID Cards) --- */}
        {viewMode === 'grid' && (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredCrew.map(member => {
                    const progress = Math.min((member.daysOnBoard / member.rotationLimit) * 100, 100);
                    let progressColor = "bg-primary";
                    if (progress > 80) progressColor = "bg-orange-500";
                    if (progress >= 100) progressColor = "bg-red-500";

                    return (
                        <div 
                            key={member.id} 
                            onClick={() => { setSelectedMember(member); setActiveTab('general'); setIsEditing(false); }}
                            className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl overflow-hidden shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all cursor-pointer group flex flex-col"
                        >
                            {/* Card Header (Bg + Avatar Fix) */}
                            <div className="relative h-24 bg-gradient-to-r from-slate-100 to-slate-200 dark:from-surface-darker dark:to-surface-dark">
                                <div className="absolute top-3 right-3 z-20">
                                    <StatusBadge status={member.status} />
                                </div>
                                <div className="absolute -bottom-8 left-1/2 -translate-x-1/2">
                                     <img 
                                        src={member.avatarUrl} 
                                        alt={member.name} 
                                        className="size-24 rounded-full object-cover object-top border-4 border-white dark:border-surface-dark shadow-lg bg-white relative z-10" 
                                     />
                                </div>
                            </div>
                            
                            <div className="px-5 pb-5 pt-10 flex-1 flex flex-col text-center">
                                <div className="mb-4">
                                    <h3 className="font-bold text-lg text-slate-900 dark:text-white group-hover:text-primary transition-colors leading-tight">{member.name}</h3>
                                    <div className="flex items-center justify-center gap-2 mt-1">
                                        <RoleBadge role={member.role} />
                                    </div>
                                    <p className="text-xs text-slate-400 mt-1">{member.id}</p>
                                </div>

                                <div className="space-y-3 flex-1 text-left">
                                    {/* Location Info */}
                                    <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-surface-darker/50 p-2 rounded-lg">
                                        <span className="material-symbols-outlined text-slate-400">location_on</span>
                                        <span className="truncate w-full text-center">{member.vesselName || "Sin Asignación"}</span>
                                    </div>

                                    {/* Rotation Progress */}
                                    {member.status === 'Embarcado' && (
                                        <div className="space-y-1">
                                            <div className="flex justify-between text-xs font-medium">
                                                <span className="text-slate-500">Rotación</span>
                                                <span className={`${progress >= 100 ? 'text-red-500 font-bold' : 'text-slate-700 dark:text-slate-200'}`}>
                                                    {member.daysOnBoard} / {member.rotationLimit} d
                                                </span>
                                            </div>
                                            <div className="h-2 w-full bg-slate-100 dark:bg-surface-darker rounded-full overflow-hidden">
                                                <div 
                                                    className={`h-full ${progressColor} transition-all duration-500`} 
                                                    style={{ width: `${progress}%` }}
                                                ></div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                                
                                {/* Footer: Docs */}
                                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-border-dark flex items-center justify-between">
                                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Docs</span>
                                    <div className="flex -space-x-1">
                                        {member.certifications.map((cert, idx) => {
                                             let color = "bg-emerald-500";
                                             if (cert.status === 'Expiring') color = "bg-orange-500";
                                             if (cert.status === 'Expired') color = "bg-red-500";
                                             return (
                                                 <div key={idx} className={`size-2.5 rounded-full ring-2 ring-white dark:ring-surface-dark ${color}`} title={`${cert.name}: ${cert.status}`}></div>
                                             );
                                        })}
                                        {member.certifications.length === 0 && <span className="text-[10px] text-slate-400">Sin datos</span>}
                                    </div>
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
        )}

        {/* --- LIST VIEW --- */}
        {viewMode === 'list' && (
            <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl overflow-hidden shadow-sm">
                <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 dark:bg-surface-darker text-slate-500 font-medium border-b border-slate-200 dark:border-border-dark">
                        <tr>
                            <th className="px-6 py-4">Tripulante</th>
                            <th className="px-6 py-4">Rol</th>
                            <th className="px-6 py-4">Estado</th>
                            <th className="px-6 py-4">Buque / Ubicación</th>
                            <th className="px-6 py-4">Días Emb.</th>
                            <th className="px-6 py-4 text-right">Acciones</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-border-dark">
                        {filteredCrew.map(member => (
                            <tr key={member.id} onClick={() => { setSelectedMember(member); setActiveTab('general'); setIsEditing(false); }} className="hover:bg-slate-50 dark:hover:bg-surface-darker/50 cursor-pointer">
                                <td className="px-6 py-4">
                                    <div className="flex items-center gap-3">
                                        <img src={member.avatarUrl} className="size-8 rounded-full object-cover object-top" />
                                        <div>
                                            <p className="font-bold text-slate-900 dark:text-white">{member.name}</p>
                                            <p className="text-xs text-slate-500">{member.email}</p>
                                        </div>
                                    </div>
                                </td>
                                <td className="px-6 py-4"><RoleBadge role={member.role} /></td>
                                <td className="px-6 py-4"><StatusBadge status={member.status} /></td>
                                <td className="px-6 py-4 text-slate-600 dark:text-slate-300">{member.vesselName || "-"}</td>
                                <td className="px-6 py-4 font-mono">{member.daysOnBoard > 0 ? `${member.daysOnBoard} d` : '-'}</td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-slate-400 hover:text-primary"><span className="material-symbols-outlined">more_vert</span></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        )}

        {/* --- ADD CREW MODAL --- */}
        {isAddModalOpen && (
             <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                <div className="absolute inset-0 bg-slate-900/70 backdrop-blur-sm transition-opacity" onClick={() => setIsAddModalOpen(false)}></div>
                <div className="relative w-full max-w-lg bg-white dark:bg-surface-dark rounded-2xl shadow-2xl border border-slate-200 dark:border-border-dark overflow-hidden animate-fade-in-up">
                    <div className="px-6 py-4 border-b border-slate-200 dark:border-border-dark bg-slate-50 dark:bg-surface-darker flex justify-between items-center">
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                            <span className="material-symbols-outlined text-primary">person_add</span>
                            Alta de Tripulante
                        </h3>
                        <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-900 dark:hover:text-white">
                            <span className="material-symbols-outlined">close</span>
                        </button>
                    </div>

                    <form onSubmit={handleAddCrew} className="p-6 space-y-4">
                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Nombre Completo</label>
                            <input 
                                required
                                type="text" 
                                className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2.5 outline-none focus:ring-2 focus:ring-primary/50"
                                value={formData.name}
                                onChange={e => setFormData({...formData, name: e.target.value})}
                                placeholder="Ej. Juan Pérez"
                            />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Rol / Cargo</label>
                                <select 
                                    className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2.5 outline-none focus:ring-2 focus:ring-primary/50"
                                    value={formData.role}
                                    onChange={e => setFormData({...formData, role: e.target.value as any})}
                                >
                                    {roles.slice(1).map(r => <option key={r} value={r}>{r}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Estado Inicial</label>
                                <select 
                                    className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2.5 outline-none focus:ring-2 focus:ring-primary/50"
                                    value={formData.status}
                                    onChange={e => setFormData({...formData, status: e.target.value as any})}
                                >
                                    {statuses.slice(1).map(s => <option key={s} value={s}>{s}</option>)}
                                </select>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                             <div>
                                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Teléfono</label>
                                <input 
                                    type="tel" 
                                    className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2.5 outline-none focus:ring-2 focus:ring-primary/50"
                                    value={formData.phone}
                                    onChange={e => setFormData({...formData, phone: e.target.value})}
                                />
                            </div>
                             <div>
                                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Email</label>
                                <input 
                                    type="email" 
                                    className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2.5 outline-none focus:ring-2 focus:ring-primary/50"
                                    value={formData.email}
                                    onChange={e => setFormData({...formData, email: e.target.value})}
                                />
                            </div>
                        </div>

                        <div className="pt-4 flex justify-end gap-3">
                             <button 
                                type="button"
                                onClick={() => setIsAddModalOpen(false)}
                                className="px-4 py-2 text-slate-600 dark:text-slate-300 font-medium hover:bg-slate-100 dark:hover:bg-surface-darker rounded-lg transition-colors"
                             >
                                Cancelar
                             </button>
                             <button 
                                type="submit"
                                className="px-6 py-2 bg-primary hover:bg-primary-dark text-white font-bold rounded-lg shadow-lg shadow-primary/20 transition-colors"
                             >
                                Guardar Tripulante
                             </button>
                        </div>
                    </form>
                </div>
             </div>
        )}

        {/* --- DETAIL MODAL (ENHANCED) --- */}
        {selectedMember && (
             <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                <div className="absolute inset-0 bg-slate-900/70 backdrop-blur-sm" onClick={() => setSelectedMember(null)}></div>
                <div className="relative w-full max-w-2xl bg-white dark:bg-surface-dark rounded-2xl shadow-2xl border border-slate-200 dark:border-border-dark overflow-hidden animate-fade-in-up flex flex-col max-h-[90vh]">
                    
                    {/* Modal Header */}
                    <div className="p-6 pb-0 bg-slate-50 dark:bg-surface-darker flex justify-between items-start border-b border-slate-200 dark:border-border-dark">
                        <div className="flex items-center gap-5 pb-6">
                             <img src={selectedMember.avatarUrl} alt={selectedMember.name} className="size-20 rounded-full object-cover object-top border-4 border-white dark:border-surface-dark shadow-md" />
                             <div>
                                 <h2 className="text-2xl font-bold text-slate-900 dark:text-white">{selectedMember.name}</h2>
                                 <div className="flex items-center gap-2 mt-1">
                                     <RoleBadge role={selectedMember.role} />
                                     <span className="text-slate-500 dark:text-[#9db2b9] text-sm">• ID: {selectedMember.id}</span>
                                 </div>
                             </div>
                        </div>
                        <button onClick={() => setSelectedMember(null)} className="text-slate-400 hover:text-slate-900 dark:hover:text-white">
                            <span className="material-symbols-outlined">close</span>
                        </button>
                    </div>

                    {/* Navigation Tabs */}
                    <div className="flex px-6 border-b border-slate-200 dark:border-border-dark bg-slate-50 dark:bg-surface-darker">
                        <button 
                            onClick={() => setActiveTab('general')}
                            className={`pb-3 px-2 text-sm font-bold border-b-2 transition-colors ${activeTab === 'general' ? 'border-primary text-primary' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-white'}`}
                        >
                            General
                        </button>
                        <button 
                            onClick={() => setActiveTab('documents')}
                            className={`pb-3 px-2 text-sm font-bold border-b-2 transition-colors ${activeTab === 'documents' ? 'border-primary text-primary' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-white'}`}
                        >
                            Documentos
                        </button>
                        <button 
                            onClick={() => setActiveTab('history')}
                            className={`pb-3 px-2 text-sm font-bold border-b-2 transition-colors ${activeTab === 'history' ? 'border-primary text-primary' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-white'}`}
                        >
                            Historial
                        </button>
                    </div>

                    <div className="flex-1 overflow-y-auto p-6 bg-white dark:bg-surface-dark">
                        {activeTab === 'general' && renderGeneralTab(selectedMember)}
                        {activeTab === 'documents' && renderDocumentsTab(selectedMember)}
                        {activeTab === 'history' && renderHistoryTab(selectedMember)}
                    </div>

                    <div className="p-4 border-t border-slate-200 dark:border-border-dark flex justify-between items-center bg-slate-50 dark:bg-surface-darker">
                        <span className="text-xs text-slate-400">Última actualización: Hace 2 días</span>
                        <div className="flex gap-3">
                            <button 
                                onClick={() => handleExportProfile(selectedMember)}
                                className="px-4 py-2 bg-white dark:bg-surface-dark border border-slate-300 dark:border-border-dark rounded-lg text-slate-700 dark:text-white font-medium hover:bg-slate-50 dark:hover:bg-border-dark transition-colors flex items-center gap-2"
                            >
                                <span className="material-symbols-outlined text-[18px]">download</span> Exportar Ficha
                            </button>
                            {!isEditing && (
                                <button 
                                    onClick={() => startEditing(selectedMember)}
                                    className="px-4 py-2 bg-primary hover:bg-primary-dark text-white rounded-lg font-bold shadow-lg shadow-primary/20 transition-colors"
                                >
                                    Editar Perfil
                                </button>
                            )}
                        </div>
                    </div>
                </div>
             </div>
        )}
    </div>
  );
};

export default Crew;