import React, { useState } from 'react';

// Define interface for Inventory Item
interface InventoryItem {
    id: string; // internal id
    code: string;
    name: string;
    cat: string;
    stock: number;
    loc: string;
    status: 'ok' | 'low' | 'crit';
}

const INITIAL_ITEMS: InventoryItem[] = [
    { id: '1', code: "REP-001", name: "Filtro Aceite CAT-3512", cat: "Motor", stock: 12, loc: "Pañol Central A1", status: "ok" },
    { id: '2', code: "SEG-104", name: "Chaleco Salvavidas SOLAS", cat: "Seguridad", stock: 45, loc: "Titan III", status: "low" },
    { id: '3', code: "CUB-220", name: "Cabo Polipropileno 2\"", cat: "Cubierta", stock: 4, loc: "Pañol Central B2", status: "ok" },
    { id: '4', code: "ELC-099", name: "Fusible 200A Industrial", cat: "Eléctrico", stock: 0, loc: "-", status: "crit" },
];

const Inventory: React.FC = () => {
    const [items, setItems] = useState<InventoryItem[]>(INITIAL_ITEMS);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");

    const handleAddItem = (e: React.FormEvent) => {
        e.preventDefault();
        const form = e.target as HTMLFormElement;
        const formData = new FormData(form);

        const stockVal = Number(formData.get('stock'));
        let status: 'ok' | 'low' | 'crit' = 'ok';
        if (stockVal === 0) status = 'crit';
        else if (stockVal < 10) status = 'low';

        const newItem: InventoryItem = {
            id: Date.now().toString(),
            code: formData.get('code') as string,
            name: formData.get('name') as string,
            cat: formData.get('cat') as string,
            stock: stockVal,
            loc: formData.get('loc') as string,
            status: status
        };

        setItems([...items, newItem]);
        setIsAddModalOpen(false);
    };

    const filteredItems = items.filter(item => 
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        item.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.loc.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="animate-fade-in space-y-6 relative">
            <div className="flex justify-between items-end">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Pañol Digital</h1>
                    <p className="text-slate-500 dark:text-[#9db2b9] mt-1">Inventario de repuestos, insumos y herramientas.</p>
                </div>
                <div className="flex gap-2">
                    <button className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark text-slate-700 dark:text-white px-4 py-2 rounded-lg text-sm font-bold shadow-sm hover:bg-slate-50 dark:hover:bg-surface-darker transition-colors">
                        Auditoría
                    </button>
                    <button 
                        onClick={() => setIsAddModalOpen(true)}
                        className="bg-primary hover:bg-primary-dark text-white px-5 py-2.5 rounded-lg font-bold shadow-lg shadow-primary/20 flex items-center gap-2 transition-colors"
                    >
                        <span className="material-symbols-outlined">add</span> Nuevo Ítem
                    </button>
                </div>
            </div>

            <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl overflow-hidden shadow-sm">
                 <div className="p-4 border-b border-slate-200 dark:border-border-dark flex gap-4">
                    <input 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="Buscar repuesto, código o ubicación..." 
                        className="flex-1 bg-slate-50 dark:bg-surface-darker border border-slate-200 dark:border-border-dark rounded-lg px-4 py-2 text-sm outline-none focus:ring-1 focus:ring-primary dark:text-white"
                    />
                    <select className="bg-slate-50 dark:bg-surface-darker border border-slate-200 dark:border-border-dark rounded-lg px-4 py-2 text-sm outline-none dark:text-white">
                        <option>Categoría: Todas</option>
                        <option>Motor</option>
                        <option>Cubierta</option>
                        <option>Seguridad</option>
                    </select>
                 </div>
                 <table className="w-full text-left text-sm">
                    <thead className="bg-slate-50 dark:bg-surface-darker text-slate-500 border-b border-slate-200 dark:border-border-dark">
                        <tr>
                            <th className="px-6 py-3">Código</th>
                            <th className="px-6 py-3">Ítem</th>
                            <th className="px-6 py-3">Categoría</th>
                            <th className="px-6 py-3">Stock</th>
                            <th className="px-6 py-3">Ubicación</th>
                            <th className="px-6 py-3">Estado</th>
                            <th className="px-6 py-3 text-right">Acciones</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-border-dark">
                        {filteredItems.map((item) => (
                            <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-surface-darker/50">
                                <td className="px-6 py-4 font-mono text-xs text-slate-500">{item.code}</td>
                                <td className="px-6 py-4 font-bold text-slate-900 dark:text-white">{item.name}</td>
                                <td className="px-6 py-4 text-slate-600 dark:text-slate-300">{item.cat}</td>
                                <td className="px-6 py-4 font-bold text-slate-900 dark:text-white">{item.stock} un.</td>
                                <td className="px-6 py-4 text-slate-500">{item.loc}</td>
                                <td className="px-6 py-4">
                                    {item.status === 'ok' && <span className="bg-emerald-100 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded text-xs font-bold uppercase">En Stock</span>}
                                    {item.status === 'low' && <span className="bg-orange-100 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400 px-2 py-0.5 rounded text-xs font-bold uppercase">Bajo</span>}
                                    {item.status === 'crit' && <span className="bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400 px-2 py-0.5 rounded text-xs font-bold uppercase">Sin Stock</span>}
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-slate-400 hover:text-primary"><span className="material-symbols-outlined">edit</span></button>
                                </td>
                            </tr>
                        ))}
                        {filteredItems.length === 0 && (
                             <tr>
                                <td colSpan={7} className="px-6 py-8 text-center text-slate-500 dark:text-slate-400 italic">
                                    No se encontraron ítems en el inventario.
                                </td>
                            </tr>
                        )}
                    </tbody>
                 </table>
            </div>

            {/* --- ADD ITEM MODAL --- */}
            {isAddModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <div 
                        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity" 
                        onClick={() => setIsAddModalOpen(false)}
                    ></div>

                    <div className="relative w-full max-w-lg bg-white dark:bg-surface-dark rounded-xl shadow-2xl border border-slate-200 dark:border-border-dark flex flex-col max-h-[90vh] overflow-hidden animate-fade-in-up">
                        <div className="px-6 py-4 border-b border-slate-200 dark:border-border-dark flex justify-between items-center bg-slate-50 dark:bg-surface-darker">
                            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                <span className="material-symbols-outlined text-primary">inventory_2</span>
                                Nuevo Ítem de Pañol
                            </h3>
                            <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-red-500 transition-colors">
                                <span className="material-symbols-outlined">close</span>
                            </button>
                        </div>

                        <form onSubmit={handleAddItem} className="p-6 space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Nombre del Ítem</label>
                                <input name="name" type="text" required placeholder="Ej. Filtro de Aceite" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Código SKU</label>
                                    <input name="code" type="text" required placeholder="ABC-123" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50 font-mono" />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Categoría</label>
                                    <select name="cat" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50">
                                        <option value="Motor">Motor</option>
                                        <option value="Cubierta">Cubierta</option>
                                        <option value="Seguridad">Seguridad</option>
                                        <option value="Eléctrico">Eléctrico</option>
                                        <option value="Herramientas">Herramientas</option>
                                        <option value="Insumos">Insumos</option>
                                    </select>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Stock Inicial</label>
                                    <input name="stock" type="number" required min="0" defaultValue="0" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Ubicación</label>
                                    <input name="loc" type="text" placeholder="Estantería A1" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                                </div>
                            </div>

                            <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200 dark:border-border-dark mt-4">
                                <button type="button" onClick={() => setIsAddModalOpen(false)} className="px-4 py-2 text-slate-600 dark:text-slate-300 font-medium hover:bg-slate-100 dark:hover:bg-surface-darker rounded-lg transition-colors">Cancelar</button>
                                <button type="submit" className="px-6 py-2 bg-primary hover:bg-primary-dark text-white font-bold rounded-lg shadow-lg shadow-primary/20 transition-all">Guardar Ítem</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Inventory;