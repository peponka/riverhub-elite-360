import React, { useState } from 'react';

interface DocumentItem {
    id: string;
    title: string;
    type: 'Manifest' | 'Bill of Lading' | 'Invoice' | 'Certificate' | 'Clearance';
    tripId?: string;
    vessel?: string;
    date: string;
    status: 'Draft' | 'Signed' | 'Submitted' | 'Archived';
    size: string;
    format: 'pdf' | 'xls' | 'img';
}

const MOCK_DOCS: DocumentItem[] = [
    { id: 'DOC-8829', title: 'Manifiesto de Carga #8829', type: 'Manifest', tripId: 'VJ-2024-081', vessel: 'Titan III', date: '2023-10-27', status: 'Signed', size: '2.4 MB', format: 'pdf' },
    { id: 'DOC-8830', title: 'Conocimiento de Embarque (BL)', type: 'Bill of Lading', tripId: 'VJ-2024-081', vessel: 'Titan III', date: '2023-10-27', status: 'Signed', size: '1.1 MB', format: 'pdf' },
    { id: 'DOC-8831', title: 'Despacho Prefectura (Zarpe)', type: 'Clearance', tripId: 'VJ-2024-081', vessel: 'Titan III', date: '2023-10-26', status: 'Submitted', size: '0.8 MB', format: 'pdf' },
    { id: 'DOC-8815', title: 'Factura Flete #001-992', type: 'Invoice', tripId: 'VJ-2024-075', vessel: 'Barcaza B-102', date: '2023-10-20', status: 'Archived', size: '0.5 MB', format: 'pdf' },
    { id: 'DOC-8899', title: 'Certificado Arqueo', type: 'Certificate', vessel: 'Barcaza T-55', date: '2023-09-15', status: 'Signed', size: '5.2 MB', format: 'pdf' },
    { id: 'DOC-9001', title: 'Manifiesto Borrador', type: 'Manifest', tripId: 'VJ-2024-089', vessel: 'Alpha Uno', date: 'Hoy', status: 'Draft', size: '-', format: 'xls' },
];

const DocumentStatusBadge = ({ status }: { status: string }) => {
    let color = '';
    let icon = '';
    switch(status) {
        case 'Signed': color = 'bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-400 dark:border-emerald-800'; icon='verified'; break;
        case 'Submitted': color = 'bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-800'; icon='send'; break;
        case 'Draft': color = 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'; icon='edit_note'; break;
        case 'Archived': color = 'bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-900/20 dark:text-amber-400 dark:border-amber-800'; icon='inventory_2'; break;
    }
    return (
        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${color}`}>
            <span className="material-symbols-outlined text-[12px]">{icon}</span>
            {status}
        </span>
    );
};

// --- Mock Document Viewer Component ---
const SimulatedDocument = ({ doc }: { doc: DocumentItem }) => {
    return (
        <div className="bg-white text-slate-900 font-serif p-8 md:p-12 shadow-2xl min-h-[800px] w-full max-w-[800px] mx-auto relative overflow-hidden flex flex-col">
            {/* Watermark */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5">
                <span className="material-symbols-outlined text-[400px]">anchor</span>
            </div>

            {/* Header */}
            <div className="flex justify-between items-start border-b-2 border-slate-800 pb-6 mb-8 relative z-10">
                <div className="flex items-center gap-3">
                    <div className="size-12 bg-slate-900 text-white flex items-center justify-center rounded">
                        <span className="material-symbols-outlined text-3xl">anchor</span>
                    </div>
                    <div>
                        <h1 className="text-xl font-bold uppercase tracking-widest">AquaFleet Logistics</h1>
                        <p className="text-xs text-slate-500">Asunción, Paraguay • Reg. Fluvial #99281</p>
                    </div>
                </div>
                <div className="text-right">
                    <h2 className="text-2xl font-bold text-slate-800 uppercase">{doc.type}</h2>
                    <p className="font-mono text-red-600 font-bold">{doc.id}</p>
                    <p className="text-sm text-slate-500 mt-1">{doc.date}</p>
                </div>
            </div>

            {/* Content Body */}
            <div className="flex-1 relative z-10 space-y-8">
                
                {/* Vessel Info */}
                <div className="bg-slate-50 p-4 border border-slate-200 rounded">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                            <span className="block text-xs font-bold text-slate-400 uppercase">Embarcación</span>
                            <span className="font-bold text-lg">{doc.vessel}</span>
                        </div>
                        <div>
                            <span className="block text-xs font-bold text-slate-400 uppercase">Viaje Referencia</span>
                            <span className="font-mono">{doc.tripId || 'N/A'}</span>
                        </div>
                    </div>
                </div>

                {/* Dynamic Content based on Type */}
                {doc.type === 'Manifest' && (
                    <table className="w-full text-sm border-collapse border border-slate-300">
                        <thead>
                            <tr className="bg-slate-100">
                                <th className="border border-slate-300 p-2 text-left">Descripción</th>
                                <th className="border border-slate-300 p-2 text-right">Cant.</th>
                                <th className="border border-slate-300 p-2 text-right">Peso (Ton)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td className="border border-slate-300 p-2">Harina de Soja a Granel</td>
                                <td className="border border-slate-300 p-2 text-right">12 Barc.</td>
                                <td className="border border-slate-300 p-2 text-right">20,000</td>
                            </tr>
                            <tr>
                                <td className="border border-slate-300 p-2">Maíz Grado 2</td>
                                <td className="border border-slate-300 p-2 text-right">2 Barc.</td>
                                <td className="border border-slate-300 p-2 text-right">2,000</td>
                            </tr>
                            <tr className="font-bold bg-slate-50">
                                <td className="border border-slate-300 p-2 text-right">TOTAL</td>
                                <td className="border border-slate-300 p-2 text-right">14</td>
                                <td className="border border-slate-300 p-2 text-right">22,000</td>
                            </tr>
                        </tbody>
                    </table>
                )}

                {doc.type === 'Invoice' && (
                    <div className="space-y-4">
                        <div className="flex justify-between border-b border-slate-300 pb-1">
                            <span>Flete Fluvial (Tramo ASU-ROS)</span>
                            <span className="font-mono">$ 45,000.00</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-300 pb-1">
                            <span>Gastos Portuarios</span>
                            <span className="font-mono">$ 3,250.00</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-300 pb-1">
                            <span>Seguro de Carga</span>
                            <span className="font-mono">$ 1,500.00</span>
                        </div>
                        <div className="flex justify-between font-bold text-lg pt-2">
                            <span>TOTAL USD</span>
                            <span>$ 49,750.00</span>
                        </div>
                    </div>
                )}

                {(doc.type === 'Certificate' || doc.type === 'Clearance') && (
                    <div className="text-justify text-sm leading-loose text-slate-700">
                        <p>Por la presente se certifica que la embarcación mencionada cumple con todas las regulaciones de seguridad y navegación vigentes según el tratado de la Hidrovía Paraguay-Paraná.</p>
                        <p className="mt-4">La inspección ha sido realizada satisfactoriamente el día {doc.date}, no encontrándose novedades que impidan su libre navegación.</p>
                        <p className="mt-4">Válido hasta: <strong>Diciembre 2024</strong>.</p>
                    </div>
                )}

                {doc.type === 'Bill of Lading' && (
                    <div className="border border-slate-800 p-4 min-h-[200px] text-xs">
                        <div className="grid grid-cols-2 gap-8">
                            <div>
                                <strong className="block uppercase border-b border-slate-300 mb-1">Shipper</strong>
                                <p>AGROEXPORT S.A.</p>
                                <p>Ruta Transchaco Km 14</p>
                                <p>Asunción, Paraguay</p>
                            </div>
                            <div>
                                <strong className="block uppercase border-b border-slate-300 mb-1">Consignee</strong>
                                <p>GLOBAL TRADING CORP.</p>
                                <p>Av. Belgrano 455</p>
                                <p>Rosario, Argentina</p>
                            </div>
                        </div>
                        <div className="mt-6">
                            <strong className="block uppercase border-b border-slate-300 mb-1">Notify Address</strong>
                            <p>SAME AS CONSIGNEE</p>
                        </div>
                    </div>
                )}

            </div>

            {/* Footer / Signature */}
            <div className="mt-auto pt-12 relative z-10 flex justify-between items-end">
                <div className="text-xs text-slate-400">
                    <p>Generado electrónicamente por AquaFleet System.</p>
                    <p>Hash: {Math.random().toString(36).substring(7)}</p>
                </div>
                
                {(doc.status === 'Signed' || doc.status === 'Submitted' || doc.status === 'Archived') && (
                    <div className="text-center relative">
                        {/* Stamp */}
                        <div className="absolute -top-12 left-1/2 -translate-x-1/2 border-4 border-red-700 text-red-700 rounded-full w-32 h-32 flex items-center justify-center opacity-70 -rotate-12 mix-blend-multiply pointer-events-none">
                            <div className="text-center">
                                <span className="block text-xs font-bold">AQUAFLEET</span>
                                <span className="block text-xl font-black uppercase">{doc.status === 'Signed' ? 'APROBADO' : 'ARCHIVADO'}</span>
                                <span className="block text-[10px]">{doc.date}</span>
                            </div>
                        </div>
                        
                        <div className="font-script text-3xl text-blue-900 mb-2">Carlos Martínez</div>
                        <div className="border-t border-slate-400 w-48 mx-auto"></div>
                        <p className="text-xs font-bold uppercase mt-1">Firma Autorizada</p>
                    </div>
                )}
            </div>
        </div>
    );
}

const Documents: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [typeFilter, setTypeFilter] = useState('All');
    const [selectedDoc, setSelectedDoc] = useState<DocumentItem | null>(null);
    
    const filteredDocs = MOCK_DOCS.filter(doc => {
        const matchesSearch = doc.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                              doc.vessel?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                              doc.tripId?.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesType = typeFilter === 'All' || doc.type === typeFilter;
        return matchesSearch && matchesType;
    });

    return (
        <div className="space-y-6 animate-fade-in relative">
            {/* Header */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Documentación</h1>
                    <p className="text-slate-500 dark:text-[#9db2b9] mt-1">Gestión centralizada de Manifiestos, BLs y Certificados.</p>
                </div>
                <div className="flex gap-2">
                    <button className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark text-slate-700 dark:text-white px-4 py-2.5 rounded-lg text-sm font-bold shadow-sm hover:bg-slate-50 dark:hover:bg-surface-darker transition-colors flex items-center gap-2">
                        <span className="material-symbols-outlined text-[18px]">cloud_upload</span> Subir
                    </button>
                    <button className="bg-primary hover:bg-primary-dark text-white px-5 py-2.5 rounded-lg font-bold shadow-lg shadow-primary/20 flex items-center gap-2 transition-colors">
                        <span className="material-symbols-outlined text-[20px]">post_add</span> Generar Manifiesto
                    </button>
                </div>
            </div>

            {/* Filters */}
            <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-4 flex flex-col md:flex-row gap-4 items-center">
                <div className="relative flex-1 w-full">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 material-symbols-outlined text-[20px]">search</span>
                    <input 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="Buscar por ID, buque o viaje..."
                        className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-surface-darker border border-slate-200 dark:border-border-dark rounded-lg outline-none focus:ring-1 focus:ring-primary dark:text-white text-sm"
                    />
                </div>
                <div className="flex gap-2 overflow-x-auto w-full md:w-auto pb-1">
                    {['All', 'Manifest', 'Bill of Lading', 'Certificate', 'Invoice'].map(t => (
                        <button 
                            key={t}
                            onClick={() => setTypeFilter(t)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap border transition-colors ${
                                typeFilter === t 
                                ? 'bg-primary/10 text-primary border-primary/20' 
                                : 'bg-white dark:bg-surface-dark text-slate-500 dark:text-slate-400 border-slate-200 dark:border-border-dark hover:bg-slate-50 dark:hover:bg-surface-darker'
                            }`}
                        >
                            {t === 'All' ? 'Todos' : t}
                        </button>
                    ))}
                </div>
            </div>

            {/* Document Grid */}
            {filteredDocs.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6">
                    {filteredDocs.map(doc => (
                        <div key={doc.id} className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-5 hover:shadow-lg transition-all group flex flex-col">
                            <div className="flex justify-between items-start mb-4">
                                <div className={`size-10 rounded-lg flex items-center justify-center text-white shadow-sm font-bold uppercase text-xs
                                    ${doc.format === 'pdf' ? 'bg-red-500' : doc.format === 'xls' ? 'bg-emerald-500' : 'bg-blue-500'}`}>
                                    {doc.format}
                                </div>
                                <DocumentStatusBadge status={doc.status} />
                            </div>
                            
                            <h3 onClick={() => setSelectedDoc(doc)} className="font-bold text-slate-900 dark:text-white text-lg leading-tight mb-1 group-hover:text-primary transition-colors cursor-pointer">{doc.title}</h3>
                            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">{doc.id}</p>

                            <div className="space-y-2 mb-6 flex-1">
                                {doc.tripId && (
                                    <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                                        <span className="material-symbols-outlined text-[16px] text-slate-400">route</span>
                                        <span className="font-mono bg-slate-100 dark:bg-surface-darker px-1.5 rounded">{doc.tripId}</span>
                                    </div>
                                )}
                                {doc.vessel && (
                                    <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                                        <span className="material-symbols-outlined text-[16px] text-slate-400">directions_boat</span>
                                        <span>{doc.vessel}</span>
                                    </div>
                                )}
                                <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                                    <span className="material-symbols-outlined text-[16px] text-slate-400">calendar_today</span>
                                    <span>{doc.date}</span>
                                </div>
                            </div>

                            <div className="pt-4 border-t border-slate-100 dark:border-border-dark flex items-center justify-between">
                                <span className="text-xs text-slate-400 font-medium">{doc.size}</span>
                                <div className="flex gap-2">
                                    <button onClick={() => setSelectedDoc(doc)} className="p-2 hover:bg-slate-100 dark:hover:bg-surface-darker rounded text-slate-500 hover:text-primary transition-colors" title="Vista Previa">
                                        <span className="material-symbols-outlined text-[20px]">visibility</span>
                                    </button>
                                    <button className="p-2 hover:bg-slate-100 dark:hover:bg-surface-darker rounded text-slate-500 hover:text-primary transition-colors" title="Descargar">
                                        <span className="material-symbols-outlined text-[20px]">download</span>
                                    </button>
                                    <button className="p-2 hover:bg-slate-100 dark:hover:bg-surface-darker rounded text-slate-500 hover:text-primary transition-colors" title="Compartir">
                                        <span className="material-symbols-outlined text-[20px]">share</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="flex flex-col items-center justify-center py-16 text-slate-400 dark:text-slate-600 border-2 border-dashed border-slate-200 dark:border-border-dark rounded-xl">
                    <span className="material-symbols-outlined text-5xl mb-2 opacity-50">folder_off</span>
                    <p className="text-sm font-medium">No se encontraron documentos.</p>
                </div>
            )}

            {/* --- PREVIEW MODAL --- */}
            {selectedDoc && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                    <div 
                        className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm transition-opacity" 
                        onClick={() => setSelectedDoc(null)}
                    ></div>

                    <div className="relative w-full max-w-4xl h-[90vh] bg-slate-100 dark:bg-[#0f1519] rounded-xl shadow-2xl overflow-hidden flex flex-col animate-fade-in-up">
                        {/* Toolbar */}
                        <div className="bg-slate-900 text-white px-4 py-3 flex justify-between items-center shadow-md z-20">
                            <div className="flex items-center gap-3">
                                <span className="material-symbols-outlined text-slate-400">description</span>
                                <div>
                                    <h3 className="text-sm font-bold text-white leading-none">{selectedDoc.title}</h3>
                                    <p className="text-[10px] text-slate-400 mt-0.5">Vista Previa • Solo Lectura</p>
                                </div>
                            </div>
                            <div className="flex gap-2">
                                <button className="p-2 hover:bg-white/10 rounded-lg transition-colors" title="Imprimir">
                                    <span className="material-symbols-outlined text-[20px]">print</span>
                                </button>
                                <button className="p-2 hover:bg-white/10 rounded-lg transition-colors" title="Descargar PDF">
                                    <span className="material-symbols-outlined text-[20px]">download</span>
                                </button>
                                <div className="w-px h-8 bg-white/20 mx-1"></div>
                                <button onClick={() => setSelectedDoc(null)} className="p-2 hover:bg-red-500/80 rounded-lg transition-colors text-slate-300 hover:text-white">
                                    <span className="material-symbols-outlined text-[20px]">close</span>
                                </button>
                            </div>
                        </div>

                        {/* Document Viewer Area */}
                        <div className="flex-1 overflow-y-auto p-4 md:p-8 bg-slate-200/50 dark:bg-black/20 flex justify-center">
                            <SimulatedDocument doc={selectedDoc} />
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Documents;