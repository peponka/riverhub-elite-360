import React, { useState } from 'react';

interface WorkOrder {
  id: string;
  vessel: string;
  title: string;
  description: string;
  type: 'Preventivo' | 'Correctivo' | 'Predictivo';
  priority: 'Alta' | 'Media' | 'Baja';
  status: 'Pendiente' | 'En Progreso' | 'Completado' | 'Validado';
  assignedTo: string;
  dueDate: string;
}

const MOCK_ORDERS: WorkOrder[] = [
  { id: "OT-101", vessel: "Remolcador Titan III", title: "Cambio de Filtros Aceite", description: "Mantenimiento programado 5000hrs.", type: 'Preventivo', priority: 'Media', status: 'En Progreso', assignedTo: "Juan Mecánico", dueDate: "2023-10-25" },
  { id: "OT-102", vessel: "Barcaza B-102", title: "Reparación Casco Babor", description: "Fisura detectada en inspección visual.", type: 'Correctivo', priority: 'Alta', status: 'Pendiente', assignedTo: "Astillero Chaco", dueDate: "2023-10-20" },
  { id: "OT-103", vessel: "Buque Motor Delta", title: "Calibración Radares", description: "Ajuste anual de equipos de navegación.", type: 'Preventivo', priority: 'Baja', status: 'Completado', assignedTo: "Tech Marine", dueDate: "2023-10-15" },
];

const PriorityBadge = ({ priority }: { priority: string }) => {
    const colors = {
        Alta: "bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400 border-red-200 dark:border-red-800",
        Media: "bg-orange-100 text-orange-600 dark:bg-orange-900/30 dark:text-orange-400 border-orange-200 dark:border-orange-800",
        Baja: "bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400 border-blue-200 dark:border-blue-800",
    }[priority] || "bg-slate-100 text-slate-600";
    
    return <span className={`px-2 py-0.5 rounded text-xs font-bold border ${colors} uppercase`}>{priority}</span>;
};

const StatusBadge = ({ status }: { status: string }) => {
     let color = "bg-slate-100 text-slate-600";
     if(status === 'En Progreso') color = "bg-blue-100 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400";
     if(status === 'Completado') color = "bg-emerald-100 text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-400";
     if(status === 'Pendiente') color = "bg-amber-100 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400";
     
     return (
         <span className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold ${color}`}>
             <span className={`size-1.5 rounded-full ${status === 'En Progreso' ? 'bg-blue-500 animate-pulse' : 'bg-current'}`}></span>
             {status}
         </span>
     );
};

const Maintenance: React.FC = () => {
    const [orders, setOrders] = useState<WorkOrder[]>(MOCK_ORDERS);
    const [isModalOpen, setIsModalOpen] = useState(false);

    const handleAddOrder = (e: React.FormEvent) => {
        e.preventDefault();
        const form = e.target as HTMLFormElement;
        const formData = new FormData(form);
        const newOrder: WorkOrder = {
            id: `OT-${Math.floor(Math.random() * 1000)}`,
            title: formData.get('title') as string,
            vessel: formData.get('vessel') as string,
            type: formData.get('type') as any,
            priority: formData.get('priority') as any,
            status: 'Pendiente',
            description: formData.get('description') as string,
            assignedTo: formData.get('assignedTo') as string,
            dueDate: formData.get('dueDate') as string,
        };
        setOrders([...orders, newOrder]);
        setIsModalOpen(false);
    };

    return (
        <div className="space-y-6 animate-fade-in relative">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Mantenimiento</h1>
                    <p className="text-slate-500 dark:text-[#9db2b9] mt-1">Gestión de órdenes de trabajo y plan preventivo.</p>
                </div>
                <button 
                    onClick={() => setIsModalOpen(true)}
                    className="bg-primary hover:bg-primary-dark text-white px-5 py-2.5 rounded-lg font-bold shadow-lg shadow-primary/20 flex items-center gap-2 transition-colors"
                >
                    <span className="material-symbols-outlined">build_circle</span> Nueva Orden
                </button>
            </div>

            {/* KPIs */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white dark:bg-surface-dark p-4 rounded-xl border border-slate-200 dark:border-border-dark flex items-center gap-4">
                    <div className="size-12 rounded-full bg-orange-500/10 text-orange-500 flex items-center justify-center"><span className="material-symbols-outlined text-2xl">pending_actions</span></div>
                    <div><h3 className="text-2xl font-bold text-slate-900 dark:text-white">5</h3><p className="text-xs text-slate-500">Pendientes</p></div>
                </div>
                <div className="bg-white dark:bg-surface-dark p-4 rounded-xl border border-slate-200 dark:border-border-dark flex items-center gap-4">
                    <div className="size-12 rounded-full bg-blue-500/10 text-blue-500 flex items-center justify-center"><span className="material-symbols-outlined text-2xl">engineering</span></div>
                    <div><h3 className="text-2xl font-bold text-slate-900 dark:text-white">3</h3><p className="text-xs text-slate-500">En Ejecución</p></div>
                </div>
                <div className="bg-white dark:bg-surface-dark p-4 rounded-xl border border-slate-200 dark:border-border-dark flex items-center gap-4">
                    <div className="size-12 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center"><span className="material-symbols-outlined text-2xl">task_alt</span></div>
                    <div><h3 className="text-2xl font-bold text-slate-900 dark:text-white">92%</h3><p className="text-xs text-slate-500">Cumplimiento</p></div>
                </div>
            </div>

            {/* List */}
            <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-slate-50 dark:bg-surface-darker text-slate-500 border-b border-slate-200 dark:border-border-dark">
                            <tr>
                                <th className="px-6 py-4">ID / Título</th>
                                <th className="px-6 py-4">Embarcación</th>
                                <th className="px-6 py-4">Tipo</th>
                                <th className="px-6 py-4">Prioridad</th>
                                <th className="px-6 py-4">Asignado a</th>
                                <th className="px-6 py-4">Vencimiento</th>
                                <th className="px-6 py-4">Estado</th>
                                <th className="px-6 py-4 text-right"></th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-border-dark">
                            {orders.map(order => (
                                <tr key={order.id} className="hover:bg-slate-50 dark:hover:bg-surface-darker/50 transition-colors">
                                    <td className="px-6 py-4">
                                        <p className="font-bold text-slate-900 dark:text-white">{order.title}</p>
                                        <p className="text-xs text-slate-500">{order.id}</p>
                                    </td>
                                    <td className="px-6 py-4 text-slate-600 dark:text-slate-300">{order.vessel}</td>
                                    <td className="px-6 py-4 text-slate-600 dark:text-slate-300">{order.type}</td>
                                    <td className="px-6 py-4"><PriorityBadge priority={order.priority} /></td>
                                    <td className="px-6 py-4 text-slate-600 dark:text-slate-300">{order.assignedTo}</td>
                                    <td className="px-6 py-4 font-mono text-slate-600 dark:text-slate-300">{order.dueDate}</td>
                                    <td className="px-6 py-4"><StatusBadge status={order.status} /></td>
                                    <td className="px-6 py-4 text-right">
                                        <button className="text-slate-400 hover:text-primary"><span className="material-symbols-outlined">more_vert</span></button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Modal */}
            {isModalOpen && (
                 <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-slate-900/70 backdrop-blur-sm" onClick={() => setIsModalOpen(false)}></div>
                    <div className="relative w-full max-w-lg bg-white dark:bg-surface-dark rounded-xl shadow-2xl border border-slate-200 dark:border-border-dark flex flex-col animate-fade-in-up">
                        <div className="px-6 py-4 border-b border-slate-200 dark:border-border-dark flex justify-between items-center bg-slate-50 dark:bg-surface-darker">
                            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                <span className="material-symbols-outlined text-primary">add_task</span> Nueva Orden
                            </h3>
                            <button onClick={() => setIsModalOpen(false)}><span className="material-symbols-outlined text-slate-400">close</span></button>
                        </div>
                        <form onSubmit={handleAddOrder} className="p-6 space-y-4">
                            <input name="title" required placeholder="Título del trabajo" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2" />
                            <div className="grid grid-cols-2 gap-4">
                                <input name="vessel" required placeholder="Embarcación" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2" />
                                <select name="type" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2">
                                    <option value="Preventivo">Preventivo</option>
                                    <option value="Correctivo">Correctivo</option>
                                </select>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <select name="priority" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2">
                                    <option value="Baja">Baja</option>
                                    <option value="Media">Media</option>
                                    <option value="Alta">Alta</option>
                                </select>
                                <input name="dueDate" type="date" required className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2" />
                            </div>
                            <input name="assignedTo" placeholder="Asignar a (Técnico/Proveedor)" className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2" />
                            <textarea name="description" placeholder="Descripción del problema..." className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-surface-darker px-4 py-2 h-24"></textarea>
                            <div className="flex justify-end gap-2 pt-2">
                                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-surface-darker rounded-lg">Cancelar</button>
                                <button type="submit" className="px-6 py-2 bg-primary text-white font-bold rounded-lg">Crear Orden</button>
                            </div>
                        </form>
                    </div>
                 </div>
            )}
        </div>
    );
};

export default Maintenance;