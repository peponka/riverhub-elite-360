import React, { useState } from 'react';

// --- Types & Mock Data ---
interface TripEvent {
    time: string;
    title: string;
    desc: string;
    type: 'normal' | 'warning' | 'alert';
}

interface TripStop {
    location: string;
    eta: string;
    status: 'completed' | 'current' | 'pending';
}

interface Trip {
  id: string;
  vesselName: string;
  vesselType: string;
  origin: string;
  destination: string;
  etd: string; // Estimated Time of Departure
  eta: string; // Estimated Time of Arrival
  progress: number; // 0-100
  status: 'Scheduled' | 'Loading' | 'In Transit' | 'Unloading' | 'Completed' | 'Delayed';
  cargo: string;
  amount: string;
  client: string;
  // Details for Modal
  stops?: TripStop[];
  events?: TripEvent[];
  manifest?: { item: string; qty: string; weight: string }[];
}

const MOCK_TRIPS: Trip[] = [
  {
    id: "VJ-2024-081",
    vesselName: "Remolcador Titan III",
    vesselType: "Convoy",
    origin: "Puerto Villeta (PY)",
    destination: "Rosario (ARG)",
    etd: "10 Oct, 08:00",
    eta: "15 Oct, 14:00",
    progress: 65,
    status: 'In Transit',
    cargo: "Harina de Soja",
    amount: "22,000 Ton",
    client: "Cargill",
    stops: [
        { location: "Puerto Villeta (Zarpe)", eta: "10 Oct, 08:00", status: "completed" },
        { location: "Pilar (Control)", eta: "11 Oct, 16:30", status: "completed" },
        { location: "Paso Bermejo", eta: "12 Oct, 09:00", status: "completed" },
        { location: "Bella Vista (Actual)", eta: "13 Oct, 12:00", status: "current" },
        { location: "Rosario (Destino)", eta: "15 Oct, 14:00", status: "pending" }
    ],
    events: [
        { time: "10 Oct, 08:15", title: "Zarpe Exitoso", desc: "Sin novedades.", type: "normal" },
        { time: "11 Oct, 17:00", title: "Cruce Pilar", desc: "Verificación de calado por prefectura.", type: "normal" },
        { time: "12 Oct, 10:30", title: "Lluvia Intensa", desc: "Reducción de velocidad por visibilidad.", type: "warning" }
    ],
    manifest: [
        { item: "Harina de Soja (Granel)", qty: "12 Barcazas", weight: "20,000 Ton" },
        { item: "Maíz (Granel)", qty: "2 Barcazas", weight: "2,000 Ton" }
    ]
  },
  {
    id: "VJ-2024-082",
    vesselName: "Barcaza T-55",
    vesselType: "Tanque",
    origin: "San Lorenzo (ARG)",
    destination: "Villa Elisa (PY)",
    etd: "12 Oct, 06:00",
    eta: "18 Oct, 18:00",
    progress: 15,
    status: 'Delayed',
    cargo: "Diesel Premium",
    amount: "3,500 m³",
    client: "Petropar",
    stops: [
        { location: "San Lorenzo", eta: "12 Oct, 06:00", status: "completed" },
        { location: "Km 400 (Actual)", eta: "13 Oct, 10:00", status: "current" },
        { location: "Villa Elisa", eta: "19 Oct, 08:00", status: "pending" }
    ],
    events: [
        { time: "12 Oct, 06:00", title: "Inicio de Bombeo", desc: "Carga completada.", type: "normal" },
        { time: "13 Oct, 08:00", title: "Falla Motor Aux", desc: "Detenido para reparaciones menores.", type: "alert" }
    ]
  },
  {
    id: "VJ-2024-085",
    vesselName: "Buque Motor Delta",
    vesselType: "Portacontenedores",
    origin: "Montevideo (URU)",
    destination: "Asunción (PY)",
    etd: "14 Oct, 22:00",
    eta: "19 Oct, 10:00",
    progress: 0,
    status: 'Loading',
    cargo: "Contenedores (Electronics)",
    amount: "140 TEUs",
    client: "Multi-Client",
    stops: [],
    events: []
  },
  {
    id: "VJ-2024-089",
    vesselName: "Remolcador Alpha",
    vesselType: "Convoy",
    origin: "Corumbá (BRA)",
    destination: "Concepción (PY)",
    etd: "20 Oct, 08:00",
    eta: "25 Oct, 12:00",
    progress: 0,
    status: 'Scheduled',
    cargo: "Mineral de Hierro",
    amount: "30,000 Ton",
    client: "Vale",
    stops: [],
    events: []
  }
];

// --- Helper Date Parser ---
const parseTripDate = (dateStr: string): Date => {
    // 1. Try ISO format (from HTML date input)
    if (dateStr.includes('-') && (dateStr.includes('T') || dateStr.length === 10)) {
        return new Date(dateStr);
    }

    // 2. Handle "DD Mon, HH:MM" format (Mock Data)
    // Assumes current year for the mock data
    const currentYear = new Date().getFullYear();
    const parts = dateStr.split(' ');
    
    if (parts.length >= 2) {
        const day = parseInt(parts[0]);
        // Remove comma and normalize
        const monthStr = parts[1].replace(',', '').substring(0, 3).toLowerCase();
        
        const months: {[key: string]: number} = {
            'ene': 0, 'jan': 0,
            'feb': 1,
            'mar': 2,
            'abr': 3, 'apr': 3,
            'may': 4,
            'jun': 5,
            'jul': 6,
            'ago': 7, 'aug': 7,
            'sep': 8,
            'oct': 9,
            'nov': 10,
            'dic': 11, 'dec': 11
        };
        
        const month = months[monthStr] ?? 0;
        return new Date(currentYear, month, day);
    }
    
    return new Date(); // Fallback
};

// --- Components ---

const StatusBadge = ({ status }: { status: Trip['status'] }) => {
    let styles = "";
    let icon = "";

    switch (status) {
        case 'In Transit': styles = "bg-blue-500/10 text-blue-500 border-blue-500/20"; icon = "sailing"; break;
        case 'Loading': styles = "bg-amber-500/10 text-amber-500 border-amber-500/20"; icon = "forklift"; break;
        case 'Unloading': styles = "bg-purple-500/10 text-purple-500 border-purple-500/20"; icon = "download"; break;
        case 'Scheduled': styles = "bg-slate-500/10 text-slate-500 border-slate-500/20"; icon = "event"; break;
        case 'Completed': styles = "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"; icon = "check_circle"; break;
        case 'Delayed': styles = "bg-red-500/10 text-red-500 border-red-500/20 animate-pulse"; icon = "warning"; break;
    }

    return (
        <span className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold border ${styles} uppercase tracking-wide`}>
            <span className="material-symbols-outlined text-[16px]">{icon}</span>
            {status === 'In Transit' ? 'En Ruta' : status === 'Delayed' ? 'Retrasado' : status === 'Loading' ? 'Cargando' : status === 'Scheduled' ? 'Programado' : status}
        </span>
    );
};

const TripCard = ({ trip, onClick }: { trip: Trip, onClick: (t: Trip) => void }) => (
    <div 
        onClick={() => onClick(trip)}
        className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-5 shadow-sm hover:shadow-md hover:border-primary/50 cursor-pointer transition-all group relative overflow-hidden"
    >
        {/* Progress Bar Background (Subtle) */}
        <div className="absolute top-0 left-0 h-1 bg-slate-100 dark:bg-slate-800 w-full">
            <div 
                className={`h-full ${trip.status === 'Delayed' ? 'bg-red-500' : 'bg-primary'} transition-all duration-1000`} 
                style={{ width: `${trip.progress}%` }}
            ></div>
        </div>

        <div className="flex justify-between items-start mb-4 mt-2">
            <div className="flex items-center gap-3">
                <div className="size-10 rounded-lg bg-slate-100 dark:bg-surface-darker flex items-center justify-center text-slate-600 dark:text-slate-300">
                    <span className="material-symbols-outlined">
                        {trip.vesselType === 'Tanque' ? 'water_drop' : trip.vesselType === 'Portacontenedores' ? 'view_module' : 'directions_boat'}
                    </span>
                </div>
                <div>
                    <h3 className="font-bold text-slate-900 dark:text-white group-hover:text-primary transition-colors">{trip.vesselName}</h3>
                    <p className="text-xs text-slate-500 dark:text-[#9db2b9] font-mono">{trip.id}</p>
                </div>
            </div>
            <StatusBadge status={trip.status} />
        </div>

        {/* Route Visualization */}
        <div className="flex items-center justify-between text-sm mb-6 relative px-2">
            {/* Connecting Line */}
            <div className="absolute top-1/2 left-4 right-4 h-0.5 bg-slate-200 dark:bg-slate-700 -z-0"></div>
            
            {/* Origin */}
            <div className="relative z-10 flex flex-col items-center bg-white dark:bg-surface-dark px-2">
                <div className="size-3 rounded-full border-2 border-slate-400 bg-white dark:bg-surface-dark mb-1"></div>
                <span className="font-bold text-slate-700 dark:text-slate-200">{trip.origin.split('(')[0]}</span>
                <span className="text-[10px] text-slate-400">{trip.etd}</span>
            </div>

            {/* Current Ship Icon on Line */}
            {trip.progress > 0 && trip.progress < 100 && (
                 <div 
                    className="absolute top-1/2 -translate-y-1/2 z-10 text-primary bg-white dark:bg-surface-dark rounded-full p-0.5"
                    style={{ left: `calc(${trip.progress}% - 12px)` }}
                >
                    <span className="material-symbols-outlined text-[20px] transform rotate-90">directions_boat</span>
                 </div>
            )}

            {/* Destination */}
            <div className="relative z-10 flex flex-col items-center bg-white dark:bg-surface-dark px-2">
                 <div className={`size-3 rounded-full border-2 ${trip.progress === 100 ? 'border-emerald-500 bg-emerald-500' : 'border-slate-400 bg-white dark:bg-surface-dark'} mb-1`}></div>
                <span className="font-bold text-slate-700 dark:text-slate-200">{trip.destination.split('(')[0]}</span>
                <span className={`text-[10px] ${trip.status === 'Delayed' ? 'text-red-500 font-bold' : 'text-slate-400'}`}>
                    ETA: {trip.eta}
                </span>
            </div>
        </div>

        {/* Footer Info */}
        <div className="bg-slate-50 dark:bg-surface-darker rounded-lg p-3 flex justify-between items-center text-xs border border-slate-100 dark:border-border-dark/50">
            <div>
                <p className="text-slate-500 dark:text-slate-400 uppercase text-[10px] font-bold tracking-wider">Carga</p>
                <p className="font-medium text-slate-900 dark:text-white">{trip.amount}</p>
                <p className="text-slate-500 truncate max-w-[120px]">{trip.cargo}</p>
            </div>
            <div className="text-right">
                <p className="text-slate-500 dark:text-slate-400 uppercase text-[10px] font-bold tracking-wider">Cliente</p>
                <p className="font-medium text-slate-900 dark:text-white">{trip.client}</p>
                <button className="text-primary hover:underline mt-0.5 text-[10px] font-bold">VER DETALLES</button>
            </div>
        </div>
    </div>
);

const KPICard = ({ label, value, subtext, icon, color }: any) => (
    <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-4 flex items-center gap-4 shadow-sm">
        <div className={`size-12 rounded-full ${color} bg-opacity-10 flex items-center justify-center text-xl`}>
            <span className="material-symbols-outlined">{icon}</span>
        </div>
        <div>
            <p className="text-xs text-slate-500 dark:text-[#9db2b9] font-bold uppercase tracking-wider">{label}</p>
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white">{value}</h3>
            <p className="text-xs text-slate-400">{subtext}</p>
        </div>
    </div>
);

const Trips: React.FC = () => {
  const [tripsList, setTripsList] = useState<Trip[]>(MOCK_TRIPS);
  const [filter, setFilter] = useState<'All' | 'Active' | 'Scheduled'>('All');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  
  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  const [detailTab, setDetailTab] = useState<'timeline' | 'manifest' | 'logs'>('timeline');

  const filteredTrips = tripsList.filter(t => {
      // 1. Status Filter
      let matchesStatus = true;
      if (filter === 'Active') matchesStatus = ['In Transit', 'Loading', 'Unloading', 'Delayed'].includes(t.status);
      if (filter === 'Scheduled') matchesStatus = t.status === 'Scheduled';

      // 2. Date Filter
      let matchesDate = true;
      if (startDate || endDate) {
          const tripDate = parseTripDate(t.etd);
          
          if (startDate) {
              const start = new Date(startDate);
              start.setHours(0, 0, 0, 0);
              if (tripDate < start) matchesDate = false;
          }
          
          if (endDate && matchesDate) {
              const end = new Date(endDate);
              end.setHours(23, 59, 59, 999);
              if (tripDate > end) matchesDate = false;
          }
      }

      return matchesStatus && matchesDate;
  });

  const handleAddTrip = (e: React.FormEvent) => {
      e.preventDefault();
      const form = e.target as HTMLFormElement;
      const formData = new FormData(form);
      const newTrip: Trip = {
          id: `VJ-${new Date().getFullYear()}-${Math.floor(Math.random()*1000)}`,
          vesselName: formData.get('vesselName') as string,
          vesselType: 'Barcaza', // Simplified
          origin: formData.get('origin') as string,
          destination: formData.get('destination') as string,
          etd: formData.get('etd') as string, // returns ISO format YYYY-MM-DDTHH:MM
          eta: 'Pendiente',
          progress: 0,
          status: 'Scheduled',
          cargo: formData.get('cargo') as string,
          amount: formData.get('amount') as string,
          client: formData.get('client') as string,
          stops: [],
          events: [],
          manifest: []
      };
      setTripsList([...tripsList, newTrip]);
      setIsModalOpen(false);
  };

  const handleTripClick = (trip: Trip) => {
      setSelectedTrip(trip);
      setDetailTab('timeline');
  };

  return (
    <div className="space-y-6 animate-fade-in relative">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
            <div>
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Gestión de Viajes</h1>
                <p className="text-slate-500 dark:text-[#9db2b9] mt-1">Control logístico y seguimiento de cargas en tiempo real.</p>
            </div>
            <button 
                onClick={() => setIsModalOpen(true)}
                className="bg-primary hover:bg-primary-dark text-white px-5 py-2.5 rounded-lg font-bold shadow-lg shadow-primary/20 flex items-center gap-2 transition-colors"
            >
                <span className="material-symbols-outlined">add_circle</span> Nuevo Viaje
            </button>
        </div>

        {/* Operational KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <KPICard label="En Tránsito" value={tripsList.filter(t => t.status === 'In Transit').length} subtext="Activos en ruta" icon="sailing" color="text-blue-500 bg-blue-500" />
            <KPICard label="Toneladas Activas" value="45.2k" subtext="+12% vs mes anterior" icon="weight" color="text-emerald-500 bg-emerald-500" />
            <KPICard label="Retrasos" value={tripsList.filter(t => t.status === 'Delayed').length} subtext="Bajo nivel del río" icon="timer_off" color="text-red-500 bg-red-500" />
            <KPICard label="Eficiencia" value="94%" subtext="Cumplimiento de ETA" icon="check_circle" color="text-purple-500 bg-purple-500" />
        </div>

        {/* Filters & Content */}
        <div className="flex flex-col gap-4">
            {/* Filter Bar */}
            <div className="border-b border-slate-200 dark:border-border-dark flex flex-col md:flex-row md:items-center justify-between gap-4">
                {/* Tabs */}
                <div className="flex gap-6 overflow-x-auto">
                    {['All', 'Active', 'Scheduled'].map((f) => (
                        <button 
                            key={f}
                            onClick={() => setFilter(f as any)}
                            className={`pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${
                                filter === f 
                                ? 'border-primary text-primary' 
                                : 'border-transparent text-slate-500 dark:text-[#9db2b9] hover:text-slate-800 dark:hover:text-white'
                            }`}
                        >
                            {f === 'All' ? 'Todos' : f === 'Active' ? 'En Curso' : 'Programados'}
                        </button>
                    ))}
                </div>

                {/* Date Filters */}
                <div className="flex items-center gap-3 pb-2 md:pb-1">
                    <div className="flex items-center gap-2 bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-lg px-2 py-1.5 shadow-sm">
                        <span className="text-xs font-bold text-slate-400 uppercase">Desde</span>
                        <input 
                            type="date" 
                            value={startDate}
                            onChange={(e) => setStartDate(e.target.value)}
                            className="bg-transparent text-xs text-slate-900 dark:text-white outline-none font-medium"
                        />
                    </div>
                    <div className="flex items-center gap-2 bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-lg px-2 py-1.5 shadow-sm">
                        <span className="text-xs font-bold text-slate-400 uppercase">Hasta</span>
                        <input 
                            type="date" 
                            value={endDate}
                            onChange={(e) => setEndDate(e.target.value)}
                            className="bg-transparent text-xs text-slate-900 dark:text-white outline-none font-medium"
                        />
                    </div>
                    {(startDate || endDate) && (
                        <button 
                            onClick={() => { setStartDate(''); setEndDate(''); }}
                            className="text-slate-400 hover:text-red-500 transition-colors"
                            title="Limpiar fechas"
                        >
                            <span className="material-symbols-outlined text-[20px]">filter_alt_off</span>
                        </button>
                    )}
                </div>
            </div>

            {/* Grid of Trips */}
            {filteredTrips.length > 0 ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-2 gap-6">
                    {filteredTrips.map(trip => (
                        <TripCard key={trip.id} trip={trip} onClick={handleTripClick} />
                    ))}
                </div>
            ) : (
                <div className="flex flex-col items-center justify-center py-12 text-slate-400 dark:text-slate-600">
                    <span className="material-symbols-outlined text-5xl mb-2 opacity-50">event_busy</span>
                    <p className="text-sm font-medium">No se encontraron viajes en este rango de fechas.</p>
                </div>
            )}
        </div>

        {/* --- ADD TRIP MODAL --- */}
        {isModalOpen && (
             <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                <div 
                    className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity" 
                    onClick={() => setIsModalOpen(false)}
                ></div>

                <div className="relative w-full max-w-lg bg-white dark:bg-surface-dark rounded-xl shadow-2xl border border-slate-200 dark:border-border-dark flex flex-col max-h-[90vh] overflow-hidden animate-fade-in-up">
                    <div className="px-6 py-4 border-b border-slate-200 dark:border-border-dark flex justify-between items-center bg-slate-50 dark:bg-surface-darker">
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                            <span className="material-symbols-outlined text-primary">route</span>
                            Planificar Nuevo Viaje
                        </h3>
                        <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-red-500 transition-colors">
                            <span className="material-symbols-outlined">close</span>
                        </button>
                    </div>

                    <form onSubmit={handleAddTrip} className="p-6 overflow-y-auto space-y-4">
                         <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Embarcación Asignada</label>
                            <input name="vesselName" type="text" placeholder="Ej. Remolcador Titan III" required className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                         </div>

                         <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Origen</label>
                                <input name="origin" type="text" placeholder="Puerto..." required className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Destino</label>
                                <input name="destination" type="text" placeholder="Puerto..." required className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                            </div>
                         </div>

                         <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Fecha y Hora de Zarpe (ETD)</label>
                            <input name="etd" type="datetime-local" required className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                         </div>

                         <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Tipo de Carga</label>
                                <input name="cargo" type="text" placeholder="Ej. Soja" required className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Cantidad</label>
                                <input name="amount" type="text" placeholder="Ej. 2000 Ton" required className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                            </div>
                         </div>
                         
                         <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Cliente</label>
                            <input name="client" type="text" placeholder="Ej. Cargill" required className="w-full rounded-lg border border-slate-300 dark:border-border-dark bg-slate-50 dark:bg-[#111618] px-4 py-2.5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/50" />
                         </div>

                        <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200 dark:border-border-dark mt-4">
                            <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-slate-600 dark:text-slate-300 font-medium hover:bg-slate-100 dark:hover:bg-surface-darker rounded-lg transition-colors">Cancelar</button>
                            <button type="submit" className="px-6 py-2 bg-primary hover:bg-primary-dark text-white font-bold rounded-lg shadow-lg shadow-primary/20 transition-all">Crear Viaje</button>
                        </div>
                    </form>
                </div>
            </div>
        )}

        {/* --- DETAILED TRIP MODAL (MISSION CONTROL) --- */}
        {selectedTrip && (
            <div className="fixed inset-0 z-50 flex items-center justify-end">
                <div 
                    className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm transition-opacity" 
                    onClick={() => setSelectedTrip(null)}
                ></div>

                <div className="relative w-full max-w-2xl h-full bg-white dark:bg-surface-dark shadow-2xl border-l border-slate-200 dark:border-border-dark flex flex-col animate-slide-in-right">
                    
                    {/* Detail Header */}
                    <div className="p-6 bg-slate-50 dark:bg-surface-darker border-b border-slate-200 dark:border-border-dark flex justify-between items-start">
                        <div>
                            <div className="flex items-center gap-2 mb-1">
                                <span className="text-xs font-bold bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded font-mono">{selectedTrip.id}</span>
                                <StatusBadge status={selectedTrip.status} />
                            </div>
                            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">{selectedTrip.vesselName}</h2>
                            <p className="text-sm text-slate-500 dark:text-[#9db2b9] mt-1">{selectedTrip.origin} <span className="text-slate-300 mx-1">➔</span> {selectedTrip.destination}</p>
                        </div>
                        <div className="flex gap-2">
                            <button className="p-2 text-slate-400 hover:text-white bg-slate-200 dark:bg-slate-800 rounded-lg transition-colors" title="Exportar">
                                <span className="material-symbols-outlined text-[20px]">print</span>
                            </button>
                            <button onClick={() => setSelectedTrip(null)} className="p-2 text-slate-400 hover:text-red-500 bg-slate-200 dark:bg-slate-800 rounded-lg transition-colors">
                                <span className="material-symbols-outlined text-[20px]">close</span>
                            </button>
                        </div>
                    </div>

                    {/* Navigation */}
                    <div className="flex border-b border-slate-200 dark:border-border-dark">
                        <button 
                            onClick={() => setDetailTab('timeline')}
                            className={`flex-1 py-3 text-sm font-bold border-b-2 transition-colors ${detailTab === 'timeline' ? 'border-primary text-primary' : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-white'}`}
                        >
                            Línea de Tiempo
                        </button>
                        <button 
                            onClick={() => setDetailTab('manifest')}
                            className={`flex-1 py-3 text-sm font-bold border-b-2 transition-colors ${detailTab === 'manifest' ? 'border-primary text-primary' : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-white'}`}
                        >
                            Manifiesto ({selectedTrip.manifest?.length || 0})
                        </button>
                        <button 
                            onClick={() => setDetailTab('logs')}
                            className={`flex-1 py-3 text-sm font-bold border-b-2 transition-colors ${detailTab === 'logs' ? 'border-primary text-primary' : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-white'}`}
                        >
                            Bitácora
                        </button>
                    </div>

                    {/* Content Area */}
                    <div className="flex-1 overflow-y-auto p-6 bg-slate-50/50 dark:bg-[#0f1519]">
                        
                        {detailTab === 'timeline' && (
                            <div className="space-y-0 relative">
                                {/* Vertical Line */}
                                <div className="absolute left-[21px] top-4 bottom-4 w-0.5 bg-slate-200 dark:bg-slate-700"></div>

                                {selectedTrip.stops?.length ? selectedTrip.stops.map((stop, i) => {
                                    const isLast = i === (selectedTrip.stops?.length || 0) - 1;
                                    const isCurrent = stop.status === 'current';
                                    const isCompleted = stop.status === 'completed';
                                    
                                    return (
                                        <div key={i} className="relative flex gap-6 pb-8 last:pb-0">
                                            <div className={`relative z-10 size-11 rounded-full border-4 flex items-center justify-center shrink-0 bg-white dark:bg-surface-dark
                                                ${isCurrent ? 'border-primary text-primary shadow-[0_0_15px_rgba(19,182,236,0.4)]' : 
                                                  isCompleted ? 'border-emerald-500 text-emerald-500' : 'border-slate-300 dark:border-slate-600 text-slate-300'}`}
                                            >
                                                <span className="material-symbols-outlined text-[20px]">
                                                    {isCompleted ? 'check' : isCurrent ? 'anchor' : 'circle'}
                                                </span>
                                            </div>
                                            <div className="flex-1 bg-white dark:bg-surface-dark p-4 rounded-xl border border-slate-200 dark:border-border-dark shadow-sm">
                                                <div className="flex justify-between items-start">
                                                    <h4 className={`font-bold ${isCurrent ? 'text-primary' : 'text-slate-900 dark:text-white'}`}>{stop.location}</h4>
                                                    <span className="text-xs font-mono text-slate-500">{stop.eta}</span>
                                                </div>
                                                <p className="text-xs text-slate-500 mt-1 uppercase font-bold tracking-wide">
                                                    {isCurrent ? 'UBICACIÓN ACTUAL' : isCompleted ? 'COMPLETADO' : 'PENDIENTE'}
                                                </p>
                                            </div>
                                        </div>
                                    );
                                }) : (
                                    <div className="text-center text-slate-500 py-10">Sin información de ruta detallada.</div>
                                )}
                            </div>
                        )}

                        {detailTab === 'manifest' && (
                            <div className="space-y-4">
                                <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl overflow-hidden">
                                    <table className="w-full text-left text-sm">
                                        <thead className="bg-slate-100 dark:bg-surface-darker text-slate-500 font-bold border-b border-slate-200 dark:border-border-dark">
                                            <tr>
                                                <th className="px-4 py-3">Ítem / Producto</th>
                                                <th className="px-4 py-3">Cantidad</th>
                                                <th className="px-4 py-3 text-right">Peso Total</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-slate-100 dark:divide-border-dark">
                                            {selectedTrip.manifest?.map((item, i) => (
                                                <tr key={i} className="hover:bg-slate-50 dark:hover:bg-surface-darker/50">
                                                    <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">{item.item}</td>
                                                    <td className="px-4 py-3 text-slate-500">{item.qty}</td>
                                                    <td className="px-4 py-3 text-right font-mono text-slate-700 dark:text-slate-300">{item.weight}</td>
                                                </tr>
                                            ))}
                                            {!selectedTrip.manifest?.length && (
                                                <tr><td colSpan={3} className="px-4 py-8 text-center text-slate-500">No hay carga registrada.</td></tr>
                                            )}
                                        </tbody>
                                        <tfoot className="bg-slate-50 dark:bg-surface-darker font-bold border-t border-slate-200 dark:border-border-dark">
                                            <tr>
                                                <td className="px-4 py-3 text-slate-900 dark:text-white">TOTAL</td>
                                                <td className="px-4 py-3"></td>
                                                <td className="px-4 py-3 text-right text-primary">{selectedTrip.amount}</td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div className="p-4 bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-800 rounded-xl flex gap-3">
                                    <span className="material-symbols-outlined text-blue-500">info</span>
                                    <div>
                                        <h4 className="text-sm font-bold text-blue-700 dark:text-blue-300">Nota del Cliente</h4>
                                        <p className="text-xs text-blue-600/80 dark:text-blue-400 mt-1">Requiere certificación de calidad en puerto de destino antes de descarga.</p>
                                    </div>
                                </div>
                            </div>
                        )}

                        {detailTab === 'logs' && (
                            <div className="space-y-4">
                                {selectedTrip.events?.map((evt, i) => (
                                    <div key={i} className={`p-4 rounded-xl border flex gap-3 ${
                                        evt.type === 'alert' ? 'bg-red-50 dark:bg-red-900/10 border-red-200 dark:border-red-800' :
                                        evt.type === 'warning' ? 'bg-orange-50 dark:bg-orange-900/10 border-orange-200 dark:border-orange-800' :
                                        'bg-white dark:bg-surface-dark border-slate-200 dark:border-border-dark'
                                    }`}>
                                        <div className={`mt-0.5 ${
                                            evt.type === 'alert' ? 'text-red-500' : 
                                            evt.type === 'warning' ? 'text-orange-500' : 
                                            'text-blue-500'
                                        }`}>
                                            <span className="material-symbols-outlined">
                                                {evt.type === 'alert' ? 'error' : evt.type === 'warning' ? 'warning' : 'info'}
                                            </span>
                                        </div>
                                        <div>
                                            <div className="flex items-center gap-2 mb-1">
                                                <span className="text-xs font-mono bg-slate-200 dark:bg-slate-700 px-1.5 py-0.5 rounded text-slate-600 dark:text-slate-300">{evt.time}</span>
                                                <h4 className="text-sm font-bold text-slate-900 dark:text-white">{evt.title}</h4>
                                            </div>
                                            <p className="text-xs text-slate-500 dark:text-slate-400">{evt.desc}</p>
                                        </div>
                                    </div>
                                ))}
                                {!selectedTrip.events?.length && (
                                    <div className="text-center text-slate-500 py-10">Sin eventos registrados.</div>
                                )}
                                <button className="w-full py-2 border-2 border-dashed border-slate-300 dark:border-border-dark text-slate-500 rounded-xl hover:border-primary hover:text-primary transition-colors text-sm font-bold flex items-center justify-center gap-2">
                                    <span className="material-symbols-outlined">add</span> Agregar Novedad
                                </button>
                            </div>
                        )}

                    </div>

                    {/* Footer Actions */}
                    <div className="p-4 border-t border-slate-200 dark:border-border-dark bg-slate-50 dark:bg-surface-darker flex gap-3">
                        <button className="flex-1 py-2.5 bg-white dark:bg-surface-dark border border-slate-300 dark:border-border-dark rounded-lg text-sm font-bold text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-border-dark transition-colors">
                            Contactar Capitán
                        </button>
                        <button className="flex-1 py-2.5 bg-primary hover:bg-primary-dark text-white rounded-lg text-sm font-bold transition-colors shadow-lg shadow-primary/20">
                            Actualizar Estado
                        </button>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default Trips;