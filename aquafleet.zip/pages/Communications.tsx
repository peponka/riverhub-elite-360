import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";

// --- Tipos y Datos Iniciales ---

interface Channel {
    id: number;
    name: string;
    frequency: string; // Ej: 156.800 MHz
    type: "emergency" | "ops" | "gov" | "log" | "ai";
    signalStrength: number; // 0-100
    gatewayStatus: "connected" | "tuning" | "offline";
}

interface Message {
    id: number;
    sender: string;
    text: string;
    time: string;
    isMe: boolean;
    type: 'text' | 'audio' | 'location' | 'file';
    duration?: string; // Para audio
    sources?: { title: string; uri: string }[]; // Para Grounding de Mapas
}

const CHANNELS_DATA: Channel[] = [
    { id: 1, name: "Canal 16 (Emergencia)", frequency: "156.800 MHz", type: "emergency", signalStrength: 95, gatewayStatus: "connected" },
    { id: 2, name: "Canal 12 (Operaciones)", frequency: "156.600 MHz", type: "ops", signalStrength: 80, gatewayStatus: "connected" },
    { id: 3, name: "Canal 06 (Prefectura)", frequency: "156.300 MHz", type: "gov", signalStrength: 60, gatewayStatus: "connected" },
    { id: 4, name: "Canal 72 (Logística)", frequency: "156.625 MHz", type: "log", signalStrength: 100, gatewayStatus: "connected" },
    { id: 99, name: "Canal Info (IA Maps)", frequency: "SAT-LINK AI", type: "ai", signalStrength: 100, gatewayStatus: "connected" },
];

const CONTACTS = [
    { id: 'v1', name: "Remolcador Titan III", status: "online", lastMsg: "Arribando a zona de alijo." },
    { id: 'v2', name: "Barcaza T-55", status: "away", lastMsg: "Recibido. Cambio y fuera." },
    { id: 'v3', name: "Base Asunción", status: "online", lastMsg: "Reporte meteorológico enviado." },
    { id: 'v4', name: "Cap. Ramírez", status: "offline", lastMsg: "Solicito permiso de zarpe." },
];

const INITIAL_MESSAGES: Message[] = [
    { id: 1, sender: "Base Asunción", text: "Atención toda la flota: Alerta de tormenta severa en zona sur para las próximas 4 horas.", time: "10:30", isMe: true, type: 'text' },
    { id: 2, sender: "Remolcador Titan III", text: "Recibido Base. Mantenemos posición en Km 1240.", time: "10:32", isMe: false, type: 'text' },
    { id: 3, sender: "Barcaza T-55", text: "Copiado. Procedemos a asegurar carga.", time: "10:33", isMe: false, type: 'text' },
];

const QUICK_REPLIES = [
    "Copiado", "Recibido, cambio.", "Posición Actual", "Solicitando Permiso", "Emergencia", "En espera"
];

// Componente para barras de señal
const SignalBars = ({ strength }: { strength: number }) => (
    <div className="flex gap-0.5 items-end h-3" title={`Intensidad de señal RoIP: ${strength}%`}>
        <div className={`w-1 rounded-sm ${strength > 20 ? 'bg-current' : 'bg-slate-300 dark:bg-slate-700'} h-1`}></div>
        <div className={`w-1 rounded-sm ${strength > 40 ? 'bg-current' : 'bg-slate-300 dark:bg-slate-700'} h-1.5`}></div>
        <div className={`w-1 rounded-sm ${strength > 60 ? 'bg-current' : 'bg-slate-300 dark:bg-slate-700'} h-2`}></div>
        <div className={`w-1 rounded-sm ${strength > 80 ? 'bg-current' : 'bg-slate-300 dark:bg-slate-700'} h-3`}></div>
    </div>
);

const Communications: React.FC = () => {
    const [activeChannelId, setActiveChannelId] = useState<number>(CHANNELS_DATA[0].id);
    const [channelStatus, setChannelStatus] = useState<'connecting' | 'connected'>('connected');
    
    const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
    const [inputText, setInputText] = useState("");
    const [isTyping, setIsTyping] = useState(false); // AI Typing State
    
    const [isRecording, setIsRecording] = useState(false);
    const [recordingTime, setRecordingTime] = useState(0);
    const [showAttachments, setShowAttachments] = useState(false);
    
    const chatEndRef = useRef<HTMLDivElement>(null);
    const timerRef = useRef<number | null>(null);

    const activeChannel = CHANNELS_DATA.find(c => c.id === activeChannelId) || CHANNELS_DATA[0];

    // Simular conexión RoIP al cambiar canal
    useEffect(() => {
        setChannelStatus('connecting');
        const timeout = setTimeout(() => {
            setChannelStatus('connected');
        }, 800); // 800ms de "sintonización"
        return () => clearTimeout(timeout);
    }, [activeChannelId]);

    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isRecording, isTyping]);

    useEffect(() => {
        if (isRecording) {
            timerRef.current = window.setInterval(() => {
                setRecordingTime(prev => prev + 1);
            }, 1000);
        } else {
            if (timerRef.current) clearInterval(timerRef.current);
            setRecordingTime(0);
        }
        return () => {
            if (timerRef.current) clearInterval(timerRef.current);
        };
    }, [isRecording]);

    const formatTime = (seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    };

    const handleSendMessage = async (text: string, type: 'text' | 'audio' | 'location' = 'text', duration?: string) => {
        if (!text.trim() && type === 'text') return;

        const newMsg: Message = {
            id: Date.now(),
            sender: "Yo",
            text: text,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isMe: true,
            type: type,
            duration: duration
        };

        setMessages(prev => [...prev, newMsg]);
        setInputText("");
        setShowAttachments(false);

        // --- AI INTEGRATION (Maps Grounding) ---
        if (activeChannel.type === 'ai' && type === 'text') {
            setIsTyping(true);
            try {
                const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: text,
                    config: {
                        tools: [{ googleMaps: {} }],
                        systemInstruction: "Eres 'Centro de Control IA', un asistente experto en logística fluvial y geografía para capitanes. Responde consultas sobre ubicaciones, distancias a puertos, y puntos de interés en el río de forma breve, profesional y útil. Usa Google Maps para verificar ubicaciones reales.",
                    }
                });

                const aiText = response.text || "Copiado. Sin información visual disponible.";
                
                // Extract Map Sources
                const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks
                    ?.map(c => c.maps)
                    .filter(m => m)
                    .map(m => ({ title: m.title, uri: m.uri })) || [];

                const aiResponseMsg: Message = {
                    id: Date.now() + 1,
                    sender: "Centro de Control IA",
                    text: aiText,
                    time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    isMe: false,
                    type: 'text',
                    sources: sources
                };

                setMessages(prev => [...prev, aiResponseMsg]);
            } catch (error) {
                console.error("Error AI:", error);
                const errorMsg: Message = {
                    id: Date.now() + 1,
                    sender: "System",
                    text: "Error de conexión satelital con el servidor de mapas.",
                    time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    isMe: false,
                    type: 'text'
                };
                setMessages(prev => [...prev, errorMsg]);
            } finally {
                setIsTyping(false);
            }
        }
    };

    const startRecording = () => setIsRecording(true);
    const cancelRecording = () => setIsRecording(false);
    const sendAudio = () => {
        const duration = formatTime(recordingTime);
        handleSendMessage("Transmisión PTT", 'audio', duration);
        setIsRecording(false);
    };

    return (
        <div className="h-[calc(100vh-140px)] flex gap-4 animate-fade-in">
            {/* Sidebar Channels & Contacts */}
            <div className="w-80 flex flex-col gap-4 hidden md:flex">
                
                {/* Channels Panel (RoIP Gateways) */}
                <div className="bg-slate-900 dark:bg-surface-dark rounded-xl border border-slate-800 dark:border-border-dark overflow-hidden flex flex-col shadow-lg">
                    <div className="p-4 bg-slate-800 dark:bg-surface-darker border-b border-slate-700 dark:border-border-dark flex justify-between items-center">
                        <div>
                            <h3 className="text-white font-bold text-sm uppercase flex items-center gap-2">
                                <span className="material-symbols-outlined text-primary">router</span> Gateways RoIP
                            </h3>
                            <p className="text-[10px] text-slate-400 mt-0.5">Enlace Radio-a-IP Activo</p>
                        </div>
                        <div className="size-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_#10b981]"></div>
                    </div>
                    <div className="p-2 space-y-1">
                        {CHANNELS_DATA.map(ch => (
                            <button 
                                key={ch.id}
                                onClick={() => setActiveChannelId(ch.id)}
                                className={`w-full text-left px-4 py-3 rounded-lg flex items-center justify-between transition-all border border-transparent ${
                                    activeChannelId === ch.id 
                                    ? 'bg-primary/20 text-white border-primary/30 shadow-md' 
                                    : 'text-slate-400 hover:bg-slate-800 dark:hover:bg-surface-darker hover:text-white'
                                }`}
                            >
                                <div className="flex flex-col overflow-hidden">
                                    <span className="font-bold text-sm truncate flex items-center gap-2">
                                        {ch.type === 'ai' && <span className="material-symbols-outlined text-sm text-purple-400">smart_toy</span>}
                                        {ch.name}
                                    </span>
                                    <span className="text-[10px] font-mono opacity-70">{ch.frequency}</span>
                                </div>
                                <div className="flex flex-col items-end gap-1">
                                    {ch.type === 'emergency' && <span className="material-symbols-outlined text-xs text-red-500">warning</span>}
                                    <SignalBars strength={ch.signalStrength} />
                                </div>
                            </button>
                        ))}
                    </div>
                </div>

                {/* Direct Messages */}
                <div className="flex-1 bg-white dark:bg-surface-dark rounded-xl border border-slate-200 dark:border-border-dark overflow-hidden flex flex-col shadow-sm">
                     <div className="p-4 bg-slate-50 dark:bg-surface-darker border-b border-slate-200 dark:border-border-dark">
                        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-2">Mensajería Privada</h3>
                        <input 
                            placeholder="Buscar contacto..." 
                            className="w-full bg-white dark:bg-surface-dark border border-slate-300 dark:border-border-dark rounded-lg px-3 py-1.5 text-sm outline-none focus:ring-1 focus:ring-primary dark:text-white"
                        />
                    </div>
                    <div className="flex-1 overflow-y-auto p-2">
                        {CONTACTS.map(contact => (
                            <div key={contact.id} className="p-3 hover:bg-slate-50 dark:hover:bg-surface-darker rounded-lg cursor-pointer flex gap-3 items-center group">
                                <div className="relative">
                                    <div className="size-10 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-500 dark:text-slate-300 font-bold">
                                        {contact.name.charAt(0)}
                                    </div>
                                    <div className={`absolute bottom-0 right-0 size-3 rounded-full border-2 border-white dark:border-surface-dark ${
                                        contact.status === 'online' ? 'bg-emerald-500' : contact.status === 'away' ? 'bg-amber-500' : 'bg-slate-400'
                                    }`}></div>
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex justify-between items-center">
                                        <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">{contact.name}</h4>
                                        <span className="text-[10px] text-slate-400">10m</span>
                                    </div>
                                    <p className="text-xs text-slate-500 truncate group-hover:text-primary transition-colors">{contact.lastMsg}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Main Chat Area */}
            <div className="flex-1 bg-white dark:bg-surface-dark rounded-xl border border-slate-200 dark:border-border-dark flex flex-col shadow-sm overflow-hidden relative">
                {/* Chat Header (Radio Interface) */}
                <div className="p-4 border-b border-slate-200 dark:border-border-dark flex justify-between items-center bg-slate-50 dark:bg-surface-darker">
                    <div className="flex items-center gap-4">
                        <div className={`size-12 rounded-full flex items-center justify-center border-4 shadow-inner ${
                            channelStatus === 'connecting' 
                            ? 'border-amber-500/30 bg-amber-500/10 text-amber-500' 
                            : activeChannel.type === 'ai'
                            ? 'border-purple-500/30 bg-purple-500/10 text-purple-500'
                            : 'border-emerald-500/30 bg-emerald-500/10 text-emerald-500'
                        }`}>
                            <span className={`material-symbols-outlined text-2xl ${channelStatus === 'connecting' ? 'animate-spin' : ''}`}>
                                {channelStatus === 'connecting' ? 'settings_input_antenna' : activeChannel.type === 'ai' ? 'smart_toy' : 'sensors'}
                            </span>
                        </div>
                        <div>
                            <div className="flex items-center gap-2">
                                <h2 className="text-xl font-bold text-slate-900 dark:text-white leading-none">
                                    {activeChannel.frequency}
                                </h2>
                                {channelStatus === 'connected' ? (
                                    <span className={`text-white text-[10px] px-1.5 py-0.5 rounded font-mono uppercase animate-pulse ${activeChannel.type === 'ai' ? 'bg-purple-500' : 'bg-red-500'}`}>
                                        {activeChannel.type === 'ai' ? 'AI LINK' : 'TX/RX'}
                                    </span>
                                ) : (
                                    <span className="bg-amber-500 text-white text-[10px] px-1.5 py-0.5 rounded font-mono uppercase">Sintonizando...</span>
                                )}
                            </div>
                            <p className="text-xs text-slate-500 font-medium uppercase tracking-wide mt-1">
                                {activeChannel.name} • {activeChannel.type === 'ai' ? 'Google Maps Grounding' : 'Encriptación AES-256'}
                            </p>
                        </div>
                    </div>
                    <div className="flex gap-2 border-l border-slate-200 dark:border-slate-700 pl-4">
                         <div className="text-right mr-2 hidden lg:block">
                            <p className="text-[10px] text-slate-400 uppercase font-bold">Puerta de Enlace</p>
                            <p className="text-xs font-mono text-slate-600 dark:text-slate-300">GW-ASU-04</p>
                         </div>
                        <button className="p-2 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full text-slate-500 transition-colors" title="Historial de Audio">
                            <span className="material-symbols-outlined">history</span>
                        </button>
                        <button className="p-2 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full text-slate-500 transition-colors" title="Silenciar (Squelch)">
                            <span className="material-symbols-outlined">volume_up</span>
                        </button>
                    </div>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-100 dark:bg-[#0f1519]">
                    
                    {/* Simulated Connection Message */}
                    {channelStatus === 'connecting' && (
                        <div className="flex justify-center py-4">
                            <div className="bg-slate-800 text-slate-300 text-xs px-4 py-2 rounded-full flex items-center gap-2 shadow-sm">
                                <span className="size-2 rounded-full bg-amber-500 animate-ping"></span>
                                Estableciendo enlace con {activeChannel.name}...
                            </div>
                        </div>
                    )}

                    <div className="text-center text-xs text-slate-400 my-4">Hoy, 27 Octubre</div>
                    {messages.map(msg => (
                        <div key={msg.id} className={`flex ${msg.isMe ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[75%] rounded-2xl p-4 shadow-sm ${
                                msg.isMe 
                                ? 'bg-primary text-white rounded-tr-none' 
                                : 'bg-white dark:bg-surface-darker text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-tl-none'
                            }`}>
                                {!msg.isMe && <p className={`text-xs font-bold mb-1 ${msg.sender === 'Centro de Control IA' ? 'text-purple-400' : 'text-primary'}`}>{msg.sender}</p>}
                                
                                {/* Content based on Type */}
                                {msg.type === 'text' && (
                                    <div className="space-y-2">
                                        <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                                        
                                        {/* Render Map Sources */}
                                        {msg.sources && msg.sources.length > 0 && (
                                            <div className="flex flex-wrap gap-2 mt-2 pt-2 border-t border-slate-200 dark:border-slate-700">
                                                {msg.sources.map((source, idx) => (
                                                    <a 
                                                        key={idx} 
                                                        href={source.uri} 
                                                        target="_blank" 
                                                        rel="noopener noreferrer"
                                                        className="flex items-center gap-1.5 bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 dark:hover:bg-blue-900/40 text-blue-600 dark:text-blue-300 px-2 py-1 rounded-lg text-xs font-bold transition-colors"
                                                    >
                                                        <span className="material-symbols-outlined text-[14px]">map</span>
                                                        {source.title}
                                                    </a>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                )}
                                
                                {msg.type === 'audio' && (
                                    <div className="flex items-center gap-3 min-w-[200px]">
                                        <button className={`size-8 rounded-full flex items-center justify-center shadow-sm ${msg.isMe ? 'bg-white text-primary' : 'bg-primary text-white'}`}>
                                            <span className="material-symbols-outlined">play_arrow</span>
                                        </button>
                                        <div className="flex-1">
                                            <div className="flex justify-between text-[10px] opacity-70 mb-1">
                                                <span>PTT Audio</span>
                                                <span>{msg.duration}</span>
                                            </div>
                                            <div className={`h-6 w-full rounded flex items-center gap-0.5 overflow-hidden ${msg.isMe ? 'opacity-50' : 'opacity-100'}`}>
                                                {/* Simulated Waveform */}
                                                {Array.from({length: 20}).map((_, i) => (
                                                    <div key={i} className={`w-1 rounded-full ${msg.isMe ? 'bg-white' : 'bg-slate-400'}`} style={{ height: `${30 + Math.random() * 70}%` }}></div>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {msg.type === 'location' && (
                                    <div className="flex items-center gap-2">
                                        <span className="material-symbols-outlined text-2xl">location_on</span>
                                        <div>
                                            <p className="font-bold text-sm">Ubicación Compartida</p>
                                            <p className="text-xs underline cursor-pointer">Ver en Mapa</p>
                                        </div>
                                    </div>
                                )}

                                <p className={`text-[10px] mt-2 text-right ${msg.isMe ? 'text-primary-100' : 'text-slate-400'}`}>{msg.time}</p>
                            </div>
                        </div>
                    ))}
                    
                    {/* Typing Indicator */}
                    {isTyping && (
                        <div className="flex justify-start">
                            <div className="bg-white dark:bg-surface-darker border border-slate-200 dark:border-slate-700 rounded-2xl rounded-tl-none p-3 shadow-sm flex items-center gap-2">
                                <span className="text-xs font-bold text-purple-400">IA Maps</span>
                                <div className="flex gap-1">
                                    <span className="size-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></span>
                                    <span className="size-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></span>
                                    <span className="size-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></span>
                                </div>
                            </div>
                        </div>
                    )}
                    
                    <div ref={chatEndRef} />
                </div>

                {/* Input Area */}
                <div className="bg-white dark:bg-surface-dark border-t border-slate-200 dark:border-border-dark relative">
                    
                    {/* Attachments Menu (Floating) */}
                    {showAttachments && (
                        <div className="absolute bottom-full left-4 mb-2 bg-white dark:bg-surface-darker border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl p-2 flex flex-col gap-1 min-w-[200px] animate-fade-in-up z-20">
                            <button onClick={() => handleSendMessage("Ubicación actual: Km 1240", 'location')} className="flex items-center gap-3 px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg text-sm text-slate-700 dark:text-slate-200 text-left">
                                <span className="material-symbols-outlined text-red-500">location_on</span> Compartir Ubicación
                            </button>
                            <button className="flex items-center gap-3 px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg text-sm text-slate-700 dark:text-slate-200 text-left">
                                <span className="material-symbols-outlined text-blue-500">description</span> Manifiesto de Carga
                            </button>
                            <button className="flex items-center gap-3 px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg text-sm text-slate-700 dark:text-slate-200 text-left">
                                <span className="material-symbols-outlined text-purple-500">photo_camera</span> Cámara
                            </button>
                        </div>
                    )}

                    {/* Quick Replies Bar */}
                    {!isRecording && (
                         <div className="flex gap-2 overflow-x-auto p-2 pb-0 custom-scrollbar">
                            {QUICK_REPLIES.map((reply, i) => (
                                <button 
                                    key={i} 
                                    onClick={() => handleSendMessage(reply)}
                                    className="whitespace-nowrap px-3 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-full text-xs font-medium border border-slate-200 dark:border-slate-700 transition-colors"
                                >
                                    {reply}
                                </button>
                            ))}
                        </div>
                    )}

                    <div className="p-4">
                        {isRecording ? (
                            // --- RECORDING UI (PTT Mode) ---
                            <div className="flex items-center gap-4 bg-red-50 dark:bg-red-900/10 rounded-xl px-4 py-3 border border-red-100 dark:border-red-900/30 animate-pulse ring-2 ring-red-500/20">
                                <div className="size-3 rounded-full bg-red-500 animate-pulse shadow-[0_0_10px_#ef4444]"></div>
                                <div className="flex flex-col">
                                    <span className="font-bold text-red-600 dark:text-red-400 text-xs tracking-wider uppercase">Transmitiendo (PTT)</span>
                                    <span className="font-mono font-bold text-slate-900 dark:text-white">{formatTime(recordingTime)}</span>
                                </div>
                                
                                {/* Fake Waveform */}
                                <div className="flex-1 flex items-center justify-center gap-0.5 h-8 overflow-hidden">
                                    {Array.from({length: 40}).map((_,i) => (
                                        <div 
                                            key={i} 
                                            className="w-1 bg-red-400 rounded-full animate-pulse"
                                            style={{ height: `${20 + Math.random() * 80}%`, animationDelay: `${i * 0.05}s` }}
                                        ></div>
                                    ))}
                                </div>

                                <button onClick={cancelRecording} className="text-slate-500 hover:text-red-500 font-bold text-sm px-2">Cancelar</button>
                                <button onClick={sendAudio} className="size-10 rounded-full bg-red-500 hover:bg-red-600 text-white flex items-center justify-center shadow-lg transition-transform active:scale-95">
                                    <span className="material-symbols-outlined">send</span>
                                </button>
                            </div>
                        ) : (
                            // --- TEXT INPUT UI ---
                            <div className="flex gap-2 items-end">
                                <button 
                                    onClick={() => setShowAttachments(!showAttachments)}
                                    className={`p-3 transition-colors rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 ${showAttachments ? 'text-primary bg-primary/10' : 'text-slate-400'}`}
                                >
                                    <span className="material-symbols-outlined">attach_file</span>
                                </button>
                                <div className="flex-1 bg-slate-100 dark:bg-surface-darker rounded-xl flex items-center px-4 border border-transparent focus-within:border-primary transition-colors">
                                    <textarea 
                                        value={inputText}
                                        onChange={(e) => setInputText(e.target.value)}
                                        onKeyDown={(e) => {
                                            if (e.key === 'Enter' && !e.shiftKey) {
                                                e.preventDefault();
                                                handleSendMessage(inputText);
                                            }
                                        }}
                                        placeholder={`Transmitir en ${activeChannel.name}...`} 
                                        className="w-full bg-transparent border-none focus:ring-0 py-3 text-sm max-h-24 resize-none outline-none dark:text-white placeholder-slate-400"
                                        rows={1}
                                    />
                                </div>
                                {inputText.trim() ? (
                                    <button 
                                        onClick={() => handleSendMessage(inputText)}
                                        className="size-12 rounded-full bg-primary hover:bg-primary-dark text-white shadow-lg flex items-center justify-center transition-transform active:scale-95"
                                    >
                                        <span className="material-symbols-outlined">send</span>
                                    </button>
                                ) : (
                                    <button 
                                        onClick={startRecording}
                                        className="size-12 rounded-full bg-red-500 hover:bg-red-600 text-white shadow-lg flex items-center justify-center transition-transform active:scale-95 border-4 border-red-200 dark:border-red-900/30"
                                        title="Push to Talk (PTT)"
                                    >
                                        <span className="material-symbols-outlined">mic</span>
                                    </button>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Communications;