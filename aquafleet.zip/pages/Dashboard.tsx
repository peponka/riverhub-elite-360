import React from 'react';
import { Link } from 'react-router-dom';

const StatCard = ({ icon, label, value, subtext, colorClass, bgClass, trend }: any) => (
  <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-5 hover:border-primary/50 transition-all group shadow-sm">
    <div className="flex justify-between items-start mb-4">
      <div className={`p-2.5 rounded-lg ${colorClass} ${bgClass} bg-opacity-10 dark:bg-opacity-10 group-hover:bg-opacity-20 transition-colors`}>
        <span className="material-symbols-outlined">{icon}</span>
      </div>
      {trend && (
        <span className={`flex items-center text-xs font-bold px-2.5 py-1 rounded-full border ${trend.positive ? 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20' : 'text-red-500 bg-red-500/10 border-red-500/20'}`}>
          {trend.value}
        </span>
      )}
    </div>
    <p className="text-slate-500 dark:text-[#9db2b9] text-sm font-medium">{label}</p>
    <div className="flex items-end gap-2 mt-1">
      <h3 className="text-2xl font-bold text-slate-900 dark:text-white">{value}</h3>
    </div>
    {subtext && <p className="text-xs text-slate-400 mt-2">{subtext}</p>}
  </div>
);

// New Component: River & Weather Conditions
const RiverConditionsCard = () => (
  <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl p-6 text-white shadow-lg relative overflow-hidden group">
    {/* Abstract Background Shapes */}
    <div className="absolute top-0 right-0 w-32 h-32 bg-white opacity-5 rounded-full -mr-10 -mt-10 group-hover:scale-110 transition-transform duration-700"></div>
    <div className="absolute bottom-0 left-0 w-24 h-24 bg-white opacity-5 rounded-full -ml-10 -mb-10 group-hover:scale-110 transition-transform duration-700"></div>
    
    <div className="relative z-10">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-blue-100 text-sm font-semibold uppercase tracking-wider">Nivel del Río</h3>
          <p className="text-white font-bold text-lg">Asunción, PY</p>
        </div>
        <div className="bg-white/20 p-2 rounded-lg backdrop-blur-sm">
          <span className="material-symbols-outlined text-white">water_drop</span>
        </div>
      </div>
      
      <div className="flex items-end gap-3 mb-4">
        <span className="text-4xl font-bold">1.24m</span>
        <div className="flex items-center text-red-300 bg-red-900/30 px-2 py-1 rounded text-xs font-bold mb-1 border border-red-500/30">
          <span className="material-symbols-outlined text-[14px] mr-1">trending_down</span>
          -2cm
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4 mt-6 pt-6 border-t border-white/10">
        <div>
          <p className="text-blue-200 text-xs mb-1">Clima</p>
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-yellow-300">sunny</span>
            <span className="font-bold">34°C</span>
          </div>
        </div>
        <div>
          <p className="text-blue-200 text-xs mb-1">Viento</p>
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-gray-300">air</span>
            <span className="font-bold">NE 12kt</span>
          </div>
        </div>
      </div>
    </div>
  </div>
);

// New Component: Fuel Analytics Chart (CSS Only)
const FuelChart = () => {
  const data = [
    { day: 'Lun', val: 65, color: 'bg-primary' },
    { day: 'Mar', val: 45, color: 'bg-primary' },
    { day: 'Mie', val: 78, color: 'bg-primary' },
    { day: 'Jue', val: 55, color: 'bg-primary' },
    { day: 'Vie', val: 89, color: 'bg-orange-500' }, // High consumption alert
    { day: 'Sab', val: 34, color: 'bg-primary' },
    { day: 'Dom', val: 20, color: 'bg-primary' },
  ];

  return (
    <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-6 shadow-sm h-full flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">Consumo de Combustible</h3>
          <p className="text-xs text-slate-500 dark:text-[#9db2b9]">Últimos 7 días (Litros x1000)</p>
        </div>
        <button className="text-slate-400 hover:text-primary transition-colors">
          <span className="material-symbols-outlined">more_vert</span>
        </button>
      </div>

      <div className="flex-1 flex items-end justify-between gap-2 md:gap-4 mt-2">
        {data.map((item, i) => (
          <div key={i} className="flex flex-col items-center gap-2 w-full group cursor-pointer">
            <div className="relative w-full bg-slate-100 dark:bg-surface-darker rounded-t-lg h-32 md:h-40 overflow-hidden">
              <div 
                className={`absolute bottom-0 left-0 right-0 ${item.color} opacity-80 group-hover:opacity-100 transition-all duration-500 rounded-t-lg`}
                style={{ height: `${item.val}%` }}
              >
                {/* Tooltip on hover */}
                <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] px-2 py-1 rounded transition-opacity whitespace-nowrap z-10">
                  {item.val * 100} L
                </div>
              </div>
            </div>
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400 group-hover:text-primary transition-colors">{item.day}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight">Visión General</h1>
          <p className="text-slate-500 dark:text-[#9db2b9] mt-1 flex items-center gap-2 text-sm">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            Sistema Operativo • Hidrovía Paraguay-Paraná
          </p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-surface-dark text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-50 dark:hover:bg-border-dark transition-colors text-sm font-medium border border-slate-200 dark:border-border-dark shadow-sm">
            <span className="material-symbols-outlined text-[20px]">download</span>
            Reportes
          </button>
          <Link to="/voyages/new" className="flex items-center gap-2 px-4 py-2 bg-primary hover:bg-primary-dark text-white rounded-lg transition-all text-sm font-semibold shadow-lg shadow-primary/20">
            <span className="material-symbols-outlined text-[20px]">add</span>
            Nuevo Viaje
          </Link>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          icon="directions_boat" 
          label="Barcazas Operativas" 
          value="85/100" 
          colorClass="text-blue-500" 
          bgClass="bg-blue-500" 
          trend={{value: '98% Disp.', positive: true}} 
        />
        <StatCard 
          icon="map" 
          label="Viajes Activos" 
          value="12" 
          subtext="3 arribos estimados hoy"
          colorClass="text-purple-500" 
          bgClass="bg-purple-500"
          trend={{value: '+1 Nuevo', positive: true}} 
        />
        <StatCard 
          icon="assignment_late" 
          label="Certificados por Vencer" 
          value="3" 
          subtext="Vencimiento < 7 días"
          colorClass="text-orange-500" 
          bgClass="bg-orange-500"
          trend={{value: 'Atención', positive: false}} 
        />
        <StatCard 
          icon="build_circle" 
          label="Mantenimientos" 
          value="5" 
          subtext="1 de Alta Prioridad"
          colorClass="text-slate-500" 
          bgClass="bg-slate-500" 
        />
      </div>

      {/* Main Content Area - Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column (2/3 width) */}
        <div className="lg:col-span-2 flex flex-col gap-6">
          
          {/* Map Section */}
          <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl flex flex-col overflow-hidden shadow-sm h-[400px]">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-border-dark bg-slate-50 dark:bg-surface-darker flex justify-between items-center">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-slate-400">public</span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Flota en Tiempo Real</h3>
              </div>
              <div className="flex gap-2">
                  <Link to="/map" className="text-xs text-primary hover:underline font-medium">Ver mapa completo</Link>
              </div>
            </div>
            <div className="relative flex-1 bg-slate-800 w-full h-full overflow-hidden group">
              {/* Simulated Map Background */}
              <div className="absolute inset-0 bg-cover bg-center opacity-60 mix-blend-luminosity hover:mix-blend-normal transition-all duration-700" style={{ backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuDgdm1br09l4HMWYtNme7-id8ufkJ1lGWlGDU932SJY4447rvTEez-WjX1jD6eMFH3pYy8avEy4LVKXAqc2GYWpUJjAGm1k9PcB90a6ZJ9zTkzhxiC_bR6lU6Tb9z0On2lpwJl_jqLtx6taYFc2yOMijiVZxqzYcrJdjerffabPSfz_OBnDreMS3aQsRsm6f2aWb-5BUpi_DROd0dp2Ga0GShset5XP5DBjt2EIDsDf_EnmjuSbPaYY0_9O0-iBKonWgKNKSXGIqBSN")' }}></div>
              <div className="absolute inset-0 bg-gradient-to-t from-surface-dark/90 via-transparent to-surface-dark/10 pointer-events-none"></div>
              
              {/* Map Markers */}
              <div className="absolute top-[35%] left-[48%] flex flex-col items-center cursor-pointer group/marker">
                 <div className="relative flex items-center justify-center size-8 hover:scale-110 transition-transform">
                   <div className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary/30 opacity-75"></div>
                   <div className="relative inline-flex items-center justify-center rounded-full size-4 bg-primary border-2 border-white shadow-lg"></div>
                 </div>
                 <div className="mt-1 bg-surface-darker/90 backdrop-blur text-white text-[10px] px-2 py-1 rounded border border-border-dark font-medium opacity-0 group-hover/marker:opacity-100 transition-opacity">R. Alpha</div>
              </div>

              <div className="absolute top-[60%] left-[65%] flex flex-col items-center cursor-pointer group/marker">
                 <div className="relative flex items-center justify-center size-6 hover:scale-110 transition-transform">
                   <div className="relative inline-flex items-center justify-center rounded-full size-3 bg-emerald-500 border-2 border-white shadow-lg"></div>
                 </div>
                 <div className="mt-1 bg-surface-darker/90 backdrop-blur text-white text-[10px] px-2 py-1 rounded border border-border-dark font-medium opacity-0 group-hover/marker:opacity-100 transition-opacity">R. Beta</div>
              </div>
            </div>
          </div>

          {/* New Row for Analytics */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-64">
             <FuelChart />
             
             {/* Simple List (Maintenance) moved here */}
             <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl flex flex-col overflow-hidden shadow-sm">
                <div className="px-5 py-4 border-b border-slate-200 dark:border-border-dark flex justify-between items-center">
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">Próximos Mantenimientos</h3>
                    <Link to="/maintenance" className="text-primary text-xs font-medium hover:underline">Ver todo</Link>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-2">
                    {[
                        { title: 'Cambio de Aceite', ship: 'R. Alpha', icon: 'settings', date: 'Hoy' },
                        { title: 'Limpieza de Casco', ship: 'B-102', icon: 'cleaning_services', date: 'Mañana' },
                        { title: 'Inspección General', ship: 'Delta', icon: 'verified', date: '15 Nov' },
                        { title: 'Revisión Motor', ship: 'Titan III', icon: 'engine', date: '18 Nov' },
                    ].map((item, i) => (
                        <div key={i} className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-surface-darker/50 hover:bg-slate-100 dark:hover:bg-surface-darker border border-transparent hover:border-slate-200 dark:hover:border-border-dark rounded-lg transition-all group cursor-pointer">
                            <div className="flex items-center gap-3">
                                <div className="bg-slate-200 dark:bg-slate-700/50 size-9 rounded-lg flex items-center justify-center text-slate-500 dark:text-slate-300 group-hover:text-primary dark:group-hover:text-white group-hover:bg-primary/10 dark:group-hover:bg-primary/20 transition-colors">
                                    <span className="material-symbols-outlined text-[18px]">{item.icon}</span>
                                </div>
                                <div>
                                    <p className="text-sm font-medium text-slate-900 dark:text-white">{item.title}</p>
                                    <div className="flex items-center gap-2">
                                      <p className="text-xs text-slate-500">{item.ship}</p>
                                      <span className="text-[10px] bg-slate-200 dark:bg-slate-700 px-1.5 rounded text-slate-600 dark:text-slate-300">{item.date}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
          </div>
        </div>

        {/* Right Column (1/3 width) - Context & Alerts */}
        <div className="flex flex-col gap-6">
            
            {/* 1. River Conditions (New) */}
            <RiverConditionsCard />

            {/* 2. Alerts List */}
            <div className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl flex-1 flex flex-col overflow-hidden shadow-sm min-h-[300px]">
                <div className="px-5 py-3 border-b border-slate-200 dark:border-border-dark bg-slate-50 dark:bg-surface-darker flex justify-between items-center">
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                        <span className="size-2 rounded-full bg-red-500 animate-pulse"></span> Alertas
                    </h3>
                    <span className="bg-red-500/10 text-red-500 border border-red-500/20 text-[10px] px-2 py-0.5 rounded font-bold uppercase">2 Activas</span>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                    <div className="group flex gap-3 items-start p-3 bg-red-50 dark:bg-red-500/5 border border-red-100 dark:border-red-500/10 rounded-lg hover:bg-red-100 dark:hover:bg-red-500/10 transition-all cursor-pointer">
                        <div className="bg-red-500/20 p-1.5 rounded text-red-500 shrink-0"><span className="material-symbols-outlined text-[20px]">warning</span></div>
                        <div>
                            <h4 className="text-sm font-semibold text-slate-900 dark:text-red-50">Falla Hidráulica</h4>
                            <p className="text-xs text-slate-500 dark:text-red-200/70 mt-0.5">Remolcador Gamma • Km 980</p>
                            <p className="text-[10px] text-slate-400 mt-1">Hace 2 horas</p>
                        </div>
                    </div>
                    <div className="group flex gap-3 items-start p-3 bg-orange-50 dark:bg-orange-500/5 border border-orange-100 dark:border-orange-500/10 rounded-lg hover:bg-orange-100 dark:hover:bg-orange-500/10 transition-all cursor-pointer">
                        <div className="bg-orange-500/20 p-1.5 rounded text-orange-500 shrink-0"><span className="material-symbols-outlined text-[20px]">description</span></div>
                        <div>
                            <h4 className="text-sm font-semibold text-slate-900 dark:text-orange-50">Certificado Vencido</h4>
                            <p className="text-xs text-slate-500 dark:text-orange-200/70 mt-0.5">Barcaza B-204</p>
                        </div>
                    </div>
                    {/* Extra simulated alerts to fill space if needed */}
                    <div className="group flex gap-3 items-start p-3 bg-blue-50 dark:bg-blue-500/5 border border-blue-100 dark:border-blue-500/10 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-500/10 transition-all cursor-pointer">
                        <div className="bg-blue-500/20 p-1.5 rounded text-blue-500 shrink-0"><span className="material-symbols-outlined text-[20px]">info</span></div>
                        <div>
                            <h4 className="text-sm font-semibold text-slate-900 dark:text-blue-50">Aviso Meteorológico</h4>
                            <p className="text-xs text-slate-500 dark:text-blue-200/70 mt-0.5">Tormentas severas zona sur.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;