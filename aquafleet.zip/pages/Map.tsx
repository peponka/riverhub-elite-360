
import React, { useState, useEffect, useRef, useCallback } from 'react';

// --- CONFIGURACIÓN MAPA ---
const MAP_BOUNDS = { TOP_LAT: -20.0, BOTTOM_LAT: -35.0, LEFT_LON: -62.0, RIGHT_LON: -55.0 };

// Barcos iniciales para la simulación (Fallback)
const INITIAL_VESSELS = [
    { mmsi: '7450001', name: 'REMOLCADOR TITAN III', type: 70, lat: -25.2, lon: -57.6, cog: 180, speed: 8 },
    { mmsi: '7450002', name: 'BARCAZA T-55', type: 80, lat: -26.1, lon: -58.2, cog: 175, speed: 4 },
    { mmsi: '7010023', name: 'BUQUE DELTA', type: 70, lat: -27.5, lon: -58.8, cog: 10, speed: 12 },
    { mmsi: '7459999', name: 'PATRULLA PNA', type: 30, lat: -32.9, lon: -60.6, cog: 320, speed: 15 },
    { mmsi: '7451111', name: 'CONVOY ALPHA', type: 70, lat: -29.0, lon: -59.5, cog: 190, speed: 6 },
    { mmsi: '7452222', name: 'TRANSBORDADOR ZETA', type: 60, lat: -25.5, lon: -57.5, cog: 90, speed: 5 },
    { mmsi: '7453333', name: 'CARGUERO OMEGA', type: 79, lat: -33.5, lon: -60.0, cog: 340, speed: 10 },
];

const project = (lat: number, lon: number) => {
    // Proyección simple lineal (Mercator simplificada) para demo visual
    const y = ((lat - MAP_BOUNDS.TOP_LAT) / (MAP_BOUNDS.BOTTOM_LAT - MAP_BOUNDS.TOP_LAT)) * 100;
    const x = ((lon - MAP_BOUNDS.LEFT_LON) / (MAP_BOUNDS.RIGHT_LON - MAP_BOUNDS.LEFT_LON)) * 100;
    return { top: Math.max(5, Math.min(95, y)), left: Math.max(5, Math.min(95, x)) };
};

export const FleetMap = () => {
    const [vessels, setVessels] = useState<any>({});
    const [rxCount, setRxCount] = useState(0);
    const [connectionMode, setConnectionMode] = useState<'SIMULATION' | 'LIVE_PROXY'>('SIMULATION');
    const [lastHeartbeat, setLastHeartbeat] = useState(Date.now());
    const [isConnecting, setIsConnecting] = useState(false);
    const [showGuide, setShowGuide] = useState(false); // Estado para la guía de ayuda
    
    // Referencias para controlar intervalos y sockets
    const socketRef = useRef<WebSocket | null>(null);
    const simulationIntervalRef = useRef<any>(null);

    // --- LOGIC: SIMULATION MODE ---
    const startSimulation = useCallback(() => {
        if (simulationIntervalRef.current) return; // Ya corre
        console.log("Iniciando Modo Simulación...");
        
        // Cargar datos iniciales
        const initialMap: any = {};
        INITIAL_VESSELS.forEach(v => {
            initialMap[v.mmsi] = { ...v, ...project(v.lat, v.lon) };
        });
        setVessels(initialMap);

        simulationIntervalRef.current = setInterval(() => {
            setVessels((prev: any) => {
                const next = { ...prev };
                Object.keys(next).forEach(key => {
                    const v = next[key];
                    // Movimiento simulado
                    const speedFactor = 0.0005 * (v.speed / 10);
                    const rad = (v.cog - 90) * (Math.PI / 180);
                    let newLat = v.lat + (Math.sin(rad) * speedFactor);
                    let newLon = v.lon + (Math.cos(rad) * speedFactor);

                    // Rebote
                    if (newLat > MAP_BOUNDS.TOP_LAT || newLat < MAP_BOUNDS.BOTTOM_LAT) { v.cog = (v.cog + 180) % 360; newLat = v.lat; }
                    if (newLon > MAP_BOUNDS.RIGHT_LON || newLon < MAP_BOUNDS.LEFT_LON) { v.cog = (v.cog + 180) % 360; newLon = v.lon; }

                    next[key] = { ...v, lat: newLat, lon: newLon, cog: v.cog + (Math.random() - 0.5) * 2, ...project(newLat, newLon) };
                });
                return next;
            });
        }, 1000);
    }, []);

    const stopSimulation = useCallback(() => {
        if (simulationIntervalRef.current) {
            clearInterval(simulationIntervalRef.current);
            simulationIntervalRef.current = null;
        }
    }, []);

    // --- LOGIC: LIVE MODE (PROXY) ---
    const connectToProxy = useCallback(() => {
        if (socketRef.current?.readyState === WebSocket.OPEN) return;

        setIsConnecting(true);
        const ws = new WebSocket('ws://localhost:8080');

        ws.onopen = () => {
            console.log("✅ Conectado al Proxy AIS!");
            setConnectionMode('LIVE_PROXY');
            stopSimulation(); 
            setVessels({});
            setRxCount(0);
            setIsConnecting(false);
            setShowGuide(false); // Cerrar guía si conecta con éxito
        };

        ws.onmessage = (event) => {
            try {
                const raw = JSON.parse(event.data);
                if (raw.error === "API_KEY_MISSING") {
                    alert("⚠️ Error: Falta configurar la API KEY en el archivo proxy.js");
                    ws.close();
                    return;
                }

                const msg = raw;
                if (msg.MessageType === 'PositionReport') {
                    const mmsi = msg.MetaData.MMSI;
                    const name = msg.MetaData.ShipName.trim();
                    const lat = msg.Message.PositionReport.Latitude;
                    const lon = msg.Message.PositionReport.Longitude;
                    const cog = msg.Message.PositionReport.Cog;
                    const speed = msg.Message.PositionReport.Sog;

                    setVessels((prev: any) => ({
                        ...prev,
                        [mmsi]: {
                            mmsi,
                            name: name || `Vessel ${mmsi}`,
                            type: 70, 
                            lat,
                            lon,
                            cog,
                            speed,
                            ...project(lat, lon)
                        }
                    }));
                    setRxCount(c => c + 1);
                    setLastHeartbeat(Date.now());
                }
            } catch (e) {
                // Ignorar
            }
        };

        ws.onclose = () => {
            setConnectionMode('SIMULATION');
            socketRef.current = null;
            setIsConnecting(false);
            startSimulation();
        };

        ws.onerror = (err) => {
            console.error("Error Websocket", err);
            ws.close(); 
            // Si falla la conexión manual, sugerir abrir la guía
            if (isConnecting) setShowGuide(true);
        };

        socketRef.current = ws;
    }, [startSimulation, stopSimulation, isConnecting]);

    // Initial Mount
    useEffect(() => {
        startSimulation();
        // Intentamos conectar una vez al inicio silenciosamente
        const ws = new WebSocket('ws://localhost:8080');
        ws.onopen = () => {
             ws.close(); // Solo checkeo
             connectToProxy();
        };
        return () => {
            if (socketRef.current) socketRef.current.close();
            stopSimulation();
        };
    }, [startSimulation, stopSimulation, connectToProxy]);

    return (
        <div className="relative w-full h-[calc(100vh-140px)] bg-[#0f172a] rounded-2xl overflow-hidden border border-slate-800 font-sans shadow-2xl flex flex-col">
            
            {/* --- STATUS BAR OVERLAY --- */}
            <div className="absolute top-4 left-4 z-20 bg-black/80 border border-slate-700 backdrop-blur-md p-3 rounded-lg text-[10px] text-slate-300 font-mono shadow-lg min-w-[240px]">
                <div className="flex items-center justify-between mb-3 pb-2 border-b border-white/10">
                    <div className="flex items-center gap-2">
                        <div className={`size-2.5 rounded-full animate-pulse shadow-[0_0_8px_currentColor] ${connectionMode === 'LIVE_PROXY' ? 'bg-purple-500 text-purple-500' : 'bg-amber-500 text-amber-500'}`} />
                        <span className={`font-bold ${connectionMode === 'LIVE_PROXY' ? 'text-purple-400' : 'text-amber-400'}`}>
                            {connectionMode === 'LIVE_PROXY' ? 'SATELITAL (VÍA PROXY)' : 'MODO SIMULACIÓN'}
                        </span>
                    </div>
                    <span className="text-white font-bold">{rxCount} PKTS</span>
                </div>
                
                <div className="space-y-1.5 mb-3">
                    <div className="flex justify-between">
                        <span>ESTADO:</span> 
                        <span className="text-white">{connectionMode === 'LIVE_PROXY' ? 'CONECTADO' : 'LOCAL / DEMO'}</span>
                    </div>
                    <div className="flex justify-between">
                        <span>ACTIVOS:</span> 
                        <span className="text-white">{Object.keys(vessels).length}</span>
                    </div>
                </div>

                {connectionMode === 'SIMULATION' && (
                    <div className="flex flex-col gap-2">
                        <button 
                            onClick={connectToProxy}
                            disabled={isConnecting}
                            className={`w-full py-2 rounded text-[10px] font-bold uppercase transition-all flex items-center justify-center gap-2 ${
                                isConnecting 
                                ? 'bg-slate-700 text-slate-400 cursor-wait' 
                                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md'
                            }`}
                        >
                            {isConnecting ? (
                                <>
                                    <span className="size-3 border-2 border-slate-400 border-t-transparent rounded-full animate-spin"></span>
                                    Conectando...
                                </>
                            ) : (
                                <>
                                    <span className="material-symbols-outlined text-[14px]">router</span>
                                    Conectar Proxy Local
                                </>
                            )}
                        </button>
                        <button 
                            onClick={() => setShowGuide(true)}
                            className="w-full py-1.5 text-[9px] text-slate-400 hover:text-white underline"
                        >
                            ¿Cómo funciona esto?
                        </button>
                    </div>
                )}

                <div className="mt-2 text-[9px] text-slate-500 italic text-center">
                    {connectionMode === 'LIVE_PROXY' 
                        ? 'Recibiendo datos de proxy.js (Puerto 8080)'
                        : 'Ejecuta "node proxy.js" para ver datos reales.'
                    }
                </div>
            </div>

            {/* --- SETUP GUIDE MODAL --- */}
            {showGuide && (
                <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
                    <div className="bg-[#1e293b] border border-slate-700 rounded-xl max-w-lg w-full p-6 shadow-2xl relative">
                        <button 
                            onClick={() => setShowGuide(false)}
                            className="absolute top-4 right-4 text-slate-400 hover:text-white"
                        >
                            <span className="material-symbols-outlined">close</span>
                        </button>
                        
                        <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                            <span className="material-symbols-outlined text-amber-500">warning</span> 
                            Configuración del Proxy AIS
                        </h2>
                        
                        <div className="space-y-4 text-sm text-slate-300">
                            <p>El navegador web no puede conectarse directamente a satélites por seguridad. Necesitas ejecutar un pequeño "puente" en tu computadora.</p>
                            
                            <div className="bg-black/50 rounded-lg p-4 font-mono text-xs space-y-3 border border-slate-800">
                                <div>
                                    <p className="text-slate-500 mb-1">PASO 1: Instalar dependencias (Solo una vez)</p>
                                    <div className="text-green-400 select-all">npm install ws</div>
                                </div>
                                <div>
                                    <p className="text-slate-500 mb-1">PASO 2: Configurar Llave</p>
                                    <p>Abre el archivo <span className="text-white bg-slate-700 px-1 rounded">proxy.js</span> y pega tu API Key de AISStream.</p>
                                </div>
                                <div>
                                    <p className="text-slate-500 mb-1">PASO 3: Encender el Motor</p>
                                    <div className="text-green-400 select-all">node proxy.js</div>
                                </div>
                            </div>

                            <p className="text-xs text-slate-400">
                                Una vez que veas el mensaje <span className="text-white">"🚀 Proxy AIS Local iniciado"</span> en tu terminal, presiona el botón "Conectar Proxy Local" aquí en el mapa.
                            </p>
                        </div>

                        <div className="mt-6 flex justify-end">
                            <button 
                                onClick={() => { setShowGuide(false); connectToProxy(); }}
                                className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg font-bold text-sm transition-colors shadow-lg"
                            >
                                ¡Listo, ya lo ejecuté!
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Map Area */}
            <div className="relative flex-1 bg-[#0b1120] overflow-hidden group">
                
                {/* 1. Base Map (Abstract River Shape) */}
                <div className="absolute inset-0 opacity-20 pointer-events-none">
                    <svg className="w-full h-full" preserveAspectRatio="none">
                        <defs>
                            <linearGradient id="riverGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                                <stop offset="0%" stopColor="#0ea5d6" stopOpacity="0.1" />
                                <stop offset="50%" stopColor="#0ea5d6" stopOpacity="0.6" />
                                <stop offset="100%" stopColor="#0ea5d6" stopOpacity="0.1" />
                            </linearGradient>
                        </defs>
                        <path d="M 60 0 Q 65 20 50 40 T 40 80 T 60 100" fill="none" stroke="url(#riverGrad)" strokeWidth="80" strokeLinecap="round" />
                        <path d="M 60 0 Q 65 20 50 40 T 40 80 T 60 100" fill="none" stroke="#0ea5d6" strokeWidth="2" strokeDasharray="5,5" opacity="0.5" />
                    </svg>
                </div>

                {/* 2. Grid Lines */}
                <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:40px_40px]"></div>

                {/* 3. Vessels Render */}
                {Object.values(vessels).map((v: any, i: number) => {
                    const isTug = v.type >= 70 && v.type <= 79; 
                    const isTanker = v.type >= 80 && v.type <= 89;
                    
                    return (
                        <div 
                            key={i} 
                            className="absolute transition-all duration-[1000ms] ease-linear group/vessel cursor-pointer z-10" 
                            style={{ top: `${v.top}%`, left: `${v.left}%`, transform: 'translate(-50%, -50%)' }}
                        >
                            {/* Label on Hover */}
                            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 bg-slate-900/90 text-white text-[9px] px-2 py-1 rounded border border-slate-700 whitespace-nowrap opacity-0 group-hover/vessel:opacity-100 transition-opacity z-20 pointer-events-none shadow-xl">
                                <p className="font-bold text-primary">{v.name}</p>
                                <p className="text-slate-300 font-mono">LAT: {v.lat.toFixed(4)}</p>
                                <p className="text-slate-300 font-mono">LON: {v.lon.toFixed(4)}</p>
                                <div className="flex gap-2 mt-1 pt-1 border-t border-slate-700">
                                    <span className="text-emerald-400">{v.speed.toFixed(1)} kts</span>
                                    <span className="text-amber-400">{Math.round(v.cog)}°</span>
                                </div>
                            </div>

                            {/* Vessel Icon */}
                            <div 
                                className="relative flex items-center justify-center transition-transform duration-500"
                                style={{ transform: `rotate(${v.cog}deg)` }}
                            >
                                {/* Wake Effect (Estela) */}
                                <div className="absolute -bottom-3 w-0.5 h-6 bg-gradient-to-t from-transparent to-white/30 blur-[1px]"></div>
                                
                                {isTug ? (
                                    <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-b-[14px] border-b-emerald-500 filter drop-shadow-[0_0_6px_rgba(16,185,129,0.8)]"></div>
                                ) : isTanker ? (
                                    <div className="w-3 h-6 bg-red-500 rounded-sm border border-white/50 shadow-[0_0_10px_rgba(239,68,68,0.6)]"></div>
                                ) : (
                                    <div className="size-3 bg-blue-500 rotate-45 border border-white/50 shadow-[0_0_10px_rgba(59,130,246,0.6)]"></div>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default FleetMap;
