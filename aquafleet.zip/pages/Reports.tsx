import React, { useState } from 'react';
import { useToast } from '../components/Toast';

interface ReportType {
    id: string;
    title: string;
    description: string;
    icon: string;
    color: string;
    category: 'Operativo' | 'Financiero' | 'Seguridad';
}

const REPORTS: ReportType[] = [
    { id: 'rep-01', title: 'Resumen de Viajes Mensual', description: 'Detalle de viajes completados, tiempos de tránsito y demoras.', icon: 'route', color: 'text-blue-500 bg-blue-500/10', category: 'Operativo' },
    { id: 'rep-02', title: 'Consumo de Combustible', description: 'Análisis de consumo por buque vs. distancia recorrida.', icon: 'local_gas_station', color: 'text-orange-500 bg-orange-500/10', category: 'Financiero' },
    { id: 'rep-03', title: 'Mantenimientos Realizados', description: 'Historial de órdenes de trabajo y costos asociados.', icon: 'build', color: 'text-slate-500 bg-slate-500/10', category: 'Operativo' },
    { id: 'rep-04', title: 'Incidentes y Seguridad (SMS)', description: 'Reporte de no conformidades y accidentes laborales.', icon: 'security', color: 'text-red-500 bg-red-500/10', category: 'Seguridad' },
    { id: 'rep-05', title: 'Control de Tripulación', description: 'Días embarcados, rotaciones y vencimiento de documentos.', icon: 'groups', color: 'text-emerald-500 bg-emerald-500/10', category: 'Operativo' },
    { id: 'rep-06', title: 'Rentabilidad por Viaje', description: 'P&L detallado por viaje asignado (Fletes vs Costos).', icon: 'payments', color: 'text-purple-500 bg-purple-500/10', category: 'Financiero' },
];

const Reports: React.FC = () => {
    const { showToast } = useToast();
    const [isGenerating, setIsGenerating] = useState<string | null>(null);
    const [filter, setFilter] = useState('Todos');

    const handleGenerate = (id: string, title: string) => {
        setIsGenerating(id);
        // Simulate API call/Generation
        setTimeout(() => {
            setIsGenerating(null);
            showToast(`Reporte "${title}" generado exitosamente.`, 'success');
        }, 2000);
    };

    const filteredReports = REPORTS.filter(r => filter === 'Todos' || r.category === filter);

    return (
        <div className="space-y-6 animate-fade-in">
             <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Centro de Reportes</h1>
                    <p className="text-slate-500 dark:text-[#9db2b9] mt-1">Generación de informes operativos y gerenciales.</p>
                </div>
            </div>

            {/* Filters */}
            <div className="flex gap-2 border-b border-slate-200 dark:border-border-dark pb-1">
                {['Todos', 'Operativo', 'Financiero', 'Seguridad'].map(cat => (
                    <button 
                        key={cat}
                        onClick={() => setFilter(cat)}
                        className={`px-4 py-2 text-sm font-bold border-b-2 transition-colors ${filter === cat ? 'border-primary text-primary' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-white'}`}
                    >
                        {cat}
                    </button>
                ))}
            </div>

            {/* Reports Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredReports.map((report) => (
                    <div key={report.id} className="bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow flex flex-col">
                        <div className="flex items-start justify-between mb-4">
                            <div className={`size-12 rounded-xl flex items-center justify-center ${report.color}`}>
                                <span className="material-symbols-outlined text-2xl">{report.icon}</span>
                            </div>
                            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-slate-100 dark:bg-surface-darker px-2 py-1 rounded">
                                {report.category}
                            </span>
                        </div>
                        <h3 className="font-bold text-lg text-slate-900 dark:text-white mb-2">{report.title}</h3>
                        <p className="text-sm text-slate-500 dark:text-[#9db2b9] flex-1 mb-6">
                            {report.description}
                        </p>
                        
                        <div className="flex gap-3 items-center mt-auto pt-4 border-t border-slate-100 dark:border-border-dark">
                             <div className="flex-1">
                                <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Formato</label>
                                <select className="w-full bg-slate-50 dark:bg-surface-darker border border-slate-200 dark:border-border-dark rounded text-xs py-1 px-2 outline-none dark:text-white">
                                    <option>PDF (Adobe)</option>
                                    <option>Excel (XLSX)</option>
                                    <option>CSV (Raw Data)</option>
                                </select>
                             </div>
                             <button 
                                onClick={() => handleGenerate(report.id, report.title)}
                                disabled={isGenerating === report.id}
                                className={`px-4 py-2 rounded-lg font-bold text-sm text-white shadow-lg transition-all flex items-center gap-2 ${isGenerating === report.id ? 'bg-slate-400 cursor-wait' : 'bg-primary hover:bg-primary-dark shadow-primary/20'}`}
                             >
                                {isGenerating === report.id ? (
                                    <span className="size-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                                ) : (
                                    <span className="material-symbols-outlined text-[18px]">download</span>
                                )}
                                {isGenerating === report.id ? '...' : 'Descargar'}
                             </button>
                        </div>
                    </div>
                ))}
            </div>

            {/* Automatic Scheduling */}
            <div className="bg-slate-900 rounded-xl p-6 text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-10">
                     <span className="material-symbols-outlined text-9xl">schedule_send</span>
                </div>
                <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                    <div>
                        <h3 className="text-xl font-bold mb-2">Reportes Automáticos</h3>
                        <p className="text-slate-400 text-sm max-w-lg">Configura el envío automático de reportes semanales o mensuales directamente al correo de la gerencia o clientes.</p>
                    </div>
                    <button onClick={() => showToast('Módulo de programación en mantenimiento', 'warning')} className="bg-white text-slate-900 px-5 py-2.5 rounded-lg font-bold hover:bg-slate-100 transition-colors">
                        Configurar Envíos
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Reports;