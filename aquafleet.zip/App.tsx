
import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { ToastProvider } from './components/Toast';
import { LanguageProvider } from './contexts/LanguageContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Fleet from './pages/Fleet';
import Map from './pages/Map';
import Settings from './pages/Settings';
import Trips from './pages/Trips';
import Crew from './pages/Crew';
import Maintenance from './pages/Maintenance';
import Fuel from './pages/Fuel';
import Incidents from './pages/Incidents';
import QuoteIA from './pages/QuoteIA'; 
import Communications from './pages/Communications'; 
import Weather from './pages/Weather'; 
import Integrations from './pages/Integrations'; 
import Inventory from './pages/Inventory'; 
import Reports from './pages/Reports'; 
import Documents from './pages/Documents';

// Placeholder for screens not fully implemented
const Placeholder = ({ title }: { title: string }) => (
  <div className="flex flex-col items-center justify-center h-[60vh] text-center p-8 border-2 border-dashed border-slate-300 dark:border-border-dark rounded-xl">
    <span className="material-symbols-outlined text-6xl text-slate-300 dark:text-border-dark mb-4">construction</span>
    <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">{title}</h2>
    <p className="text-slate-500 dark:text-[#9db2b9]">Esta funcionalidad estará disponible pronto.</p>
  </div>
);

// Private Route Wrapper
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, isLoading, logout } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background-light dark:bg-background-dark">
        <div className="size-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return <Layout onLogout={logout}>{children}</Layout>;
};

const AppRoutes: React.FC = () => {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) return null; // Prevent flickering

  return (
    <Routes>
      {/* Public Routes */}
      <Route 
        path="/login" 
        element={isAuthenticated ? <Navigate to="/dashboard" replace /> : <Login />} 
      />
      <Route 
        path="/register" 
        element={isAuthenticated ? <Navigate to="/dashboard" replace /> : <Register />} 
      />
      
      {/* Root Redirect Logic - Smart Redirect */}
      <Route 
        path="/" 
        element={isAuthenticated ? <Navigate to="/dashboard" replace /> : <Navigate to="/login" replace />} 
      />

      {/* --- Protected Routes --- */}
      <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/map" element={<ProtectedRoute><Map /></ProtectedRoute>} />
      <Route path="/reports" element={<ProtectedRoute><Reports /></ProtectedRoute>} />
      
      {/* Commercial */}
      <Route path="/quote-ia" element={<ProtectedRoute><QuoteIA /></ProtectedRoute>} /> 
      <Route path="/documents" element={<ProtectedRoute><Documents /></ProtectedRoute>} />
      
      {/* Operations */}
      <Route path="/fleet" element={<ProtectedRoute><Fleet /></ProtectedRoute>} />
      <Route path="/trips" element={<ProtectedRoute><Trips /></ProtectedRoute>} />
      <Route path="/maintenance" element={<ProtectedRoute><Maintenance /></ProtectedRoute>} />
      <Route path="/fuel" element={<ProtectedRoute><Fuel /></ProtectedRoute>} />
      <Route path="/crew" element={<ProtectedRoute><Crew /></ProtectedRoute>} />
      <Route path="/communications" element={<ProtectedRoute><Communications /></ProtectedRoute>} /> 
      <Route path="/inventory" element={<ProtectedRoute><Inventory /></ProtectedRoute>} /> 
      
      {/* Environment */}
      <Route path="/weather" element={<ProtectedRoute><Weather /></ProtectedRoute>} /> 
      <Route path="/incidents" element={<ProtectedRoute><Incidents /></ProtectedRoute>} />
      
      {/* System */}
      <Route path="/integrations" element={<ProtectedRoute><Integrations /></ProtectedRoute>} /> 
      <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
      
      {/* Placeholders */}
      <Route path="/voyages/new" element={<ProtectedRoute><Placeholder title="Nuevo Viaje" /></ProtectedRoute>} />
      <Route path="/vessels/detail" element={<ProtectedRoute><Placeholder title="Detalle de Embarcación" /></ProtectedRoute>} />

      {/* Fallback - Send any unknown route to Dashboard if logged in, else Login */}
      <Route path="*" element={<Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />} />
    </Routes>
  );
};

const App: React.FC = () => {
  return (
    <LanguageProvider>
      <ToastProvider>
        <AuthProvider>
          <HashRouter>
            <AppRoutes />
          </HashRouter>
        </AuthProvider>
      </ToastProvider>
    </LanguageProvider>
  );
};

export default App;
