
import { createClient } from '@supabase/supabase-js';

// ==========================================
// ⚠️ PASO OBLIGATORIO PARA MODO PRODUCCIÓN ⚠️
// ==========================================
// 1. Ve a https://supabase.com y crea un proyecto.
// 2. Ve a Settings > API.
// 3. Copia y pega tus credenciales abajo entre las comillas.

const SUPABASE_URL = ''; // <-- PEGA TU URL AQUÍ (Ej: https://xyz.supabase.co)
const SUPABASE_ANON_KEY = ''; // <-- PEGA TU ANON KEY AQUÍ (Ej: eyJhbGciOiJIUzI1NiIsInR5c...)

// Lógica automática:
// - Si pegaste las claves arriba, la app se conecta a la nube (Modo Real).
// - Si las dejas vacías, la app sigue funcionando en Modo Demo (Datos falsos en memoria).

const isConfigured = SUPABASE_URL !== '' && SUPABASE_ANON_KEY !== '';

export const supabase = isConfigured
  ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY) 
  : null;

export const isSupabaseConfigured = isConfigured;
